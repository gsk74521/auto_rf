# XPath 可读定位器 · Robot Framework Browser

一个原生 JavaScript、Manifest V3 的 Chrome / Edge 扩展。加载插件不需要 Node、Python、构建工具或服务器。

当前版本：**1.1.0**。升级时替换 extension 文件夹，在扩展管理页点击“重新加载”，并**刷新待测页面**，清除旧版已注入的脚本。

## 安装

1. 解压下载的插件 ZIP 包。
2. Chrome 打开 `chrome://extensions/`，或 Edge 打开 `edge://extensions/`。
3. 开启“开发者模式”，点击“加载已解压的扩展程序”。
4. **选择内含 `manifest.json` 的 `extension` 文件夹**，不是项目根目录。
5. 将插件固定到浏览器工具栏。安装或更新后建议刷新待测页面。

## 使用

1. 在待测网页打开插件，点击“开始选取元素”。
2. 鼠标移到元素上查看绿色高亮，点击目标。Esc 取消。
3. 再次打开插件，默认展示 XPath，点击“复制定位器”或“复制操作语句”。
4. 将结果粘贴进 `.robot`。可以改选 `Fill Text`、`Get Text`、`Wait For Elements State` 等关键字。

“Browser 完整定位器”和“操作语句”已做 Robot Framework 参数转义；“查看原始定位器”展示未经 Robot 转义的原始选择器，适合检查逻辑或在其他工具使用。不要把已经转义的输出再转义一次，也不要直接粘贴到 Python 字符串中。

例如表格中存在多个“编辑”按钮，插件会优先尝试：

```robotframework
*** Settings ***
Library    Browser

*** Test Cases ***
编辑指定用户
    New Browser    chromium    headless=False
    New Page    https://你的待测网站/
    Click    xpath=//iframe[@name="workspace"] >>> xpath=//iframe[@title="编辑器"] >>> xpath=//td[normalize-space(.)="张三"]/ancestor::tr/descendant::button[normalize-space(.)="编辑"]
```

表单的典型结果：

```robotframework
Fill Text    xpath=//label[normalize-space(.)="用户名"]/following-sibling::input[1]    admin
```

`[1]` 在这里指最近的匹配兄弟元素，是标签与输入框的相对关系；插件不会在非唯一结果上简单添加全局 `(//...)[1]` 隐藏歧义。

Browser 的 iframe 分隔符参考：[官方选择器说明](https://robotframework-browser.org/docs/concepts/selectors)。本插件输出针对 **Browser**，不适用于 SeleniumLibrary。

## 定位规则

- 默认 XPath：相邻标签/文本的兄弟轴、目标文本、稳定 id/data-testid/name/aria-label、完整 class 词匹配、表格单元格/标题的 `ancestor` → `descendant` 语义关系。
- CSS 同时生成：优先稳定属性、class 及稳定祖先范围。完整 Browser 链使用 `css:light=`，避免 Browser 的默认 CSS 穿透 Shadow DOM 后额外匹配其他元素，保证与原生 DOM 检查语义一致。
- 每个候选都在当前文档/作用域内执行检查，必须恰好命中选中的元素；跨域 iframe 的每一层也独立生成定位器。
- iframe 自动沿真实父子 frame 关系向上拼接，不依赖访问跨域 `contentDocument`。支持多层 iframe 和相同 URL 的多个 frame。
- 每个 iframe/目标定位段最多6个路径步骤。先尝试无数字下标的候选；必要时在稳定锚点下使用短相对路径，最多一个局部下标，例如 `//div[@class="pix-transfer-opbar"]/button[1]`。整个 iframe 链包含多个段，各段独立限制。
- 搜索稳定祖先与输出路径长度分开处理，跳过无意义的包装层；重复工具栏会尝试组合外层 id/class 与内层工具栏锚点。
- 无符合约束的唯一定位时，返回明确提示并禁用复制，不再生成 `/html[1]/body[1]/...` 完整位置路径，也不靠全局 `(//...)[1]` 掩盖多匹配。
- 不删除网页或 DOM 元素。“动态过滤”指避开可能变化的定位属性。
- 过滤常见 React/Radix/Element/MUI 等生成 ID、CSS-in-JS class、UUID、时间戳、连续长数字，以及选取模式开始后观察到发生变化的属性。
- class 按词分析：增加/移除 `active` 等状态词不会丢弃未变化的业务 class；长纯字母业务名字不会仅因长度被当作哈希。
- 未观察到变化且只有一个稳定 class 时，使用标签加 `@class`；多个 class 或 class 曾变化时，使用完整词匹配，避免已知状态词恢复后失效。
- 动态识别是启发式判断：无法预知刷新后的所有变化；业务编号、日期文本也可能被保守过滤。用固定业务属性或稳定标签可获得更好的结果。
- 观察从“开始选取”启动，首次访问时已发生的变化依赖规则判断。没有跨刷新学习或永久稳定保证。

## 范围和限制

- Chrome / Edge 119+；暂未提供 Firefox 版本。
- Chrome 设置页、扩展商店和其他浏览器保护页面不允许注入。
- 本地 `file://` 页面须在扩展详情启用“允许访问文件网址”；跨域 frame 必须同时允许扩展访问父子站点。
- 新插入或导航后的 iframe：请重新开始选取；超时会显示错误，不会输出不完整的定位链。
- 本版支持普通 DOM；Shadow DOM 内部目标/iframe 暂不生成定位器，会明确提示。XPath 无法穿透 Shadow DOM；closed Shadow DOM 只能看到宿主元素。
- 自动验证只代表当前页面唯一匹配，不代表刷新后仍然稳定，不代表元素可见、可点击或没有被遮挡。
- 选取时阻止所选 click 的默认行为；某些页面在 pointerdown/mousedown 或更早注册的捕获处理器中也有行为，选取无法撤销这些页面副作用。
- 选择结果只保存在 `chrome.storage.session` 中，关闭浏览器后清除；主页面导航后清除，子 frame 单独导航/DOM 变化后请重新选取。
- 不上传页面数据、不连接外部服务器、不收集输入框 value。文本锚点可能包含业务数据，仍会留在浏览器会话内，复制时由你自行选择用途。
- `<all_urls>` 用于在父页面和跨域 iframe 注入；`scripting` 用于已打开的页面；`webNavigation` 读取 frame 树；`storage` 保存当前标签页结果；`activeTab` 用于当前页面操作。

## 测试

```sh
npm install
npx playwright install chromium
npm test
```

只运行不需要浏览器的动态属性/Robot 转义/iframe 链组合测试：`npm run test:unit`。

截图对应的短 XPath 回归测试：`npm run test:xpath`。这组测试使用 Python 3 + `lxml` 执行 XPath 1.0 引擎（需要时先运行 `python -m pip install lxml`）。测试 DOM 适配器只提供 fixture 树与 XPath，不模拟 CSS 和浏览器事件；完整 `npm test` 也包含这组测试。

运行真实浏览器定位和扩展端到端测试：`npm run test:browser`。可设置 `CHROMIUM_PATH` 指向系统 Chromium（Linux 例：`CHROMIUM_PATH=/usr/bin/chromium npm test`）。扩展端到端测试使用 Chromium，不使用 Chrome/Edge 的扩展侧载限制版本。

还可以打开 `tests/manual.html`：这是不依赖服务器的定位测试页面，页面自动显示 DOM 定位测试结果，也可用插件手工选取表格按钮、输入框和嵌套 iframe。

交付环境的验证结果见 `docs/verification.md`。
