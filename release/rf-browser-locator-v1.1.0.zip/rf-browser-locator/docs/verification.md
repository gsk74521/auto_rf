# 1.1.0 交付验证记录

日期：2026-11-17。

## 已通过

- `node tests/short-xpath.test.cjs`：10 项通过。用真实 libxml2/lxml XPath 1.0 执行生成结果，并验证唯一性及目标身份。涵盖截图结构的工具栏 class + 单局部下标、稳定目标 id 优先、祖先 id 与目标 class 组合、跳过10层包装、重复工具栏限定范围、拒绝无锚点长路径、class 状态变化及恢复、表格行语义轴。
- 这些测试在修复前复现了长全位置路径、遗漏目标 class 候选等失败；状态词恢复的回归也先运行失败，再修复并通过。
- `node tests/unit.test.cjs`：9 项通过。包含动态属性过滤、长业务 class 保留、Robot 转义、iframe 链顺序和不可支持 frame 禁用整链。
- `node tests/background.test.cjs`：3 项通过。使用 Chrome API 边界替身运行真实 service worker，验证导航竞态与正常保存行为。
- 合计22项不需要浏览器 socket 的测试通过。lxml fixture 的 DOM 适配器不模拟 CSS、MutationObserver 调度或 Chrome 扩展 API；class 变化测试直接向观察回调投递边界记录，不能代替浏览器事件集成验证。
- extension 内四个 JavaScript 文件及测试脚本语法检查通过；manual.html 提取出的内联脚本语法检查通过。
- 独立只读代码审查已完成，发现的 class 状态恢复稳定性问题已补回归并修复。

## 完整套件仍受环境权限阻塞

执行命令：`CHROMIUM_PATH=/usr/bin/chromium npm test`。

- `tests/core.test.cjs` 无法启动 Chromium：`setsockopt: Operation not permitted`，浏览器进程在沙箱中退出。
- `tests/extension.test.cjs` 无法启动本地 fixture 服务器：`listen EPERM`。
- 完整套件退出码为1，5个测试文件中3个通过、2个因运行环境阻塞失败。不能声称完整浏览器测试通过。
- 没有在用户的 Chrome/Edge、真实业务网站或 Robot Framework Browser 运行器中实测；用户截图用同类 DOM 结构复现，未取得原网页 DOM。

## 在本机验收

1. 替换 extension 文件夹，在扩展管理页重新加载插件，然后刷新待测网页。旧页面中的旧注入脚本必须通过刷新清除。
2. 按 README 加载后打开 tests/manual.html；如通过文件网址打开，请允许扩展访问文件网址。
3. 查看页面自动 DOM 检查；测试表单输入框、张三行编辑按钮和 class 工具栏。
4. 选取 iframe 内的元素，检查完整定位器保留 iframe 的 >>> 链，每个 frame/目标段独立限制在6步内，最多一个局部下标。
5. 在业务网页复制结果到 Browser 脚本执行；局部下标依赖同级顺序，顺序变化后仍需复查。
6. 有 Node、Python3 和 lxml 时运行 README 中的完整测试命令，补全浏览器验证。
