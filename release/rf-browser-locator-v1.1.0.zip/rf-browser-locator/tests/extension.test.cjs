const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
let server, context, worker, control, base, profile;
before(async () => {
  server = http.createServer((req, res) => {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    const port = server.address().port;
    if (req.url === '/child') res.end('<iframe title="编辑器" src="/inner"></iframe>');
    else if (req.url === '/inner') res.end('<table><tr><td>李四</td><td><button>编辑</button></td></tr><tr><td>张三</td><td><button id="react-132345">编辑</button></td></tr></table>');
    else res.end('<h1>表格演示</h1><iframe name="workspace" src="http://localhost:' + port + '/child"></iframe>');
  });
  await new Promise(resolve => server.listen(0, '0.0.0.0', resolve));
  base = 'http://127.0.0.1:' + server.address().port;
  profile = fs.mkdtempSync(path.join(os.tmpdir(), 'rf-locator-test-'));
  const extension = path.join(__dirname, '../extension');
  context = await chromium.launchPersistentContext(profile, {
    executablePath: process.env.CHROMIUM_PATH || undefined,
    channel: 'chromium', headless: true,
    args: ['--no-sandbox', '--disable-extensions-except=' + extension, '--load-extension=' + extension]
  });
  worker = context.serviceWorkers()[0] || await context.waitForEvent('serviceworker');
  const id = new URL(worker.url()).host;
  control = await context.newPage();
  await control.goto('chrome-extension://' + id + '/popup.html');
});
after(async () => {
  await context?.close();
  if (server) await new Promise(resolve => server.close(resolve));
  if (profile) fs.rmSync(profile, { recursive: true, force: true });
});
test('captures a cross-origin nested iframe target and executes both generated chains', async () => {
  const page = await context.newPage();
  await page.goto(base);
  await page.frameLocator('iframe').frameLocator('iframe').locator('button').last().waitFor();
  const tabId = await worker.evaluate(async url => (await chrome.tabs.query({})).find(t => t.url === url + '/').id, base);
  const reply = await control.evaluate(tabId => chrome.runtime.sendMessage({ type: 'START_PICK', tabId }), tabId);
  assert.equal(reply.ok, true, reply.error);
  await page.frameLocator('iframe').frameLocator('iframe').locator('button').last().click();
  await control.waitForFunction(async tabId => ['ready', 'error'].includes((await chrome.storage.session.get('tab:' + tabId))['tab:' + tabId]?.status), tabId);
  const result = await control.evaluate(async tabId => (await chrome.storage.session.get('tab:' + tabId))['tab:' + tabId], tabId);
  assert.equal(result.status, 'ready', result.message);
  assert.equal(result.frames.length, 2);
  assert.match(result.chains.xpath, /ancestor::tr\/descendant::button/);
  assert.doesNotMatch(result.chains.xpath, /132345/);
  // Browser's >>> is frame selection; validate each emitted segment using Playwright's real engines.
  for (const kind of ['xpath', 'css']) {
    const segments = result.chains[kind].split(' >>> ');
    let scope = page;
    for (const selector of segments.slice(0, -1)) scope = scope.frameLocator(selector);
    const target = scope.locator(segments.at(-1));
    assert.equal(await target.count(), 1);
    assert.equal(await target.evaluate(el => el.closest('tr').querySelector('td').textContent), '张三');
  }
  await page.close();
});
