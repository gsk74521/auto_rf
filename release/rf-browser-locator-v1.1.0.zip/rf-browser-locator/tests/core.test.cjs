const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const fs = require('node:fs');
const path = require('node:path');
let browser, page;
before(async () => { browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined, args: ['--no-sandbox'] }); });
after(async () => { await browser?.close(); });
async function setup(html) {
  page = await browser.newPage();
  await page.setContent(html);
  const file = path.join(__dirname, '../extension/core.js');
  if (fs.existsSync(file)) await page.addScriptTag({ path: file });
}
async function result(target) {
  return page.evaluate(selector => {
    if (!globalThis.LocatorCore) return null;
    const el = document.querySelector(selector);
    const value = LocatorCore.generate(el);
    const css = value.css && document.querySelectorAll(value.css.selector);
    const xp = value.xpath && document.evaluate(value.xpath.selector, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE);
    return { ...value, cssValid: !!css && css.length === 1 && css[0] === el,
      xpathValid: !!xp && xp.snapshotLength === 1 && xp.snapshotItem(0) === el };
  }, target);
}
test('prefers stable test attributes over generated id and class', async () => {
  await setup('<button id="react-923834" class="css-1ab23cd" data-testid="save">保存</button>');
  const r = await result('button');
  assert.ok(r, 'locator generator must exist');
  assert.equal(r.cssValid, true); assert.equal(r.xpathValid, true);
  assert.match(r.css.selector, /data-testid/);
  assert.doesNotMatch(r.css.selector + r.xpath.selector, /923834|1ab23cd/);
  await page.close();
});
test('disambiguates duplicate buttons using a stable ancestor', async () => {
  await setup('<section data-testid="left"><button name="save">保存</button></section><section data-testid="right"><button name="save">保存</button></section>');
  const r = await result('section:last-child button');
  assert.ok(r?.cssValid); assert.ok(r.xpathValid);
  assert.match(r.css.selector, /right/);
  await page.close();
});
test('escapes both quote kinds, backslashes and Unicode in attribute values', async () => {
  await setup('<button>保存</button><button>取消</button>');
  await page.locator('button').first().evaluate(el => el.setAttribute('data-testid', `中文"单'\\值`));
  const r = await result('button');
  assert.ok(r?.cssValid); assert.ok(r.xpathValid);
  await page.close();
});
test('declines paths without semantic anchors instead of emitting a full indexed tree', async () => {
  await setup('<div><i></i><i></i></div><div><i></i><i></i></div>');
  const r = await result('div:last-child i:last-child');
  assert.equal(r.css, null); assert.equal(r.xpath, null);
  assert.ok(r.warnings.length > 0);
  await page.close();
});
test('retains the unchanged toolbar class after a state-class mutation', async () => {
  await setup('<div class="pix-transfer-opbar"><button></button><button></button></div>');
  await page.evaluate(() => LocatorCore.observe(document));
  await page.locator('div').evaluate(el => el.classList.add('active'));
  const r = await result('button');
  assert.ok(r.xpathValid); assert.ok(r.cssValid);
  assert.match(r.xpath.selector, /pix-transfer-opbar/);
  assert.doesNotMatch(r.xpath.selector, /active/);
  await page.close();
});
test('ignores attributes observed changing after inspection starts', async () => {
  await setup('<button id="before" name="submit">保存</button>');
  await page.evaluate(() => globalThis.LocatorCore?.observe(document));
  await page.locator('button').evaluate(el => el.id = 'after');
  const r = await result('button');
  assert.ok(r?.cssValid); assert.ok(r.xpathValid);
  assert.doesNotMatch(r.css.selector + r.xpath.selector, /after/);
  await page.close();
});
test('uses XPath text when attributes are absent and text is unique', async () => {
  await setup('<button>保存</button><button>取消</button>');
  const r = await result('button');
  assert.ok(r?.xpathValid); assert.match(r.xpath.selector, /保存/);
  await page.close();
});
test('rejects shadow-root selectors instead of claiming unverified uniqueness', async () => {
  await setup('<div id="host"></div>');
  const r = await page.evaluate(() => {
    const root = document.querySelector('div').attachShadow({ mode: 'open' });
    root.innerHTML = '<button data-testid="save">Save</button>';
    return globalThis.LocatorCore?.generate(root.querySelector('button'));
  });
  assert.ok(r); assert.equal(r.xpath, null); assert.equal(r.css, null);
  assert.ok(r.warnings.length);
  await page.close();
});
test('Robot escaping preserves literal backslashes, variables, whitespace and comments', async () => {
  await setup('<div></div>');
  const r = await page.evaluate(() => globalThis.LocatorCore?.robotCell('css=[name="${value}  a\\b"] # ok'));
  assert.equal(r, 'css=[name="\\${value}\\x20\\x20a\\\\b"] \\# ok');
  await page.close();
});
test('prefers a readable label axis over an opaque structural input path', async () => {
  await setup('<form><label>用户名</label><input class="css-9f238a"><label>密码</label><input></form>');
  const r = await result('input');
  assert.ok(r?.xpathValid);
  assert.equal(r.xpath.selector, '//label[normalize-space(.)="用户名"]/following-sibling::input[1]');
  await page.close();
});
test('identifies a repeated row action by row text and ancestor axis', async () => {
  await setup('<table><tr><td>李四</td><td><button>编辑</button></td></tr><tr><td>张三</td><td><button>编辑</button></td></tr></table>');
  const r = await result('tr:last-child button');
  assert.ok(r?.xpathValid);
  assert.equal(r.xpath.selector, '//td[normalize-space(.)="张三"]/ancestor::tr/descendant::button[normalize-space(.)="编辑"]');
  await page.close();
});
