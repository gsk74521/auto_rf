const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
function workerHarness({ documentId = 'old', navigate = false } = {}) {
  const data = { 'tab:9': { status: 'picking', sessionId: 'selection-1' } };
  let listener, topologyReads = 0;
  const chrome = {
    runtime: { getURL: () => 'chrome-extension://test/', onMessage: { addListener(fn) { listener = fn; } } },
    storage: { session: {
      async get(key) { return { [key]: data[key] }; },
      async set(values) { Object.assign(data, values); },
      async remove(key) { delete data[key]; }
    } },
    webNavigation: {
      async getAllFrames() {
        topologyReads++;
        if (navigate && topologyReads >= 2) delete data['tab:9'];
        return [{ frameId: 0, parentFrameId: -1, documentId }];
      },
      onCommitted: { addListener() {} }
    },
    tabs: { async sendMessage() { return { ok: true }; }, onRemoved: { addListener() {} } },
    action: { async setBadgeText() {}, async setBadgeBackgroundColor() {} }
  };
  const context = vm.createContext({ chrome, setTimeout, clearTimeout, crypto: globalThis.crypto });
  context.importScripts = file => vm.runInContext(fs.readFileSync(path.join(__dirname, '../extension', file), 'utf8'), context);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../extension/background.js'), 'utf8'), context);
  const target = { css: { selector: 'button' }, xpath: { selector: '//button' }, warnings: [] };
  return {
    data,
    pick: () => new Promise(resolve => listener({ type: 'PICKED', sessionId: 'selection-1', target }, { tab: { id: 9 }, frameId: 0, documentId: 'old', url: 'https://example.com/' }, resolve))
  };
}
test('does not save a selector from a document that has already navigated', async () => {
  const harness = workerHarness({ documentId: 'new' });
  const reply = await harness.pick();
  assert.equal(reply.ok, false);
  assert.notEqual(harness.data['tab:9']?.status, 'ready');
});
test('navigation clearing the session cannot be undone by an in-flight capture', async () => {
  const harness = workerHarness({ navigate: true });
  await harness.pick();
  assert.equal(harness.data['tab:9'], undefined);
});
test('an unchanged document can finish capture successfully', async () => {
  const harness = workerHarness();
  const reply = await harness.pick();
  assert.equal(reply.ok, true);
  assert.equal(harness.data['tab:9'].status, 'ready');
});
