const { test } = require('node:test');
const assert = require('node:assert/strict');
const { fixture } = require('./lxml-fixture.cjs');
globalThis.CSS = { escape: value => value }; // Fixture tags are plain HTML/custom tag names.
globalThis.XPathResult = { ORDERED_NODE_SNAPSHOT_TYPE: 7 };
require('../extension/core.js');
function generate(html, selector) {
  const f = fixture(html), [el] = f.xpath(selector);
  const result = LocatorCore.generate(el);
  if (result.xpath) {
    const nodes = f.xpath(result.xpath.selector);
    assert.equal(nodes.length, 1, result.xpath.selector);
    assert.equal(nodes[0], el, 'must select the originally picked element');
  }
  return result;
}
test('toolbar screenshot: stable class plus one local button index replaces full DOM path', () => {
  const r = generate('<pix-modal-window><div><div><pix-transfer><div><div class="pix-transfer-opbar"><button></button><button></button></div></div></pix-transfer></div></div></pix-modal-window>', '//button[1]');
  assert.equal(r.xpath?.selector, '//div[@class="pix-transfer-opbar"]/button[1]');
  assert.ok(r.warnings.some(w => w.includes('顺序')));
});
test('a target id wins over local positional candidates', () => {
  const r = generate('<div class="pix-transfer-opbar"><button></button><button id="save-order"></button></div>', '//button[@id="save-order"]');
  assert.equal(r.xpath?.selector, '//button[@id="save-order"]');
});
test('combines stable ancestor id with alternate target class when text is ambiguous', () => {
  const r = generate('<section id="editor"><button class="primary">保存</button><button class="secondary">保存</button></section><section><button class="primary">保存</button></section>', '//section[@id="editor"]/button[@class="primary"]');
  assert.ok(r.xpath);
  assert.match(r.xpath.selector, /@id="editor"/);
  assert.match(r.xpath.selector, /@class="primary"/);
  assert.doesNotMatch(r.xpath.selector, /\[\d+\]/);
});
test('finds a distant stable ancestor without emitting all the intervening wrappers', () => {
  const nested = '<div>'.repeat(10) + '<button></button>' + '</div>'.repeat(10);
  const r = generate('<section id="order-editor">' + nested + '</section><section><button></button></section>', '//section[@id="order-editor"]//button');
  assert.ok(r.xpath);
  assert.match(r.xpath.selector, /@id="order-editor"/);
  assert.ok(r.xpath.selector.split('/').filter(Boolean).length <= 6);
  assert.doesNotMatch(r.xpath.selector, /\[\d+\]/);
});
test('declines an unanchored long indexed path rather than presenting it as maintainable', () => {
  const html = '<div>'.repeat(10) + '<button></button><button></button>' + '</div>'.repeat(10);
  const r = generate(html, '//button[1]');
  assert.equal(r.xpath, null);
  assert.ok(r.warnings.length);
});
test('scopes a toolbar class with a stable ancestor before using its local index', () => {
  const html = '<section id="first"><div class="pix-transfer-opbar"><button></button><button></button></div></section><section id="second"><div class="pix-transfer-opbar"><button></button><button></button></div></section>';
  const r = generate(html, '//section[@id="second"]//button[1]');
  assert.ok(r.xpath);
  assert.match(r.xpath.selector, /@id="second"/);
  assert.equal((r.xpath.selector.match(/\[\d+\]/g) || []).length, 1);
  assert.ok(r.xpath.selector.split('/').filter(Boolean).length <= 6);
});
test('uses class token matching when extra transient classes are present', () => {
  const r = generate('<div class="pix-transfer-opbar active"><button></button><button></button></div>', '//button[1]');
  assert.ok(r.xpath);
  assert.match(r.xpath.selector, /pix-transfer-opbar/);
  assert.doesNotMatch(r.xpath.selector, /active/);
});
test('an observed state-class change does not discard the unchanged semantic class', () => {
  let notify;
  globalThis.MutationObserver = class { constructor(callback) { notify = callback; } observe() {} };
  const f = fixture('<div class="pix-transfer-opbar active"><button></button><button></button></div>');
  LocatorCore.observe(f.doc);
  notify([{ target: f.xpath('//div')[0], attributeName: 'class', oldValue: 'pix-transfer-opbar' }]);
  const r = LocatorCore.generate(f.xpath('//button[1]')[0]);
  assert.ok(r.xpath);
  assert.match(r.xpath.selector, /pix-transfer-opbar/);
  assert.doesNotMatch(r.xpath.selector, /active/);
  assert.equal(f.xpath(r.xpath.selector).length, 1);
});
test('removing and restoring a state class preserves the generated token locator', () => {
  let notify;
  globalThis.MutationObserver = class { constructor(callback) { notify = callback; } observe() {} };
  const f = fixture('<div class="pix-transfer-opbar"><button></button><button></button></div>');
  LocatorCore.observe(f.doc);
  notify([{ target: f.xpath('//div')[0], attributeName: 'class', oldValue: 'pix-transfer-opbar active' }]);
  const r = LocatorCore.generate(f.xpath('//button[1]')[0]);
  assert.ok(r.xpath);
  const restored = fixture('<div class="pix-transfer-opbar active"><button></button><button></button></div>');
  assert.equal(restored.xpath(r.xpath.selector).length, 1, 'restoring active must not invalidate the semantic class anchor');
});
test('retains readable row text and ancestor axes when duplicate actions need context', () => {
  const r = generate('<table><tr><td>李四</td><td><button>编辑</button></td></tr><tr><td>张三</td><td><button>编辑</button></td></tr></table>', '//tr[td="张三"]//button');
  assert.equal(r.xpath?.selector, '//td[normalize-space(.)="张三"]/ancestor::tr/descendant::button[normalize-space(.)="编辑"]');
});
