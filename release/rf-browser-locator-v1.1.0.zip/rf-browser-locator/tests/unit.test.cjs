const { test } = require('node:test');
const assert = require('node:assert/strict');
require('../extension/core.js');
const { stable, robotCell, chains } = globalThis.LocatorCore;
test('filters common generated framework IDs and CSS hashes', () => {
  for (const [value, attr] of [['react-923834', 'id'], [':r3:', 'id'], ['css-1ab23cd', 'class'], ['sc-eABxyz', 'class'], ['el-id-323-5', 'id'], ['row-1700000000000', 'id']]) {
    assert.equal(stable(value, attr), false, value);
  }
});
test('retains human-readable IDs, class names and Unicode labels', () => {
  for (const [value, attr] of [['save-button', 'id'], ['btn-primary', 'class'], ['用户名', 'aria-label'], ['account-name', 'data-testid']]) assert.equal(stable(value, attr), true, value);
});
test('does not mistake long business class names for random hashes', () => {
  assert.equal(stable('transferoperationbar', 'class'), true);
  assert.equal(stable('customerManagement', 'id'), true);
  assert.equal(stable('a1b2c3d4e5f6g7h8', 'id'), false);
});
test('filters transient state classes', () => {
  for (const name of ['active', 'is-loading', 'selected', 'disabled']) assert.equal(stable(name, 'class'), false);
});
test('rejects selector-chain delimiters in untrusted attributes', () => {
  assert.equal(stable('hello >>> world', 'title'), false);
  assert.equal(stable('hello >> world', 'title'), false);
});
test('Robot escaping prevents variable interpolation without destroying readability', () => {
  assert.equal(robotCell('xpath=//button[normalize-space(.)="Save draft"]'), 'xpath=//button[normalize-space(.)="Save draft"]');
  assert.equal(robotCell('xpath=//input[@name="${value}"]'), 'xpath=//input[@name="\\${value}"]');
  assert.equal(robotCell('@{list} &{dict} %{env}'), '\\@{list} \\&{dict} \\%{env}');
});
test('Robot escaping retains CSS backslashes, double spaces and line breaks', () => {
  assert.equal(robotCell('css=[name="a\\b  c"]\n\t#'), 'css=[name="a\\\\b\\x20\\x20c"]\\n\\t\\#');
  assert.equal(robotCell(' padded '), '\\x20padded\\x20');
});
test('builds nested iframe chains in outer-to-inner order', () => {
  const target = { css: { selector: 'button' }, xpath: { selector: '//button[normalize-space(.)="保存"]' } };
  const frames = [
    { css: { selector: 'iframe[name="outer"]' }, xpath: { selector: '//iframe[@name="outer"]' } },
    { css: { selector: 'iframe[title="编辑器"]' }, xpath: { selector: '//iframe[@title="编辑器"]' } }
  ];
  assert.deepEqual(chains(target, frames), {
    css: 'css:light=iframe[name="outer"] >>> css:light=iframe[title="编辑器"] >>> css:light=button',
    xpath: 'xpath=//iframe[@name="outer"] >>> xpath=//iframe[@title="编辑器"] >>> xpath=//button[normalize-space(.)="保存"]'
  });
});
test('disables both chains if a shadow-root iframe is unsupported', () => {
  const r = chains({ css: { selector: 'button' }, xpath: { selector: '//button' } }, [{ css: null, xpath: null }]);
  assert.equal(r.xpath, null);
  assert.equal(r.css, null);
});
