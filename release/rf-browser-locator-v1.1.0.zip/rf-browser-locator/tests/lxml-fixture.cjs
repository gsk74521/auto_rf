// A small DOM adapter for running the production XPath generator without browser sockets.
// XPath is evaluated by libxml2/lxml, not by an implementation of our candidate rules.
// This adapter does NOT emulate CSS or MutationObserver; browser tests cover those contracts.
const { spawnSync } = require('node:child_process');
const python = `import json,sys
from lxml import html,etree
data=json.loads(sys.argv[1])
root=html.document_fromstring(data['html'])
nodes=list(root.iter())
ids={el:i for i,el in enumerate(nodes)}
if data['op']=='tree':
 print(json.dumps([{'id':i,'tag':el.tag,'attrs':dict(el.attrib),'text':''.join(el.itertext()),'children':[ids[c] for c in el if isinstance(c.tag,str)],'parent':ids.get(el.getparent())} for i,el in enumerate(nodes) if isinstance(el.tag,str)]))
else:
 result=root.xpath(data['xpath'])
 print(json.dumps([ids[el] for el in result if isinstance(el,etree._Element)]))
`;
function execute(value) {
  const result = spawnSync('python', ['-c', python, JSON.stringify(value)], { encoding: 'utf8', timeout: 10000 });
  if (result.status !== 0) throw new Error(result.stderr || result.error?.message || 'lxml fixture failed');
  return JSON.parse(result.stdout);
}
function fixture(html) {
  const tree = execute({ op: 'tree', html });
  const byId = new Map(), cache = new Map();
  const doc = {
    nodeType: 9,
    evaluate(selector) {
      if (!cache.has(selector)) cache.set(selector, execute({ op: 'xpath', html, xpath: selector }));
      const values = cache.get(selector).map(id => byId.get(id));
      return { snapshotLength: values.length, snapshotItem: index => values[index] };
    },
    querySelectorAll(selector) { return select([...byId.values()], selector); }
  };
  function select(nodes, selector) {
    if (!/^[a-z0-9,-]+$/i.test(selector)) throw new Error('CSS selectors are outside this adapter’s scope');
    const tags = selector.split(','); return nodes.filter(el => tags.includes(el.localName));
  }
  for (const data of tree) {
    const el = {
      nodeType: 1, localName: data.tag, namespaceURI: 'http://www.w3.org/1999/xhtml',
      ownerDocument: doc, isConnected: true, textContent: data.text,
      classList: (data.attrs.class || '').split(/\s+/).filter(Boolean),
      attributes: Object.entries(data.attrs).map(([name, value]) => ({ name, value })),
      getAttribute(name) { return data.attrs[name] ?? null; },
      getRootNode() { return doc; },
      contains(other) { for (let node = other; node; node = node.parentElement) if (node === this) return true; return false; },
      querySelectorAll(selector) { return select([...byId.values()].filter(node => node !== this && this.contains(node)), selector); }
    };
    byId.set(data.id, el);
  }
  for (const data of tree) {
    const el = byId.get(data.id);
    el.children = data.children.map(id => byId.get(id));
    el.parentElement = byId.get(data.parent) || null;
    el.parentNode = el.parentElement || doc;
    const siblings = el.parentElement?.children || [el];
    const index = siblings.indexOf(el);
    el.previousElementSibling = siblings[index - 1] || null;
    el.nextElementSibling = siblings[index + 1] || null;
  }
  doc.documentElement = byId.get(0);
  doc.children = [doc.documentElement];
  doc.body = [...byId.values()].find(el => el.localName === 'body');
  return {
    doc,
    xpath(selector) { const r = doc.evaluate(selector); return Array.from({ length: r.snapshotLength }, (_, i) => r.snapshotItem(i)); }
  };
}
module.exports = { fixture };
