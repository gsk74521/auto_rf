importScripts('core.js');
const pending = new Map();
const key = tabId => 'tab:' + tabId;
async function state(tabId, value) { await chrome.storage.session.set({ [key(tabId)]: value }); }
async function broadcast(tabId, type, extra = {}) {
  const frames = await chrome.webNavigation.getAllFrames({ tabId }) || [];
  return Promise.allSettled(frames.map(frame => chrome.tabs.sendMessage(tabId, { type, ...extra }, { frameId: frame.frameId })));
}
async function start(tabId) {
  // Also supports tabs opened before the extension was installed or reloaded.
  await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ['core.js', 'content.js'] });
  const sessionId = crypto.randomUUID();
  await state(tabId, { status: 'picking', sessionId, message: '点击目标元素；Esc 取消。' });
  const results = await broadcast(tabId, 'START', { sessionId });
  if (!results.some(r => r.status === 'fulfilled')) throw new Error('无法访问此页面，请刷新普通网页后重试。');
  return { ok: true };
}
async function frameSelector(tabId, childInfo, parentInfo) {
  const token = crypto.randomUUID();
  let timer;
  const result = new Promise((resolve, reject) => {
    timer = setTimeout(() => { pending.delete(token); reject(new Error('无法识别 iframe 的父页面。请确认扩展有父子页面访问权限，并重新选取。')); }, 3000);
    pending.set(token, { tabId, parent: parentInfo.frameId, documentId: parentInfo.documentId, resolve, reject });
  });
  try {
    await chrome.tabs.sendMessage(tabId, { type: 'MARK_FRAME', token }, { documentId: childInfo.documentId });
    return await result;
  } finally { clearTimeout(timer); pending.delete(token); }
}
async function capture(message, sender) {
  const tabId = sender.tab.id;
  const old = (await chrome.storage.session.get(key(tabId)))[key(tabId)];
  if (old?.status !== 'picking' || old.sessionId !== message.sessionId) return { ok: false };
  await state(tabId, { status: 'resolving', sessionId: old.sessionId, message: '正在拼接 iframe 定位链…' });
  await broadcast(tabId, 'STOP');
  const topology = await chrome.webNavigation.getAllFrames({ tabId }) || [];
  if (!sender.documentId || topology.find(frame => frame.frameId === sender.frameId)?.documentId !== sender.documentId) throw new Error('目标文档已导航，请重新选取。');
  const frames = [];
  let current = sender.frameId;
  const seen = new Set();
  while (current !== 0) {
    if (seen.has(current)) throw new Error('iframe 结构已变化，请重新选取。');
    seen.add(current);
    const info = topology.find(frame => frame.frameId === current);
    if (!info || info.parentFrameId < 0) throw new Error('目标 iframe 已导航，请重新选取。');
    const parentInfo = topology.find(frame => frame.frameId === info.parentFrameId);
    if (!info.documentId || !parentInfo?.documentId) throw new Error('无法确认 iframe 文档身份，请重新选取。');
    frames.unshift(await frameSelector(tabId, info, parentInfo));
    current = info.parentFrameId;
  }
  const target = message.target;
  const chains = LocatorCore.chains(target, frames);
  const warnings = [...new Set([...frames, target].flatMap(item => item.warnings))];
  const latestTopology = await chrome.webNavigation.getAllFrames({ tabId }) || [];
  for (const frameId of [sender.frameId, ...seen, 0]) {
    if (topology.find(frame => frame.frameId === frameId)?.documentId !== latestTopology.find(frame => frame.frameId === frameId)?.documentId) throw new Error('解析期间页面已导航，请重新选取。');
  }
  const latest = (await chrome.storage.session.get(key(tabId)))[key(tabId)];
  if (latest?.sessionId !== old.sessionId || latest.status !== 'resolving') return { ok: false };
  await state(tabId, { status: 'ready', sessionId: old.sessionId, target, frames, chains, warnings, capturedAt: Date.now() });
  const usable = chains.xpath || chains.css;
  await chrome.action.setBadgeText({ tabId, text: usable ? '✓' : '!' });
  await chrome.action.setBadgeBackgroundColor({ tabId, color: usable ? '#23725c' : '#a66b16' });
  return { ok: true };
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message.type === 'FRAME_RESULT') {
    const task = pending.get(message.token);
    if (task && sender.tab?.id === task.tabId && sender.frameId === task.parent && sender.documentId === task.documentId) {
      if (message.error) task.reject(new Error(message.error)); else task.resolve(message.target);
    }
    respond({ ok: true }); return;
  }
  const run = async () => {
    if (message.type === 'START_PICK' && sender.url?.startsWith(chrome.runtime.getURL(''))) return start(message.tabId);
    if (message.type === 'STOP_PICK') {
      const tabId = sender.url?.startsWith(chrome.runtime.getURL('')) ? message.tabId : sender.tab?.id;
      await broadcast(tabId, 'STOP');
      await state(tabId, { status: 'idle', message: '已取消选取。' }); return { ok: true };
    }
    if (message.type === 'PICKED' && sender.tab) return capture(message, sender);
    return { ok: false };
  };
  run().then(respond).catch(async error => {
    const tabId = sender.url?.startsWith(chrome.runtime.getURL('')) ? message.tabId : sender.tab?.id;
    if (Number.isInteger(tabId)) {
      if (message.type === 'PICKED') {
        const latest = (await chrome.storage.session.get(key(tabId)))[key(tabId)];
        if (latest?.sessionId !== message.sessionId) { respond({ ok: false, error: error.message }); return; }
      }
      await broadcast(tabId, 'STOP').catch(() => {});
      await state(tabId, { status: 'error', message: error.message });
    }
    respond({ ok: false, error: error.message });
  });
  return true;
});
chrome.webNavigation.onCommitted.addListener(async details => {
  if (details.frameId === 0) {
    await chrome.storage.session.remove(key(details.tabId));
    await chrome.action.setBadgeText({ tabId: details.tabId, text: '' }).catch(() => {});
  }
});
chrome.tabs.onRemoved.addListener(tabId => chrome.storage.session.remove(key(tabId)));
