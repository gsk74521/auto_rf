(() => {
  if (globalThis.__rfLocatorInstalled) return;
  globalThis.__rfLocatorInstalled = true;
  let picking = false, host = null, box = null, hint = null, sessionId = null;
  const knownRoots = new WeakSet();
  function watch(root) {
    if (knownRoots.has(root)) return;
    knownRoots.add(root); LocatorCore.observe(root);
  }
  function stop() {
    picking = false;
    document.removeEventListener('pointermove', move, true);
    document.removeEventListener('click', click, true);
    document.removeEventListener('keydown', keydown, true);
    host?.remove(); host = null;
  }
  function start() {
    stop(); picking = true; watch(document);
    host = document.createElement('div');
    host.style.cssText = 'all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;pointer-events:none!important;';
    const root = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = '.box{position:fixed;box-sizing:border-box;border:2px solid #28b98b;background:#28b98b18;display:none}.hint{position:fixed;top:12px;left:12px;padding:10px 14px;background:#12382f;color:white;border-radius:8px;font:13px/1.5 system-ui;box-shadow:0 4px 18px #0003;max-width:420px}';
    box = document.createElement('div'); box.className = 'box';
    hint = document.createElement('div'); hint.className = 'hint'; hint.textContent = 'XPath 定位器 · 点击目标元素 · Esc 取消';
    root.append(style, box, hint); document.documentElement.append(host);
    document.addEventListener('pointermove', move, true);
    document.addEventListener('click', click, true);
    document.addEventListener('keydown', keydown, true);
  }
  function element(event) { return event.composedPath().find(node => node?.nodeType === 1); }
  function move(event) {
    const el = element(event); if (!el || !box) return;
    if (el.getRootNode().host) watch(el.getRootNode());
    const rect = el.getBoundingClientRect();
    Object.assign(box.style, { display: 'block', left: rect.left + 'px', top: rect.top + 'px', width: rect.width + 'px', height: rect.height + 'px' });
    hint.textContent = '<' + el.localName + '> · 点击选取 · Esc 取消';
  }
  function click(event) {
    if (!picking) return;
    event.preventDefault(); event.stopImmediatePropagation();
    const el = element(event);
    try {
      const target = LocatorCore.generate(el); stop();
      chrome.runtime.sendMessage({ type: 'PICKED', target, sessionId }).catch(() => {});
    } catch (error) { if (hint) hint.textContent = error.message; }
  }
  function keydown(event) {
    if (event.key === 'Escape') {
      event.preventDefault(); event.stopImmediatePropagation(); stop();
      chrome.runtime.sendMessage({ type: 'STOP_PICK' }).catch(() => {});
    }
  }
  // event.source identifies the actual child browsing context, including cross-origin frames.
  window.addEventListener('message', event => {
    if (event.data?.type !== '__RF_LOCATOR_FRAME__' || typeof event.data.token !== 'string') return;
    const frames = [];
    function collect(root) {
      frames.push(...root.querySelectorAll('iframe,frame'));
      for (const el of root.querySelectorAll('*')) if (el.shadowRoot) collect(el.shadowRoot);
    }
    collect(document);
    const frame = frames.find(el => el.contentWindow === event.source);
    if (!frame) return;
    try {
      chrome.runtime.sendMessage({ type: 'FRAME_RESULT', token: event.data.token, target: LocatorCore.generate(frame) }).catch(() => {});
    } catch (error) {
      chrome.runtime.sendMessage({ type: 'FRAME_RESULT', token: event.data.token, error: error.message }).catch(() => {});
    }
  });
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (message.type === 'START') { sessionId = message.sessionId; start(); }
    if (message.type === 'STOP') stop();
    if (message.type === 'MARK_FRAME' && window !== window.parent) window.parent.postMessage({ type: '__RF_LOCATOR_FRAME__', token: message.token }, '*');
    respond({ ok: true });
  });
})();
