# 交付验证记录

日期：2026-11-16。

## 已通过

- `node tests/unit.test.cjs`：8 项通过。包含动态属性过滤、Robot 转义、嵌套 iframe 链顺序、不可支持的 frame 禁用整链。
- `node tests/background.test.cjs`：3 项通过。使用 Chrome API 边界替身运行真实 service worker，验证旧文档拒绝保存、导航清除会话后旧 capture 不恢复结果、正常文档保存成功。
- 两项导航竞态测试先在修复前运行并失败，再在修复后运行并通过。
- `node --check`：extension 内四个 JavaScript 文件、浏览器测试脚本以及 manual.html 提取出的内联脚本语法检查通过。
- manifest.json JSON 解析和 popup/service worker/content script 入口文件存在性检查通过。
- 独立只读代码审查：已处理 CSS 作用域语义错配及导航竞态两项重要问题。

## 未通过运行环境前提，不能视为已通过

完整测试命令：`CHROMIUM_PATH=/usr/bin/chromium npm test`。

- `tests/core.test.cjs`（10 项 DOM 定位测试）无法启动 Chromium：`setsockopt: Operation not permitted`，浏览器进程在沙箱中退出。
- `tests/extension.test.cjs`（跨域嵌套 iframe 扩展端到端测试）无法启动本地 fixture 服务器：`listen EPERM`。
- 完整套件退出码为 1。这是环境权限阻塞，不能据此声称插件浏览器实测成功。
- 没有在用户的 Chrome/Edge、真实业务网站或 Robot Framework Browser 运行器中实测。
- 后台边界测试不替代真实嵌套 frame 回包、浏览器扩展权限、DOM 引擎以及 Robot 参数解析的集成验证。

## 在本机验收

1. 按 README 加载 extension 文件夹，打开 tests/manual.html。先允许扩展访问文件网址。
2. 查看页面自动 DOM 检查；选取用户名输入框和张三行的“编辑”，检查 XPath 语义。
3. 选取两层 iframe 内的保存按钮，检查完整定位器包含两次 `>>>`。
4. 打开实际业务网页（含跨域 iframe），选取并复制操作语句到 Browser 脚本执行。
5. 有 Node 环境时运行 `npm install`、`npx playwright install chromium` 和 `npm test`，补全自动浏览器验证。

本地 DOM 验收页和浏览器套件已提供，交付环境中没有将未运行的检查记为通过。
