/* Shared by the isolated content world and the extension popup. No page code is executed. */
(() => {
  'use strict';
  if (globalThis.LocatorCore) return;
  const changed = new WeakMap();
  const observers = new WeakMap();
  const attrs = ['data-testid', 'data-test', 'data-test-id', 'data-cy', 'id', 'name', 'aria-label', 'placeholder', 'title', 'alt', 'role'];
  function observe(root) {
    if (observers.has(root)) return;
    const observer = new MutationObserver(records => {
      for (const record of records) {
        const names = changed.get(record.target) || new Set();
        names.add(record.attributeName); changed.set(record.target, names);
      }
    });
    observer.observe(root, { subtree: true, attributes: true });
    observers.set(root, observer);
  }
  function stable(value, name = '') {
    if (!value || value.length > 150 || /[\r\n\t]|>>>|>>/.test(value)) return false;
    if (/\d{4,}|[a-f0-9]{8}-[a-f0-9-]{20,}/i.test(value)) return false;
    if (/^(?:react|radix|headlessui|ember|mui|rc[-_]|:r\w+:|el-id-|ext-gen|mat-input-|cdk-)/i.test(value)) return false;
    if (name === 'class' && /^(?:css-|sc-|jsx-|jss\d|_[A-Za-z0-9_-]{5})|(?:active|selected|hover|focus|disabled|loading|open|hidden|visible)$/i.test(value)) return false;
    if (['id', 'class'].includes(name) && /(?:^|[-_])[a-f0-9]{6,}(?:$|[-_])|[a-z0-9]{14,}/i.test(value)) return false;
    return true;
  }
  const cssString = value => '"' + value.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/[\x00-\x1f\x7f]/g, c => '\\' + c.charCodeAt(0).toString(16) + ' ') + '"';
  function literal(value) {
    if (!value.includes('"')) return '"' + value + '"';
    if (!value.includes("'")) return "'" + value + "'";
    return 'concat(' + value.split('"').map(part => '"' + part + '"').join(',\'"\',') + ')';
  }
  const tag = el => el.localName;
  const nodeTest = el => /^[a-z][a-z0-9-]*$/i.test(tag(el)) && el.namespaceURI === 'http://www.w3.org/1999/xhtml' ? tag(el) : '*[local-name()=' + literal(tag(el)) + ']';
  const text = el => (el.textContent || '').replace(/[\x20\t\r\n]+/g, ' ').trim();
  function usefulText(el) {
    const value = text(el);
    return value && value.length <= 70 && !/\d{4,}|>>>|>>|\$\{|@\{|%\{|&\{/.test(value) && el.children.length <= 3 ? value : '';
  }
  function tokens(el) {
    if (changed.get(el)?.has('class')) return [];
    return [...el.classList].filter(value => stable(value, 'class')).slice(0, 4);
  }
  function attributes(el) {
    return attrs.filter(name => !changed.get(el)?.has(name) && stable(el.getAttribute(name), name)).map(name => [name, el.getAttribute(name)]);
  }
  function cssAtoms(el) {
    const t = CSS.escape(tag(el));
    const values = attributes(el).map(([name, value], index) => ({ selector: t + '[' + name + '=' + cssString(value) + ']', score: index + 2, reason: '稳定属性 ' + name }));
    const classes = tokens(el);
    for (const value of classes) values.push({ selector: t + '[class~=' + cssString(value) + ']', score: 25, reason: '稳定 class' });
    if (classes.length > 1) values.push({ selector: t + classes.map(v => '[class~=' + cssString(v) + ']').join(''), score: 26, reason: '稳定 class 组合' });
    values.push({ selector: t, score: 45, reason: '唯一标签' });
    return values;
  }
  function xpathAtoms(el) {
    const t = nodeTest(el), values = [];
    const value = usefulText(el);
    if (value) values.push({ selector: t + '[normalize-space(.)=' + literal(value) + ']', score: 7, reason: '元素文本' });
    for (const [name, val] of attributes(el)) {
      const score = name === 'id' ? 8 : name.startsWith('data-') ? 10 : 15;
      values.push({ selector: t + '[@' + name + '=' + literal(val) + ']', score, reason: '稳定属性 ' + name });
      if (value) values.push({ selector: t + '[@' + name + '=' + literal(val) + ' and normalize-space(.)=' + literal(value) + ']', score: score + 2, reason: '稳定属性和文本' });
    }
    for (const value of tokens(el)) values.push({ selector: t + '[contains(concat(" ", normalize-space(@class), " "), ' + literal(' ' + value + ' ') + ')]', score: 25, reason: '完整 class 词匹配' });
    values.push({ selector: t, score: 50, reason: '唯一标签' });
    return values;
  }
  function cssMatches(root, selector) { try { return [...root.querySelectorAll(selector)]; } catch { return []; } }
  function xpathMatches(doc, selector) {
    try {
      const r = doc.evaluate(selector, doc, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
      return Array.from({ length: r.snapshotLength }, (_, i) => r.snapshotItem(i));
    } catch { return []; }
  }
  function choose(candidates, el, query) {
    return candidates.sort((a, b) => a.score - b.score || a.selector.length - b.selector.length).find(c => {
      const result = query(c.selector);
      return result.length === 1 && result[0] === el;
    });
  }
  function structural(el, kind) {
    const parts = [];
    for (let cur = el; cur?.nodeType === 1; cur = cur.parentElement) {
      const siblings = [...(cur.parentNode?.children || [])].filter(other => other.localName === cur.localName && other.namespaceURI === cur.namespaceURI);
      const index = siblings.indexOf(cur) + 1;
      parts.unshift(kind === 'css' ? CSS.escape(tag(cur)) + ':nth-of-type(' + index + ')' : nodeTest(cur) + '[' + index + ']');
    }
    return kind === 'css' ? parts.join(' > ') : '/' + parts.join('/');
  }
  function generate(el) {
    if (!el || el.nodeType !== 1 || !el.isConnected) throw new Error('目标元素已离开页面，请重新选取。');
    const root = el.getRootNode(), doc = el.ownerDocument, warnings = [];
    if (root.nodeType !== 9) return { css: null, xpath: null, warnings: ['目标位于 Shadow DOM；此版本暂不生成定位器，请选择普通 DOM 元素。'], ignored: [], tag: tag(el), text: usefulText(el) };
    const cssCandidates = cssAtoms(el);
    const xpCandidates = xpathAtoms(el).map(c => ({ ...c, selector: '//' + c.selector }));
    const targetXp = xpathAtoms(el).sort((a, b) => a.score - b.score)[0].selector;
    let depth = 0;
    for (let parent = el.parentElement; parent && depth < 6; parent = parent.parentElement, depth++) {
      if (parent === doc.body || parent === doc.documentElement) break;
      for (const anchor of cssAtoms(parent).filter(a => a.score < 40)) {
        for (const target of cssAtoms(el)) cssCandidates.push({ selector: anchor.selector + ' ' + target.selector, score: 55 + depth + target.score, reason: '稳定祖先限定范围' });
      }
      for (const anchor of xpathAtoms(parent).filter(a => a.score < 40)) xpCandidates.push({ selector: '//' + anchor.selector + '/descendant::' + targetXp, score: 40 + depth + anchor.score, reason: '稳定祖先限定范围' });
      // A readable heading/cell acts as the anchor; the final uniqueness check rejects ambiguous rows.
      const anchors = [...parent.querySelectorAll('td,th,h1,h2,h3,h4,legend,label,dt')].slice(0, 40);
      for (const anchor of anchors) {
        if (anchor.contains(el) || el.contains(anchor) || !usefulText(anchor)) continue;
        xpCandidates.push({ selector: '//' + nodeTest(anchor) + '[normalize-space(.)=' + literal(usefulText(anchor)) + ']/ancestor::' + nodeTest(parent) + '/descendant::' + targetXp,
          score: 27 + depth, reason: '文本锚点 → ancestor → descendant' });
      }
    }
    for (const sibling of [el.previousElementSibling, el.nextElementSibling]) {
      if (!sibling || !['label', 'span', 'dt', 'strong'].includes(tag(sibling)) || !usefulText(sibling)) continue;
      const previous = sibling === el.previousElementSibling;
      xpCandidates.push({ selector: '//' + nodeTest(sibling) + '[normalize-space(.)=' + literal(usefulText(sibling)) + ']/' + (previous ? 'following-sibling::' : 'preceding-sibling::') + nodeTest(el) + '[1]', score: previous ? 5 : 6, reason: '相邻文本和兄弟轴（最近匹配元素）' });
    }
    let css = choose(cssCandidates, el, selector => cssMatches(root, selector));
    if (!css) { css = { selector: structural(el, 'css'), reason: '位置兜底', score: 200 }; warnings.push('CSS 使用位置序号；插入或重排同级元素后需要复查。'); }
    let xpath = null;
    if (root.nodeType === 9) {
      xpath = choose(xpCandidates, el, selector => xpathMatches(doc, selector));
      if (!xpath) { xpath = { selector: structural(el, 'xpath'), reason: '位置兜底', score: 200 }; warnings.push('XPath 使用位置序号；建议为页面增加稳定属性或文本锚点。'); }
    } else {
      warnings.push('目标位于 Shadow DOM；本版本不提供定位器。');
    }
    const ignored = [...el.attributes].filter(a => ['id', 'class', ...attrs].includes(a.name) && (changed.get(el)?.has(a.name) || !stable(a.value, a.name))).map(a => a.name);
    return { css: { ...css, count: 1 }, xpath: xpath && { ...xpath, count: 1 }, warnings, ignored, tag: tag(el), text: usefulText(el) };
  }
  function robotCell(value) {
    return value.replace(/\\/g, '\\\\').replace(/([$@&%])\{/g, '\\$1{').replace(/#/g, '\\#').replace(/ {2,}|^ +| +$/g, spaces => '\\x20'.repeat(spaces.length)).replace(/\t/g, '\\t').replace(/\r/g, '\\r').replace(/\n/g, '\\n');
  }
  function chains(target, frames) {
    const all = [...frames, target];
    return {
      // Browser/Playwright's plain css= also pierces open shadow roots. css:light= matches our native DOM validation exactly.
      css: all.every(item => item.css) ? all.map(item => 'css:light=' + item.css.selector).join(' >>> ') : null,
      xpath: all.every(item => item.xpath) ? all.map(item => 'xpath=' + item.xpath.selector).join(' >>> ') : null
    };
  }
  globalThis.LocatorCore = { generate, observe, robotCell, chains, stable };
})();
