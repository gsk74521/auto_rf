'use strict';
const $ = id => document.getElementById(id);
let tabId, current, mode = 'xpath';
function render(value) {
  current = value;
  $('result').hidden = value?.status !== 'ready';
  $('status').textContent = value?.message || (value?.status === 'ready' ? '已生成定位器。选取时已阻止本次 click 默认行为。' : '点击选取，再回到这里复制定位器。');
  $('pick').textContent = value?.status === 'picking' ? '取消选取' : '⊕ 开始选取元素';
  if (value?.status !== 'ready') return;
  $('target').textContent = '<' + value.target.tag + '> ' + (value.target.text || '');
  $('depth').textContent = value.frames.length ? value.frames.length + ' 层 iframe' : '主页面';
  const raw = value.chains[mode];
  const cell = raw && LocatorCore.robotCell(raw);
  $('locator').value = cell || (value.chains.css ? '此目标不支持 XPath；请切换到 CSS。' : '此目标的 DOM 边界暂不受支持，请重新选取。');
  const keyword = $('keyword').value;
  const suffix = keyword === 'Fill Text' ? '    在此输入文本' : keyword === 'Wait For Elements State' ? '    visible' : '';
  $('snippet').value = cell ? keyword + '    ' + cell + suffix : '';
  $('copyLocator').disabled = !raw; $('copySnippet').disabled = !raw;
  $('raw').textContent = raw || '此定位类型不可用。';
  $('reasons').replaceChildren();
  for (const [index, item] of [...value.frames, value.target].entries()) {
    const li = document.createElement('li');
    li.textContent = (index < value.frames.length ? 'iframe ' + (index + 1) : '目标') + '：' + (item[mode]?.reason || '不支持') + '；过滤属性：' + (item.ignored.join('、') || '无');
    $('reasons').append(li);
  }
  $('warnings').replaceChildren();
  for (const warning of value.warnings) { const li = document.createElement('li'); li.textContent = warning; $('warnings').append(li); }
  $('xpathTab').classList.toggle('active', mode === 'xpath'); $('cssTab').classList.toggle('active', mode === 'css');
}
async function copy(id) {
  try { await navigator.clipboard.writeText($(id).value); $('status').textContent = '已复制。'; }
  catch { $(id).focus(); $(id).select(); $('status').textContent = '请按 Ctrl+C（macOS：⌘C）复制已选中的文本。'; }
}
$('copyLocator').addEventListener('click', () => copy('locator'));
$('copySnippet').addEventListener('click', () => copy('snippet'));
$('keyword').addEventListener('change', () => render(current));
$('xpathTab').addEventListener('click', () => { mode = 'xpath'; render(current); });
$('cssTab').addEventListener('click', () => { mode = 'css'; render(current); });
$('pick').addEventListener('click', async () => {
  if (!Number.isInteger(tabId)) return;
  $('pick').disabled = true;
  try {
    const reply = await chrome.runtime.sendMessage({ type: current?.status === 'picking' ? 'STOP_PICK' : 'START_PICK', tabId });
    if (!reply.ok) throw new Error(reply.error || '无法选取元素。');
    window.close();
  } catch (error) { $('status').textContent = '选取失败：' + error.message + ' 浏览器设置页、扩展商店等受保护页面无法使用。'; }
  finally { $('pick').disabled = false; }
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'session' && changes['tab:' + tabId]) render(changes['tab:' + tabId].newValue);
});
(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab?.id;
  if (Number.isInteger(tabId)) render((await chrome.storage.session.get('tab:' + tabId))['tab:' + tabId]);
})();
