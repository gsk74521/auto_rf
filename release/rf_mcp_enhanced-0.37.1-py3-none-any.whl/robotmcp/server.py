"""Main MCP Server implementation for Robot Framework integration."""

import argparse
import asyncio
import logging
import os
import re
import threading
import time
from contextlib import asynccontextmanager
from dataclasses import asdict
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Literal, Optional, Union

from fastmcp import Context, FastMCP

from robotmcp.compat.fastmcp_compat import (
    DISABLED_TOOL_KWARGS,
    FASTMCP_V3,
    finalize_disabled_tools,
    get_tool_fn,
    set_server_lifespan,
)

from robotmcp.components.execution import ExecutionCoordinator
from robotmcp.components.execution.external_rf_client import ExternalRFClient
from robotmcp.components.execution.mobile_capability_service import (
    MobileCapabilityService,
)
from robotmcp.components.execution.rf_native_context_manager import (
    get_rf_native_context_manager,
)
from robotmcp.components.keyword_matcher import KeywordMatcher
from robotmcp.components.library_recommender import LibraryRecommender
from robotmcp.components.nlp_processor import NaturalLanguageProcessor
from robotmcp.components.state_manager import StateManager
from robotmcp.components.test_builder import TestBuilder
from robotmcp.config import library_registry
from robotmcp.domains.instruction import FastMCPInstructionAdapter
from robotmcp.domains.shared.kernel import (
    AttachAction,
    AutomationContext,
    CoercedStringList,
    CoercedVariables,
    DetailLevel,
    ExecutionMode,
    ExtractMode,
    FilteringLevel,
    FlowStructure,
    IntentVerb,
    KeywordStrategy,
    ModelTierLiteral,
    OptionalCoercedStringList,
    PluginAction,
    RecommendMode,
    SelectMatch,
    SessionAction,
    SuiteRunMode,
    TestStatus,
    ToolProfileName,
    ValidationLevel,
    extract_deprecation_suggestion,
    resolve_deprecated_alias,
)
from robotmcp.models.session_models import PlatformType
from robotmcp.optimization.instruction_hooks import InstructionLearningHooks
from robotmcp.plugins import get_library_plugin_manager
from robotmcp.utils.server_integration import initialize_enhanced_serialization

logger = logging.getLogger(__name__)

# Initialize instruction learning hooks singleton
_instruction_hooks: Optional[InstructionLearningHooks] = None

# ADR-006/007/008 singletons (initialized lazily)
_tool_manager_adapter = None
_tool_profile_manager = None
_intent_registry = None
_intent_resolver = None
_intent_action_adapter = None
_response_optimization_configs: Dict[str, Any] = {}  # session_id -> ResponseOptimizationConfig


# ADR-014: Memory hook service singleton
_memory_hook_service: Any = None  # None=uninitialized, False=disabled
# ADR-014.2: Track pending memory writes so they aren't lost on shutdown
_pending_memory_tasks: set = set()


def _get_memory_hook_service():
    """Get or initialize the memory hook service (lazy, fire-once)."""
    global _memory_hook_service
    if _memory_hook_service is False:
        return None
    if _memory_hook_service is None:
        try:
            from robotmcp.domains.memory.services import create_memory_services

            services = create_memory_services()
            if services is None:
                _memory_hook_service = False
                return None
            _memory_hook_service = services["hook_service"]
        except Exception as exc:
            logger.debug("Memory service init failed: %s", exc)
            _memory_hook_service = False
            return None
    return _memory_hook_service


def _get_instruction_hooks() -> InstructionLearningHooks:
    """Get or initialize the instruction learning hooks.

    Returns:
        The singleton InstructionLearningHooks instance
    """
    global _instruction_hooks
    if _instruction_hooks is None:
        _instruction_hooks = InstructionLearningHooks.get_instance()
    return _instruction_hooks


def _track_tool_result(
    session_id: str,
    tool_name: str,
    arguments: Dict[str, Any],
    result: Dict[str, Any],
) -> None:
    """Track a tool call result for instruction learning.

    Args:
        session_id: Session identifier
        tool_name: Name of the tool that was called
        arguments: Arguments passed to the tool
        result: Result dictionary from the tool
    """
    try:
        hooks = _get_instruction_hooks()
        success = result.get("success", True)
        error = result.get("error") if not success else None
        hooks.on_tool_call(session_id, tool_name, arguments, success, error, result)
    except Exception as e:
        # Don't let learning errors affect tool execution
        logger.debug(f"Instruction learning tracking error: {e}")

    # ADR-014.2: tracked memory dispatch (tasks survive until done)
    try:
        mem_svc = _get_memory_hook_service()
        if mem_svc is not None:
            import asyncio

            task = asyncio.ensure_future(
                mem_svc.on_tool_call(session_id, tool_name, arguments, result)
            )
            _pending_memory_tasks.add(task)
            task.add_done_callback(_pending_memory_tasks.discard)
    except Exception:
        pass  # Never let memory errors affect tool execution


async def _augment_with_memory(
    session_id: str,
    tool_name: str,
    arguments: Dict[str, Any],
    result: Dict[str, Any],
) -> Dict[str, Any]:
    """ADR-014.2: Augment tool result with memory hints (inline, not fire-and-forget).

    Injects relevant memory context into tool responses so the LLM sees it
    without needing to call recall tools.  Returns the original result
    unchanged on any error or if memory is unavailable.
    """
    import asyncio

    mem_svc = _get_memory_hook_service()
    if mem_svc is None:
        return result
    try:
        return await asyncio.wait_for(
            mem_svc.augment_response(tool_name, arguments, result),
            timeout=0.05,  # 50ms max
        )
    except Exception:
        return result


def _externalize_response(
    tool_name: str,
    session_id: str,
    response: Dict[str, Any],
) -> Dict[str, Any]:
    """Apply artifact externalization to a tool response (ADR-015).

    Replaces large fields matching externalization rules with compact
    artifact references.  The caller can then use ``fetch_artifact``
    to retrieve the full content.

    Returns the (possibly modified) response.  Never raises.
    """
    try:
        from robotmcp.container import get_container

        svc = get_container().artifact_externalization_service
        from robotmcp.domains.artifact_output.value_objects import OutputMode

        if svc.mode == OutputMode.INLINE:
            return response
        response, results = svc.externalize(tool_name, response, session_id)
        if results:
            logger.debug(
                "Externalized %d field(s) for %s, saved ~%d tokens",
                len(results),
                tool_name,
                sum(r.saved_tokens for r in results),
            )
    except Exception as e:
        logger.debug("Artifact externalization skipped: %s", e)
    return response


if TYPE_CHECKING:
    from robotmcp.frontend.controller import FrontendServerController
    # Both are used only inside string annotations; importing them at runtime would
    # pull the Django frontend config and the session models into every server import
    # for no benefit (change: quality-baseline-cleanup).
    from robotmcp.frontend.config import FrontendConfig
    from robotmcp.models.session_models import ExecutionSession


# ── ADR-006/007/008 initialization ─────────────────────────────────


def _build_tool_descriptor_registry() -> Dict[str, Any]:
    """Build ToolDescriptor registry for all MCP tools.

    Returns a dict mapping tool_name -> ToolDescriptor with tag
    classification and description variants for each tool.
    """
    from robotmcp.domains.tool_profile.entities import ToolDescriptor
    from robotmcp.domains.tool_profile.value_objects import ToolTag

    tag_map = {
        "manage_session": frozenset({ToolTag.CORE}),
        "execute_step": frozenset({ToolTag.CORE, ToolTag.EXECUTION}),
        "execute_flow": frozenset({ToolTag.EXECUTION}),
        "get_session_state": frozenset({ToolTag.CORE}),
        "find_keywords": frozenset({ToolTag.CORE, ToolTag.DISCOVERY}),
        "get_keyword_info": frozenset({ToolTag.DISCOVERY}),
        "recommend_libraries": frozenset({ToolTag.DISCOVERY}),
        "analyze_scenario": frozenset({ToolTag.DISCOVERY}),
        "check_library_availability": frozenset({ToolTag.DISCOVERY}),
        "build_test_suite": frozenset({ToolTag.ADVANCED}),
        "run_test_suite": frozenset({ToolTag.ADVANCED}),
        "get_locator_guidance": frozenset({ToolTag.CORE}),
        "set_library_search_order": frozenset({ToolTag.ADVANCED}),
        "manage_library_plugins": frozenset({ToolTag.ADVANCED}),
        "manage_attach": frozenset({ToolTag.ADVANCED}),
        "intent_action": frozenset({ToolTag.CORE, ToolTag.EXECUTION}),
    }

    descriptors: Dict[str, ToolDescriptor] = {}
    for tool_name, tags in tag_map.items():
        descriptors[tool_name] = ToolDescriptor(
            tool_name=tool_name,
            tags=tags,
            description_full=f"Full description of {tool_name}",
            description_compact=f"{tool_name} (compact)",
            description_minimal=tool_name,
            schema_full={"type": "object"},
            token_estimate_full=400,
            token_estimate_compact=120,
            token_estimate_minimal=50,
        )
    return descriptors


async def _initialize_adr_006_007_008() -> None:
    """Initialize ADR-006/007/008 singletons.

    Idempotent -- safe to call multiple times (lazy init fallback).
    """
    global _tool_manager_adapter, _tool_profile_manager
    global _intent_registry, _intent_resolver, _intent_action_adapter
    if _intent_action_adapter is not None:
        return  # Already initialized

    try:
        from robotmcp.domains.tool_profile.adapters.fastmcp_adapter import (
            ToolManagerAdapter,
        )
        from robotmcp.domains.tool_profile.services import ToolProfileManager
        from robotmcp.domains.intent.aggregates import IntentRegistry
        from robotmcp.domains.intent.services import IntentResolver
        from robotmcp.domains.intent.adapters.mcp_tool import IntentActionAdapter
        from robotmcp.domains.intent.adapters.session_lookup_adapter import (
            SessionLookupAdapter,
        )
        from robotmcp.domains.intent.adapters.locator_normalizer_adapter import (
            LocatorNormalizerAdapter,
        )

        # Tool Profile (ADR-006)
        _tool_manager_adapter = ToolManagerAdapter(mcp)
        await _tool_manager_adapter.initialize()  # Snapshot all tools for restore
        descriptor_registry = _build_tool_descriptor_registry()
        _tool_profile_manager = ToolProfileManager(
            tool_manager=_tool_manager_adapter,
            descriptor_registry=descriptor_registry,
            event_publisher=lambda evt: logger.debug("ADR event: %s", evt),
        )

        # Intent Layer (ADR-007)
        _intent_registry = IntentRegistry.with_builtins()
        session_lookup = SessionLookupAdapter(execution_engine.session_manager)
        normalizer = LocatorNormalizerAdapter()
        _intent_resolver = IntentResolver(
            registry=_intent_registry,
            session_lookup=session_lookup,
            normalizer=normalizer,
        )
        _intent_action_adapter = IntentActionAdapter(resolver=_intent_resolver)

        logger.info("ADR-006/007/008 initialized successfully")
    except Exception as e:
        logger.warning("ADR-006/007/008 initialization failed: %s", e)


# ── End ADR-006/007/008 initialization ─────────────────────────────


def _resolve_server_instructions() -> Optional[str]:
    """Resolve MCP instructions based on environment configuration.

    Environment variables (as per ADR-002):
    - ROBOTMCP_INSTRUCTIONS: Mode control ("off", "default", "custom")
    - ROBOTMCP_INSTRUCTIONS_TEMPLATE: Template selection
      ("minimal", "standard", "detailed", "browser-focused", "api-focused")
    - ROBOTMCP_INSTRUCTIONS_FILE: Path to custom instructions file

    Returns:
        Instruction string for FastMCP, or None if instructions are disabled.
    """
    try:
        # Create adapter and resolve configuration from environment
        adapter = FastMCPInstructionAdapter()
        config = adapter.create_config_from_env()

        # Get instructions formatted for FastMCP
        instructions = adapter.get_server_instructions(
            config,
            context=adapter.get_default_tools_context(),
        )

        if instructions:
            logger.info(
                "MCP instructions enabled: mode=%s, template=%s, length=%d chars",
                config.mode.value,
                adapter.get_template_type().value if config.is_enabled else "n/a",
                len(instructions),
            )
        else:
            logger.info("MCP instructions disabled")

        return instructions

    except Exception as e:
        logger.warning(
            "Failed to resolve MCP instructions, continuing without: %s",
            str(e),
        )
        return None


def _create_mcp_server() -> FastMCP:
    """Create and configure the FastMCP server with instructions.

    Returns:
        Configured FastMCP server instance.
    """
    instructions = _resolve_server_instructions()

    return FastMCP(
        "Robot Framework MCP Server",
        instructions=instructions,
    )


# Initialize FastMCP server with instructions
mcp = _create_mcp_server()

# Optional reference to the running frontend controller
_frontend_controller: "FrontendServerController | None" = None


def _get_external_client_if_configured() -> ExternalRFClient | None:
    """Return an ExternalRFClient when attach mode is configured AND reachable.

    Uses a fast cached TCP probe (0.3ms when refused, 5s cache TTL) so callers
    never block on an unreachable bridge.

    Env vars:
    - ROBOTMCP_ATTACH_HOST (required to enable attach mode)
    - ROBOTMCP_ATTACH_PORT (optional, defaults 7317)
    - ROBOTMCP_ATTACH_TOKEN (optional, defaults 'change-me')
    """
    try:
        host = os.environ.get("ROBOTMCP_ATTACH_HOST")
        if not host:
            return None
        mode = os.environ.get("ROBOTMCP_ATTACH_DEFAULT", "auto").strip().lower()
        if mode == "off":
            return None
        port = int(os.environ.get("ROBOTMCP_ATTACH_PORT", "7317"))
        token = os.environ.get("ROBOTMCP_ATTACH_TOKEN", "change-me")
        client = ExternalRFClient(host=host, port=port, token=token)
        # Fast probe: if bridge port is unreachable, return None immediately
        if not client.is_reachable():
            return None
        return client
    except Exception:
        return None


def _project_keyword_matches_for_query(
    query: str, session_id: Optional[str], library_name: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Session-imported project keywords scored against ``query``.

    find_keywords ranks over rf-mcp's OWN catalogue, so a project's custom-library
    and resource keywords never appeared - a session declaring
    ``libraries=["BuiltIn","AcmeLibrary"]`` returned matches exclusively from
    Browser and SeleniumLibrary (change: project-keyword-discovery).

    Scoring is deliberately simple: this merges project keywords INTO the existing
    results, it does not re-tune the semantic ranker. The one guarantee the spec
    makes is that an EXACT name wins - today `query="Acme Add"` returned 336 results
    topped by `Close Window`.
    """
    if not session_id:
        return []
    try:
        from robotmcp.utils.rf_libdoc_integration import get_rf_doc_storage

        keywords = get_rf_doc_storage().project_keywords(session_id, library_name)
    except Exception as exc:  # pragma: no cover - defensive
        logger.debug("Project keyword lookup failed: %s", exc)
        return []
    if not keywords:
        return []

    def _norm(text: str) -> str:
        return " ".join((text or "").lower().replace("_", " ").split())

    def _words(text: str) -> set:
        return {w.strip(".,;:()`'\"") for w in _norm(text).split()} - {""}

    def _word_hit(w: str, pool: set) -> bool:
        # Exact, or a conservative stem match ("log" ~ "login", "click" ~ "clicks"):
        # shorter side >= 3 chars and at most 3 extra characters, so "add" does not
        # match "address".
        if w in pool:
            return True
        for u in pool:
            a, b = (w, u) if len(w) <= len(u) else (u, w)
            if len(a) >= 3 and b.startswith(a) and len(b) - len(a) <= 3:
                return True
        return False

    q = _norm(query)
    # WORD-based, not substring: a substring test matched "a" (from "navigate to a
    # web page") inside "acme add" and scored an unrelated keyword 0.75. Short tokens
    # are dropped so stopwords cannot carry a match on their own.
    q_words = {w for w in _words(q) if len(w) > 2}
    out: List[Dict[str, Any]] = []
    for ki in keywords:
        name_n = _norm(ki.name)
        name_words = _words(ki.name)
        doc_n = _norm(ki.doc)
        if name_n == q:
            confidence = 1.0
        elif q and (
            re.search(rf"\b{re.escape(q)}\b", name_n)
            or re.search(rf"\b{re.escape(name_n)}\b", q)
        ):
            # Whole-word containment ("double" in "acme double"). A CHARACTER
            # substring test scored "add" 0.9 against "Enter Address".
            confidence = 0.9
        elif q_words and all(_word_hit(w, name_words) for w in q_words):
            confidence = 0.85
        elif q_words:
            # Graded relevance from BOTH name and documentation. The previous
            # if-chain gave every partial name match a flat 0.7 and only looked at the
            # documentation when the name matched nothing, so for "log in to acme"
            # `Acme Add` tied with `Acme Login As` (doc: "Log in to Acme ...").
            name_ratio = sum(_word_hit(w, name_words) for w in q_words) / len(q_words)
            doc_ratio = sum(_word_hit(w, _words(ki.doc)) for w in q_words) / len(q_words)
            phrase = len(q) > 2 and q in doc_n
            if name_ratio < 0.5 and doc_ratio < 0.5 and not phrase:
                continue
            confidence = min(
                0.84, 0.5 + 0.25 * name_ratio + 0.2 * doc_ratio + (0.05 if phrase else 0)
            )
        elif q and len(q) > 2 and q in doc_n:
            confidence = 0.6
        else:
            continue
        out.append({
            "keyword_name": ki.name,
            "library": ki.library,
            "confidence": confidence,
            "arguments": list(ki.args or []),
            "argument_types": list(ki.arg_types or []),
            "documentation": ki.doc or "",
            "usage_example": ki.name,
            "tags": list(ki.tags or []),
            "source": ki.source or "",
            "from_project": True,
        })
    out.sort(key=lambda m: -m["confidence"])
    return out


def _session_usable_library_names(session_id: Optional[str]) -> set:
    """RF library names a session can call: its imports plus the neutral helpers."""
    names = {
        "BuiltIn", "Collections", "String", "DateTime",
        "OperatingSystem", "Process", "XML",
    }
    if not session_id:
        return names
    try:
        session = execution_engine.session_manager.get_session(session_id)
        names.update(getattr(session, "imported_libraries", []) or [])
        from robotmcp.utils.rf_libdoc_integration import get_rf_doc_storage

        names.update(get_rf_doc_storage().project_libraries(session_id).keys())
    except Exception as exc:  # pragma: no cover - defensive
        logger.debug("usable-library lookup failed for %s: %s", session_id, exc)
    return names


def _project_catalog_entries(
    session_id: Optional[str], library_name: Optional[str] = None
) -> List[Dict[str, Any]]:
    """This session's project keywords in find_keywords' catalog item shape.

    The catalog strategy listed only the engine's libraries, so a project's own
    keywords were absent - `strategy="catalog", query="acme"` returned 0 matches in
    a session where all four Acme keywords executed.
    """
    if not session_id:
        return []
    try:
        from robotmcp.utils.rf_libdoc_integration import get_rf_doc_storage

        keywords = get_rf_doc_storage().project_keywords(session_id, library_name)
    except Exception:  # pragma: no cover - defensive
        return []
    return [
        {
            "name": str(ki.name or ""),
            "library": str(ki.library or ""),
            "args": [str(a) for a in (ki.args or [])],
            "arg_types": [str(t) for t in (ki.arg_types or [])],
            "short_doc": str(ki.short_doc or ""),
            "from_project": True,
        }
        for ki in keywords
    ]


def _merge_project_keywords(discovery: Dict[str, Any], query: str,
                            session_id: Optional[str],
                            library_name: Optional[str] = None,
                            strict_library: bool = False) -> None:
    """Merge this session's project keywords into a discovery payload, in place."""
    project = _project_keyword_matches_for_query(query, session_id, library_name)
    if not project:
        return
    existing = discovery.get("matches") or []
    names_project_source = False
    if library_name:
        try:
            from robotmcp.utils.rf_libdoc_integration import get_rf_doc_storage

            names_project_source = (
                get_rf_doc_storage().resolve_project_source(session_id, library_name)
                is not None
            )
        except Exception:  # pragma: no cover - defensive
            names_project_source = False
    if library_name and (strict_library or names_project_source):
        # Scoped to the named source: its keywords are the answer. A project source
        # is always strict - the incompatibility table that makes library_name a
        # soft filter (Browser excludes SeleniumLibrary) has no entry for a
        # project's own library, so it excluded nothing and a query scoped to
        # `acme_keywords` still returned SeleniumLibrary keywords.
        merged = project
    else:
        seen = {(m.get("keyword_name"), m.get("library")) for m in project}
        merged = project + [
            m for m in existing
            if (m.get("keyword_name"), m.get("library")) not in seen
        ]
        usable = _session_usable_library_names(session_id)
        # Libraries this session can actually call rank above libraries it never
        # imported. Without this, "log in to acme" in a session holding only BuiltIn
        # and the Acme sources ranked eight SeleniumLibrary keywords above
        # `Acme Login As`.
        merged.sort(key=lambda m: (
            0 if m.get("from_project") or m.get("library") in usable else 1,
            -(m.get("confidence") or 0),
        ))
    discovery["matches"] = merged
    discovery["project_keyword_count"] = len(project)
    discovery["success"] = True


def _register_session_project_libraries(session_id: str, libraries) -> Dict[str, Any]:
    """Register a session's NON-bundled libraries for discovery.

    rf-mcp's own libraries are already in the LibDoc store; only a project's custom
    ones need registering (change: project-keyword-discovery).
    """
    out: Dict[str, Any] = {}
    try:
        from robotmcp.utils.rf_libdoc_integration import get_rf_doc_storage

        storage = get_rf_doc_storage()
        own = set(storage.libraries.keys())
        for lib in list(libraries or []):
            if lib in own:
                continue
            res = storage.register_project_source(session_id, lib)
            if res.get("success"):
                out[lib] = {"type": res.get("type"), "keywords": res.get("keywords")}
    except Exception as exc:  # pragma: no cover - defensive
        logger.debug("Init-time discovery registration failed: %s", exc)
    return out


def _register_project_source(session_id: str, source: str,
                             args=None, alias: Optional[str] = None) -> Dict[str, Any]:
    """Make a session-imported library or resource file DISCOVERABLE.

    rf-mcp could execute a project's custom-library and resource keywords but not
    find or describe them: execution goes through RF's namespace, while
    find_keywords/get_keyword_info read a LibDoc-backed store holding only rf-mcp's
    own libraries (change: project-keyword-discovery).

    Best-effort by design: a source that will not parse degrades discovery for that
    source alone and never fails the import, because execution still works.
    """
    try:
        from robotmcp.utils.rf_libdoc_integration import get_rf_doc_storage

        return get_rf_doc_storage().register_project_source(
            session_id, source, args=list(args or ()), alias=alias
        )
    except Exception as exc:  # pragma: no cover - defensive
        logger.debug("Discovery registration failed for %r: %s", source, exc)
        return {"success": False, "error": str(exc)}


def _call_attach_tool_with_fallback(
    tool_name: str,
    external_call: Callable[[ExternalRFClient], Dict[str, Any]],
    local_call: Callable[[], Dict[str, Any]],
) -> Dict[str, Any]:
    """Execute an attach-aware tool with automatic fallback when bridge is unreachable."""

    client = _get_external_client_if_configured()
    mode = os.environ.get("ROBOTMCP_ATTACH_DEFAULT", "auto").strip().lower()
    strict = os.environ.get("ROBOTMCP_ATTACH_STRICT", "0").strip() in {
        "1",
        "true",
        "yes",
    }

    if client is None or mode == "off":
        return local_call()

    try:
        response = external_call(client)
    except (
        Exception
    ) as exc:  # pragma: no cover - defensive conversion to attach-style error
        err = str(exc)
        logger.error(
            "ATTACH tool '%s' raised exception: %s", tool_name, err, exc_info=False
        )
        response = {"success": False, "error": err}

    if response.get("success"):
        return response

    error_msg = response.get("error", "attach call failed")
    logger.error("ATTACH tool '%s' error: %s", tool_name, error_msg)

    if strict or mode == "force":
        return {
            "success": False,
            "error": f"Attach bridge call failed ({tool_name}): {error_msg}",
        }

    logger.warning(
        "ATTACH unreachable for '%s'; falling back to local execution", tool_name
    )
    return local_call()


def _frontend_dependencies_available() -> bool:
    """Check whether optional frontend dependencies are installed."""

    try:
        import django  # noqa: F401
        import uvicorn  # noqa: F401
    except ImportError:
        return False
    return True


def _install_frontend_lifespan(config: "FrontendConfig") -> None:
    """Attach a custom FastMCP lifespan that manages the Django frontend."""

    from robotmcp.frontend.controller import FrontendServerController

    global _frontend_controller

    controller = FrontendServerController(config)

    @asynccontextmanager
    async def frontend_lifespan(server: FastMCP):  # type: ignore[override]
        try:
            await controller.start()
            yield {"frontend_url": controller.url}
        finally:
            await controller.stop()

    set_server_lifespan(mcp, frontend_lifespan)
    _frontend_controller = controller
    logger.info(
        "Frontend enabled at http://%s:%s%s",
        config.host,
        config.port,
        config.base_path,
    )


def _start_frontend_eager(config: "FrontendConfig") -> None:
    """Start the frontend controller for the whole process lifetime (non-stdio).

    Unlike the per-session lifespan, this binds the dashboard at server startup and
    keeps it up across MCP client connect/disconnect. It is stopped in main()'s
    finally via the shared ``_frontend_controller`` reference.
    """
    from robotmcp.frontend.controller import FrontendServerController

    global _frontend_controller
    controller = FrontendServerController(config)
    asyncio.run(controller.start())
    _frontend_controller = controller
    logger.info(
        "Frontend started eagerly at http://%s:%s%s (transport is not stdio)",
        config.host,
        config.port,
        config.base_path,
    )


def _install_health_monitor_lifespan(
    interval_seconds: int = 60,
    failure_threshold: int = 3,
) -> None:
    """Attach a FastMCP lifespan that manages the bridge health monitor.

    This function wraps any existing lifespan (e.g., frontend lifespan) to
    also start/stop the health monitor.

    Args:
        interval_seconds: Time between health checks.
        failure_threshold: Number of consecutive failures before cleanup.
    """
    global _health_monitor

    monitor = BridgeHealthMonitor(
        interval_seconds=interval_seconds,
        failure_threshold=failure_threshold,
    )
    _health_monitor = monitor

    # Capture existing lifespan (if any) to chain with it
    _inner = getattr(mcp, "_mcp_server", mcp)
    existing_lifespan = getattr(_inner, "lifespan", None)

    @asynccontextmanager
    async def health_monitor_lifespan(server: FastMCP):  # type: ignore[override]
        try:
            await monitor.start()

            # If there's an existing lifespan, chain with it
            if existing_lifespan is not None:
                async with existing_lifespan(server) as context:
                    yield context
            else:
                yield {}
        finally:
            await monitor.stop()

    set_server_lifespan(mcp, health_monitor_lifespan)


def _log_attach_banner() -> None:
    """Log attach-mode configuration and basic bridge health at server start."""

    # Log several environment variables for debugging
    logger.info(
        (
            "--- RobotMCP Environment Variables ---\n"
            f"ROBOTMCP_ATTACH_HOST: {os.environ.get('ROBOTMCP_ATTACH_HOST')}\n"
            f"ROBOTMCP_ATTACH_PORT: {os.environ.get('ROBOTMCP_ATTACH_PORT')}\n"
            f"ROBOTMCP_ATTACH_TOKEN: {os.environ.get('ROBOTMCP_ATTACH_TOKEN')}\n"
        )
    )
    try:
        client = _get_external_client_if_configured()
        if client is None:
            logger.info("Attach mode: disabled (ROBOTMCP_ATTACH_HOST not set)")
            return
        logger.info(f"Attach mode: enabled → {client.host}:{client.port}")
        diag = client.diagnostics()
        if diag.get("success"):
            details = diag.get("result") or {}
            libs = details.get("libraries")
            extra = f" libraries={libs}" if libs else ""
            logger.info(f"Attach bridge: reachable.{extra}")
        else:
            err = diag.get("error", "not reachable yet")
            logger.info(f"Attach bridge: not reachable ({err})")
        mode = os.environ.get("ROBOTMCP_ATTACH_DEFAULT", "auto").strip().lower()
        strict = os.environ.get("ROBOTMCP_ATTACH_STRICT", "0").strip() in {
            "1",
            "true",
            "yes",
        }
        logger.info(f"Attach default: {mode}{' (strict)' if strict else ''}")
    except Exception as e:  # defensive
        logger.info(f"Attach bridge: check failed ({e})")


def _startup_bridge_validation() -> Dict[str, Any]:
    """Validate bridge at startup and reset any stale local state.

    This function implements Phase 1 of ADR-004 Debug Bridge Connection Cleanup:
    - Checks bridge health on MCP server startup
    - Cleans local session state to synchronize with bridge state
    - Configurable via ROBOTMCP_STARTUP_CLEANUP environment variable

    Environment variable ROBOTMCP_STARTUP_CLEANUP:
    - "auto" (default): Clean sessions only if bridge is healthy and context is active
    - "always": Always clean local sessions at startup
    - "off": Disable startup cleanup entirely

    Returns:
        Dict with validation results and actions taken:
        - cleanup_mode: The configured cleanup mode
        - attach_mode: Whether attach mode is configured
        - healthy: Whether bridge is healthy (when attach mode enabled)
        - cleanup_performed: Whether cleanup was performed
        - sessions_cleaned: Number of sessions cleaned (if any)
        - error: Error message (if cleanup failed)
    """
    cleanup_mode = os.environ.get("ROBOTMCP_STARTUP_CLEANUP", "auto").lower().strip()

    # Validate cleanup mode
    if cleanup_mode not in ("auto", "always", "off"):
        logger.warning(
            f"Invalid ROBOTMCP_STARTUP_CLEANUP value '{cleanup_mode}', using 'auto'"
        )
        cleanup_mode = "auto"

    if cleanup_mode == "off":
        logger.info("Startup cleanup disabled via ROBOTMCP_STARTUP_CLEANUP=off")
        return {"cleanup_mode": "off", "skipped": True}

    client = _get_external_client_if_configured()
    if client is None:
        # No attach mode configured - nothing to validate
        logger.debug("Startup validation: attach mode not configured")
        return {"attach_mode": False, "cleanup_performed": False}

    try:
        # Check bridge health
        health = _check_bridge_health(client)

        if cleanup_mode == "auto":
            # In auto mode, only clean if bridge is healthy and context is active
            if health.get("healthy") and health.get("context_active"):
                cleaned = execution_engine.session_manager.cleanup_all_sessions()
                logger.info(
                    f"Startup cleanup: reset {cleaned} local sessions to sync with bridge"
                )
                return {
                    "cleanup_mode": "auto",
                    "attach_mode": True,
                    "healthy": True,
                    "context_active": True,
                    "cleanup_performed": True,
                    "sessions_cleaned": cleaned,
                }
            else:
                # Bridge not healthy or no active context - keep local sessions
                reason = (
                    "bridge not healthy"
                    if not health.get("healthy")
                    else "no active RF context"
                )
                logger.info(f"Startup cleanup: skipped ({reason}), keeping local sessions")
                return {
                    "cleanup_mode": "auto",
                    "attach_mode": True,
                    "healthy": health.get("healthy", False),
                    "context_active": health.get("context_active", False),
                    "cleanup_performed": False,
                    "reason": reason,
                }

        elif cleanup_mode == "always":
            # Always clean local sessions at startup, regardless of bridge health
            cleaned = execution_engine.session_manager.cleanup_all_sessions()
            logger.info(f"Startup cleanup (always mode): reset {cleaned} local sessions")
            return {
                "cleanup_mode": "always",
                "attach_mode": True,
                "cleanup_performed": True,
                "sessions_cleaned": cleaned,
                "bridge_healthy": health.get("healthy", False),
                "context_active": health.get("context_active", False),
            }

    except Exception as e:
        logger.warning(f"Startup validation failed: {e}")
        return {
            "cleanup_mode": cleanup_mode,
            "attach_mode": True,
            "error": str(e),
            "cleanup_performed": False,
        }

    # Should not reach here, but return a safe default
    return {"cleanup_mode": cleanup_mode, "attach_mode": True, "cleanup_performed": False}


def _compute_effective_use_context(
    use_context: bool | None, client: ExternalRFClient | None, keyword: str
) -> tuple[bool, str, bool]:
    """Decide whether to route to the external bridge.

    Returns a tuple: (effective_use_context, mode, strict)
    - mode: value of ROBOTMCP_ATTACH_DEFAULT (auto|force|off)
    - strict: True if ROBOTMCP_ATTACH_STRICT is enabled
    """
    mode = os.environ.get("ROBOTMCP_ATTACH_DEFAULT", "auto").strip().lower()
    strict = os.environ.get("ROBOTMCP_ATTACH_STRICT", "0").strip() in {
        "1",
        "true",
        "yes",
    }
    effective = bool(use_context) if use_context is not None else False
    if client is not None:
        if use_context is None:
            if mode in ("auto", "force"):
                reachable = bool(client.diagnostics().get("success"))
                if mode == "force" or reachable:
                    effective = True
                    logger.info(
                        f"ATTACH mode ({mode}): defaulting use_context=True for '{keyword}'"
                    )
                else:
                    effective = False
                    logger.info(
                        f"ATTACH mode (auto): bridge unreachable, defaulting to local for '{keyword}'"
                    )
        elif use_context is False and mode == "force":
            effective = True
            logger.info(
                f"ATTACH mode (force): overriding use_context=False → True for '{keyword}'"
            )
    return effective, mode, strict


def _get_external_client_with_session_sync(
    session_id: str = "default",
) -> tuple[ExternalRFClient | None, "ExecutionSession | None"]:
    """Get bridge client and ensure local session is synchronized.

    When bridge is configured and reachable with an active RF context,
    automatically creates the local session if it doesn't exist.

    This function implements Phase 1 of ADR-003 Debug Bridge Unification:
    - S1: Auto-Initialize Session from Bridge
    - Fixes the get_session_state first-call failure when bridge is active

    Returns:
        (client, session) tuple where:
        - client is the ExternalRFClient if bridge is configured and reachable
        - session is the local ExecutionSession (may be auto-created)
        Both may be None if bridge not configured and no local session exists.
    """
    client = _get_external_client_if_configured()
    session = execution_engine.session_manager.get_session(session_id)

    if client is None:
        # No bridge - return existing local session (may be None)
        return None, session

    # Bridge configured - check reachability and context
    try:
        diag = client.diagnostics()
        if not diag.get("success"):
            # Bridge unreachable - fall back to local
            return None, session

        # Bridge reachable with context - ensure local session exists
        if session is None:
            bridge_result = diag.get("result", {})
            if bridge_result.get("context", False):
                # Auto-create session from bridge state
                session = execution_engine.session_manager.create_session(session_id)
                for lib in bridge_result.get("libraries", []):
                    if lib not in session.imported_libraries:
                        session.imported_libraries.append(lib)
                    session.loaded_libraries.add(lib)
                if bridge_result.get("libraries"):
                    # Preserve BuiltIn at front, add bridge libraries after
                    bridge_libs = [
                        lib
                        for lib in bridge_result.get("libraries", [])
                        if lib != "BuiltIn"
                    ]
                    # Keep BuiltIn first if present in search_order
                    if session.search_order and session.search_order[0] == "BuiltIn":
                        session.search_order = ["BuiltIn"] + bridge_libs
                    else:
                        session.search_order = bridge_libs
                logger.info(
                    f"Auto-created session '{session_id}' from bridge with "
                    f"libraries: {bridge_result.get('libraries', [])}"
                )

        return client, session

    except Exception as e:
        logger.debug(f"Bridge check failed: {e}")
        return None, session


async def _sync_session_bidirectional(
    session_id: str,
    client: ExternalRFClient,
    session: "ExecutionSession",
    direction: str = "both",  # "to_bridge", "from_bridge", "both"
) -> Dict[str, Any]:
    """Synchronize session state between local and bridge.

    This function implements Phase 4 of ADR-003 Debug Bridge Unification:
    - Bidirectional sync of libraries and variables
    - Ensures local session stays in sync with live RF process

    Args:
        session_id: Session identifier for logging
        client: ExternalRFClient connected to the bridge
        session: Local ExecutionSession to sync
        direction: Sync direction - "to_bridge", "from_bridge", or "both"

    Returns:
        Dict with success status and list of synced items
    """
    results: Dict[str, Any] = {"success": True, "synced": [], "session_id": session_id}

    try:
        if direction in ("from_bridge", "both"):
            # Sync libraries from bridge
            diag = client.diagnostics()
            if diag.get("success"):
                bridge_libs = set(diag.get("result", {}).get("libraries", []))
                for lib in bridge_libs:
                    if lib not in session.imported_libraries:
                        session.imported_libraries.append(lib)
                    session.loaded_libraries.add(lib)
                results["synced"].append("libraries_from_bridge")
                results["libraries_synced"] = list(bridge_libs)

            # Sync variables from bridge
            var_resp = client.get_variables()
            if var_resp.get("success"):
                raw_vars = var_resp.get("result", {})
                synced_count = 0
                for k, v in raw_vars.items():
                    # Strip ${} wrappers from variable names
                    clean_key = k
                    if clean_key.startswith("${") and clean_key.endswith("}"):
                        clean_key = clean_key[2:-1]
                    session.variables[clean_key] = v
                    synced_count += 1
                results["synced"].append("variables_from_bridge")
                results["variables_synced_count"] = synced_count

        if direction in ("to_bridge", "both"):
            # Push local variables to bridge
            pushed_count = 0
            push_errors = []
            for key, value in session.variables.items():
                try:
                    resp = client.set_variable(key, value, scope="suite")
                    if resp.get("success"):
                        pushed_count += 1
                    else:
                        push_errors.append(f"{key}: {resp.get('error', 'unknown')}")
                except Exception as var_err:
                    push_errors.append(f"{key}: {var_err}")
            results["synced"].append("variables_to_bridge")
            results["variables_pushed_count"] = pushed_count
            if push_errors:
                results["push_errors"] = push_errors[:5]  # Limit error list

        return results

    except Exception as e:
        logger.error(f"Session bidirectional sync failed: {e}")
        return {"success": False, "error": str(e), "session_id": session_id}


def _check_bridge_health(client: ExternalRFClient) -> Dict[str, Any]:
    """Check bridge health and provide recovery hints.

    This function implements Phase 4 of ADR-003 Debug Bridge Unification:
    - Health check for the attach bridge
    - Provides actionable recovery hints for common errors

    Args:
        client: ExternalRFClient to check

    Returns:
        Dict with health status and recovery hints:
        - healthy: True if bridge is reachable and has active context
        - context_active: True if RF execution context is active
        - error: Error type if unhealthy
        - recovery_hint: Actionable hint for recovery
    """
    try:
        diag = client.diagnostics()
        if diag.get("success"):
            bridge_result = diag.get("result", {})
            return {
                "healthy": True,
                "context_active": bridge_result.get("context", False),
                "libraries": bridge_result.get("libraries", []),
                "host": client.host,
                "port": client.port,
            }
        # Bridge responded but returned error
        return {
            "healthy": False,
            "context_active": False,
            "error": "diagnostics_failed",
            "details": diag.get("error", "unknown error"),
            "recovery_hint": "Bridge responded but returned error. Check RF process logs for details.",
        }
    except Exception as e:
        error_str = str(e).lower()

        if "connection refused" in error_str:
            return {
                "healthy": False,
                "context_active": False,
                "error": "connection_refused",
                "recovery_hint": (
                    "Bridge server not running. Ensure Robot Framework is running "
                    "with McpAttach library loaded and 'MCP Serve' keyword has been called."
                ),
            }
        elif "timeout" in error_str or "timed out" in error_str:
            return {
                "healthy": False,
                "context_active": False,
                "error": "timeout",
                "recovery_hint": (
                    "Bridge server not responding. RF process may be blocked, "
                    "overloaded, or executing a long-running keyword. "
                    "Try again after the current operation completes."
                ),
            }
        elif (
            "name or service not known" in error_str
            or "nodename nor servname" in error_str
        ):
            return {
                "healthy": False,
                "context_active": False,
                "error": "dns_resolution_failed",
                "recovery_hint": (
                    f"Cannot resolve bridge host. Check ROBOTMCP_ATTACH_HOST "
                    f"environment variable (current: {client.host})."
                ),
            }
        elif "network is unreachable" in error_str:
            return {
                "healthy": False,
                "context_active": False,
                "error": "network_unreachable",
                "recovery_hint": (
                    "Network is unreachable. Check network connectivity "
                    "and firewall settings."
                ),
            }

        return {
            "healthy": False,
            "context_active": False,
            "error": str(e),
            "recovery_hint": (
                "Unknown error connecting to bridge. Check network connectivity, "
                "RF process status, and environment variables "
                "(ROBOTMCP_ATTACH_HOST, ROBOTMCP_ATTACH_PORT)."
            ),
        }


# Internal helpers to build prompt texts (used by both @mcp.prompt and wrapper tools)
def _build_recommend_libraries_sampling_prompt(
    scenario: str,
    k: int = 4,
    available_libraries: List[Dict[str, Any]] = None,
) -> str:
    try:
        import json

        libs_section = (
            json.dumps(available_libraries, ensure_ascii=False, indent=2)
            if available_libraries
            else "[]"
        )
    except Exception:
        libs_section = "[]"

    return (
        "# Task\n"
        "You are 1 of {k} samplers. Recommend the best Robot Framework libraries for this scenario.\n"
        "- Consider ONLY the libraries listed below as available in this environment.\n"
        "- Resolve conflicts (e.g., prefer one of Browser/SeleniumLibrary).\n"
        "- Output strictly the JSON schema in the Output Format section.\n\n"
        "# Scenario\n"
        f"{scenario}\n\n"
        "# Available Libraries (from environment)\n"
        f"{libs_section}\n\n"
        "# Guidance\n"
        "- Choose 2–5 libraries maximum.\n"
        "- Justify each choice concisely, referencing capabilities from 'available_libraries'.\n"
        "- If multiple web libs exist, pick one with a short rationale.\n"
        "- For API use, mention RequestsLibrary and how sessions are created.\n"
        "- For XML/data flows, consider XML/Collections/String.\n"
        "- If specialized libs are not needed, do not recommend them.\n\n"
        "# Output Format (JSON)\n"
        "{\n"
        '  "recommendations": [\n'
        '    { "name": "<LibraryName>", "reason": "<1-2 lines>", "score": 0.0 },\n'
        "    ... up to 5 total ...\n"
        "  ],\n"
        '  "conflicts": [\n'
        '    { "conflict_set": ["Browser", "SeleniumLibrary"], "chosen": "Browser", "reason": "<1 line>" }\n'
        "  ]\n"
        "}\n"
    )


def _build_choose_recommendations_prompt(
    candidates: List[Dict[str, Any]] = None,
) -> str:
    import json

    cand_section = (
        json.dumps(candidates, ensure_ascii=False, indent=2) if candidates else "[]"
    )

    return (
        "# Task\n"
        "Select or merge the following sampled recommendations into a final JSON.\n"
        "- Deduplicate libraries by name.\n"
        "- Resolve conflicts (e.g., Browser vs SeleniumLibrary) by choosing the higher total score; state a 1-line reason.\n"
        "- Normalize scores to 0..1, and keep at most 5 libraries.\n"
        "- Output strictly the JSON under 'Output Format'.\n\n"
        "# Candidates (JSON)\n"
        f"{cand_section}\n\n"
        "# Output Format (JSON)\n"
        "{\n"
        '  "recommendations": [\n'
        '    { "name": "<LibraryName>", "reason": "<1-2 lines>", "score": 0.0 }\n'
        "  ],\n"
        '  "conflicts": [\n'
        '    { "conflict_set": ["Browser", "SeleniumLibrary"], "chosen": "<name>", "reason": "<1 line>" }\n'
        "  ]\n"
        "}\n"
    )


# Initialize components
nlp_processor = NaturalLanguageProcessor()
keyword_matcher = KeywordMatcher()
library_recommender = LibraryRecommender()
state_manager = StateManager()
mobile_capability_service = MobileCapabilityService()

# --- Lazy ExecutionCoordinator (change: fast-mcp-handshake-lazy-init) ---
# Constructing the coordinator transitively spins up robotmcp's execution stack
# (and, before this change, the libdoc preload) — enough to block the MCP
# handshake for seconds. Defer it behind a transparent proxy so importing this
# module constructs nothing heavy; a warm-up thread in main() materializes it
# right after the event loop is up, and a tool call arriving during warm-up
# blocks at most on one initialization. ROBOTMCP_LAZY_INIT=0 restores eager
# construction at import.
_real_execution_engine = None
_engine_lock = threading.Lock()


def _get_execution_engine():
    """Construct (once, thread-safe) the ExecutionCoordinator + enhanced serialization."""
    global _real_execution_engine
    if _real_execution_engine is not None:
        return _real_execution_engine
    with _engine_lock:
        if _real_execution_engine is not None:
            return _real_execution_engine
        engine = ExecutionCoordinator()
        initialize_enhanced_serialization(engine)
        _real_execution_engine = engine
        return engine


class _LazyEngineProxy:
    """Transparent lazy proxy for the ExecutionCoordinator singleton.

    Materializes the real coordinator (and applies enhanced serialization) on
    first attribute access. ``from robotmcp.server import execution_engine``
    yields this proxy, and ``mock.patch("robotmcp.server.execution_engine", …)``
    replaces the module attribute wholesale, so tests still substitute what
    handlers see.
    """

    __slots__ = ()

    def __getattr__(self, name):
        return getattr(_get_execution_engine(), name)

    def __setattr__(self, name, value):
        setattr(_get_execution_engine(), name, value)

    def __repr__(self):
        return f"<LazyEngineProxy materialized={_real_execution_engine is not None}>"


if os.environ.get("ROBOTMCP_LAZY_INIT") == "0":
    execution_engine = _get_execution_engine()
else:
    execution_engine = _LazyEngineProxy()
test_builder = TestBuilder(execution_engine)

# Shared guidance for automation workflows
AUTOMATION_TOOL_GUIDE: List[tuple[str, str]] = [
    (
        "analyze_scenario",
        "to understand the requirements and create/configure a session.",
    ),
    (
        "recommend_libraries",
        "to fetch targeted library suggestions for the scenario.",
    ),
    (
        "execute_step",
        "to run individual keywords in the active session (reuse the same session_id).",
    ),
    (
        "get_session_state",
        "to capture application state, DOM snapshots, screenshots, and variables when debugging.",
    ),
    (
        "diagnose_rf_context",
        "to inspect the Robot Framework namespace (libraries, variables, search order) if keywords fail.",
    ),
    (
        "build_test_suite",
        "to compile the validated steps into a reusable Robot Framework suite.",
    ),
    (
        "run_test_suite_dry",
        "to perform a staged dry run and validate the generated suite structure.",
    ),
    (
        "run_test_suite",
        "to execute the finalized suite with all required libraries loaded.",
    ),
]


# Helper functions
async def _ensure_all_session_libraries_loaded():
    """
    Ensure all imported session libraries are loaded in LibraryManager.

    Enhanced validation to prevent keyword filtering issues and provide better error reporting.
    """
    try:
        session_manager = execution_engine.session_manager
        all_sessions = session_manager.sessions.values()

        try:
            from robotmcp.utils.rf_libdoc_integration import get_rf_doc_storage

            _storage = get_rf_doc_storage()
        except Exception:  # pragma: no cover - defensive
            _storage = None

        for session in all_sessions:
            for library_name in session.imported_libraries:
                # Project sources (a custom library imported by path, a resource) are
                # served by the session's project registry, not the orchestrator's
                # name-keyed library table. Checking them there always "failed" and
                # logged an ERROR claiming keyword filtering was at risk, for a
                # library whose keywords were executing fine.
                if _storage is not None and _storage.resolve_project_source(
                    session.session_id, library_name
                ) is not None:
                    continue
                # Check if library is loaded in the orchestrator
                if library_name not in execution_engine.keyword_discovery.libraries:
                    logger.warning(
                        f"Session library '{library_name}' not loaded in orchestrator, attempting to load"
                    )
                    session._ensure_library_loaded_immediately(library_name)

                    # Verify loading succeeded
                    if library_name not in execution_engine.keyword_discovery.libraries:
                        logger.error(
                            f"Failed to load session library '{library_name}' - may cause keyword filtering issues"
                        )
                else:
                    logger.debug(
                        f"Session library '{library_name}' already loaded in orchestrator"
                    )

        logger.debug(
            "Validated all session libraries are loaded for discovery operations"
        )

    except Exception as e:
        logger.error(f"Error ensuring session libraries loaded: {e}")
        # Don't fail the discovery operation, but log the issue for debugging


@mcp.prompt
def automate(scenario: str) -> str:
    """Uses RobotMCP to create a test suite from a scenario description"""
    tool_lines = "\n".join(
        f"{idx}. Use {tool} {description}"
        for idx, (tool, description) in enumerate(AUTOMATION_TOOL_GUIDE, start=1)
    )
    return (
        "# Task\n"
        "Use RobotMCP to create a TestSuite and execute it step wise.\n"
        f"{tool_lines}\n"
        "General hints:\n"
        "- For UI testing capture state via get_session_state (sections=['application_state','page_source','variables']).\n"
        "- Ensure Browser or Playwright contexts run in non-headless mode when interacting with live UIs.\n"
        "- When you need keyword or library details, use get_keyword_info (mode='library' or 'keyword') and get_library_documentation.\n"
        "- Use manage_session (set_variables/import_library) to configure sessions between steps if needed.\n"
        "# Scenario:\n"
        f"{scenario}\n"
    )


@mcp.prompt
def learn(scenario: str) -> str:
    """Guides a user through automation and explains the generated code/choices."""
    return (
        "# Role\n"
        "Act as a friendly Robot Framework tutor. Automate the scenario with RobotMCP tools, "
        "but after each major phase summarize what you did and why (libraries chosen, keywords executed, "
        "variables used, etc.). Keep explanations concise and practical.\n"
        "# Workflow\n"
        "1. analyze_scenario – understand requirements and capture the session_id.\n"
        "2. recommend_libraries – justify which libraries fit the scenario.\n"
        "3. manage_session / execute_step – build the test step-by-step, reusing the same session.\n"
        "4. get_session_state or diagnose_rf_context when you need to inspect UI/variables/libraries.\n"
        "5. build_test_suite – convert the validated steps into a suite.\n"
        "6. run_test_suite_dry (optional) – confirm the suite compiles.\n"
        "7. run_test_suite – execute if appropriate.\n"
        "# Teaching Guidance\n"
        "- Explain why each library/keyword was selected (e.g., Browser vs SeleniumLibrary, Images vs API).\n"
        "- Highlight any tricky locators, variables, or context setup.\n"
        "- Encourage best practices (non-headless browser, reusable keywords, variable naming) without lecturing.\n"
        "- Keep explanations short (2–3 sentences) and actionable.\n"
        "# Scenario\n"
        f"{scenario}\n"
    )


# Note: Prompt endpoints removed per Option B. Use tools below that return plain prompt text.


@mcp.tool(
    name="list_library_plugins",
    description="List discovered library plugins with basic metadata.",
    **DISABLED_TOOL_KWARGS,
)
async def list_library_plugins() -> Dict[str, Any]:
    """Return a summary of every loaded library plugin."""

    library_registry.get_all_libraries()
    manager = get_library_plugin_manager()

    plugins: List[Dict[str, Any]] = []
    for name in manager.list_plugin_names():
        metadata = manager.get_metadata(name)
        if not metadata:
            continue
        plugins.append(
            {
                "name": metadata.name,
                "package_name": metadata.package_name,
                "import_path": metadata.import_path,
                "library_type": metadata.library_type,
                "load_priority": metadata.load_priority,
                "source": manager.get_plugin_source(name) or "unknown",
                "default_enabled": metadata.default_enabled,
            }
        )

    return {"success": True, "plugins": plugins, "count": len(plugins)}


@mcp.tool(
    name="reload_library_plugins",
    description="Reload library plugins from builtin definitions, entry points, and manifests.",
    **DISABLED_TOOL_KWARGS,
)
async def reload_library_plugins_tool(
    manifest_paths: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Reload library plugins and return the resulting library list."""

    snapshot = library_registry.reload_library_plugins(manifest_paths)
    return {
        "success": True,
        "libraries": sorted(snapshot.keys()),
        "count": len(snapshot),
    }


@mcp.tool(
    name="diagnose_library_plugin",
    description="Inspect metadata, capabilities, and hooks for a specific library plugin.",
    **DISABLED_TOOL_KWARGS,
)
async def diagnose_library_plugin(plugin_name: str) -> Dict[str, Any]:
    """Return detailed information about a specific library plugin."""

    library_registry.get_all_libraries()
    manager = get_library_plugin_manager()

    metadata = manager.get_metadata(plugin_name)
    if not metadata:
        return {
            "success": False,
            "error": f"Plugin '{plugin_name}' not found.",
        }

    capabilities = manager.get_capabilities(plugin_name)
    install_actions = [
        {"description": action.description, "command": list(action.command)}
        for action in manager.get_install_actions(plugin_name)
    ]
    hints = manager.get_hints(plugin_name)
    prompts = manager.get_prompt_bundle(plugin_name)

    return {
        "success": True,
        "metadata": {
            "name": metadata.name,
            "package_name": metadata.package_name,
            "import_path": metadata.import_path,
            "library_type": metadata.library_type,
            "description": metadata.description,
            "use_cases": metadata.use_cases,
            "categories": metadata.categories,
            "contexts": metadata.contexts,
            "installation_command": metadata.installation_command,
            "post_install_commands": metadata.post_install_commands,
            "platform_requirements": metadata.platform_requirements,
            "dependencies": metadata.dependencies,
            "load_priority": metadata.load_priority,
            "default_enabled": metadata.default_enabled,
            "requires_type_conversion": metadata.requires_type_conversion,
            "supports_async": metadata.supports_async,
            "is_deprecated": metadata.is_deprecated,
            "extra_name": metadata.extra_name,
        },
        "capabilities": {
            "contexts": capabilities.contexts if capabilities else [],
            "features": capabilities.features if capabilities else [],
            "technology": capabilities.technology if capabilities else [],
            "supports_page_source": capabilities.supports_page_source
            if capabilities
            else False,
            "supports_application_state": capabilities.supports_application_state
            if capabilities
            else False,
            "requires_type_conversion": capabilities.requires_type_conversion
            if capabilities
            else False,
            "supports_async": capabilities.supports_async if capabilities else False,
        },
        "install_actions": install_actions,
        "hints": {
            "standard_keywords": hints.standard_keywords if hints else [],
            "error_hints": hints.error_hints if hints else [],
            "usage_examples": hints.usage_examples if hints else [],
        },
        "prompt_bundle": {
            "recommendation": prompts.recommendation if prompts else None,
            "troubleshooting": prompts.troubleshooting if prompts else None,
            "sampling_notes": prompts.sampling_notes if prompts else None,
        },
        "source": manager.get_plugin_source(plugin_name) or "unknown",
    }


@mcp.tool
async def manage_library_plugins(
    action: PluginAction = "list", plugin_name: str | None = None
) -> Dict[str, Any]:
    """Inspect or reload library plugins.

    Args:
        action: One of "list", "reload", or "diagnose".
        plugin_name: Plugin name when action="diagnose".

    Returns:
        Dict[str, Any]: Plugin metadata depending on action:
            - success: bool
            - action: echo of the requested action
            - plugins/plugin/reload_result: action-specific data
            - error: present on failure
    """

    action_norm = (action or "list").strip().lower()
    manager = get_library_plugin_manager()

    def _plugin_payload(name: str) -> Dict[str, Any]:
        metadata = manager.get_metadata(name)
        plugin = manager.get_plugin(name)
        capabilities = manager.get_capabilities(name)
        install_actions = manager.get_install_actions(name)
        hints = manager.get_hints(name)
        prompts = manager.get_prompt_bundle(name)
        return {
            "name": name,
            "metadata": asdict(metadata) if metadata else None,
            "capabilities": asdict(capabilities) if capabilities else None,
            "install_actions": [asdict(action) for action in install_actions],
            "hints": asdict(hints) if hints else None,
            "prompts": asdict(prompts) if prompts else None,
            "source": manager.get_plugin_source(name),
            "has_plugin": plugin is not None,
        }

    def _dump_plugins() -> List[Dict[str, Any]]:
        library_registry.get_all_libraries()
        items: List[Dict[str, Any]] = []
        for name in manager.list_plugin_names():
            items.append(_plugin_payload(name))
        return items

    if action_norm == "list":
        return {"success": True, "action": "list", "plugins": _dump_plugins()}
    if action_norm == "reload":
        reload_result = library_registry.reload_library_plugins()
        return {
            "success": True,
            "action": "reload",
            "reload_result": reload_result,
            "plugins": _dump_plugins(),
        }
    if action_norm == "diagnose":
        if not plugin_name:
            return {
                "success": False,
                "error": "plugin_name is required for action='diagnose'",
                "action": "diagnose",
            }
        if plugin_name not in manager.list_plugin_names():
            return {
                "success": False,
                "error": f"Plugin '{plugin_name}' not found",
                "action": "diagnose",
            }
        return {
            "success": True,
            "action": "diagnose",
            "plugin": _plugin_payload(plugin_name),
        }
    return {"success": False, "error": f"Unsupported action '{action}'"}


async def _refine_recommendations_with_llm(
    ctx: Context,
    scenario: str,
    context: str,
    recommendations: List[Dict[str, Any]],
) -> Optional[List[Dict[str, Any]]]:
    """Use LLM to refine library recommendations.

    Args:
        ctx: FastMCP context with sample() method
        scenario: Original scenario text
        context: Testing context (web, api, etc.)
        recommendations: Rule-based recommendations to refine

    Returns:
        Refined recommendations or None if refinement fails
    """
    if not ctx or not hasattr(ctx, "sample"):
        return None

    if not recommendations:
        return None

    # Build refinement prompt
    lib_names = [
        r.get("library_name", r.get("name", "Unknown")) for r in recommendations[:10]
    ]

    prompt = f"""Given this test automation scenario and candidate libraries, select the BEST 3-5 libraries.

Scenario: {scenario}
Context: {context}
Candidate libraries: {", ".join(lib_names)}

Rules:
1. NEVER include both Browser and SeleniumLibrary (they conflict)
2. Prefer Browser over SeleniumLibrary for web testing (it's more modern)
3. Only include libraries actually needed for the scenario
4. Include BuiltIn and Collections if other libraries are selected

Respond with ONLY a JSON array of library names, like: ["Browser", "BuiltIn", "Collections"]
"""

    try:
        result = await ctx.sample(
            messages=prompt,
            system_prompt="You are a Robot Framework expert. Respond only with a JSON array of library names.",
            temperature=0.2,
            max_tokens=256,
        )

        # Parse response
        import json
        import re

        response_text = result.text if hasattr(result, "text") else str(result)

        # Extract JSON array from response
        json_match = re.search(r"\[.*?\]", response_text, re.DOTALL)
        if json_match:
            selected_names = json.loads(json_match.group())

            # Filter recommendations to only include selected libraries
            refined = [
                r
                for r in recommendations
                if r.get("library_name", r.get("name")) in selected_names
            ]

            # Ensure we have at least some results
            if refined:
                logger.info(
                    f"LLM refined {len(recommendations)} recommendations to {len(refined)}"
                )
                return refined

    except Exception as e:
        logger.debug(f"LLM refinement parsing failed: {e}")

    return None


@mcp.tool
async def recommend_libraries(
    scenario: str,
    context: AutomationContext = "web",
    session_id: str | None = None,
    max_recommendations: int = 5,
    check_availability: bool = True,
    apply_search_order: bool = True,
    mode: RecommendMode = "direct",
    samples: List[Dict[str, Any]] | None = None,
    k: int | None = None,
    available_libraries: List[Dict[str, Any]] | None = None,
    include_keywords: bool = True,
    use_llm_refinement: bool = False,
    ctx: Context = None,
) -> Dict[str, Any]:
    """Recommend libraries for a scenario or generate/merge sampling prompts.

    WHEN TO USE THIS TOOL:
    - IMMEDIATELY after analyze_scenario, before execute_step
    - When you encounter "No keyword with name" errors
    - To discover which libraries provide needed functionality

    This tool analyzes scenario text and suggests relevant libraries, saving you from
    guessing which libraries to import.

    Args:
        scenario: Natural-language description of the task to automate.
        context: Context such as "web", "mobile", or "api". Defaults to "web".
        session_id: Optional session id to align recommendations with an existing session.
        max_recommendations: Maximum libraries to return (direct mode).
        check_availability: When True, checks installability/presence of suggested libs.
        apply_search_order: When True, applies recommended order to the session.
        mode: "direct", "sampling_prompt", or "merge_samples".
        samples: Sampled recommendations to merge when mode="merge_samples".
        k: Number of samples to request when mode="sampling_prompt" (defaults to 4).
        available_libraries: Optional pre-fetched library metadata to use instead of registry defaults.
        include_keywords: When True, include a compact keyword list (names only) for the top recommendation.
        use_llm_refinement: When True, uses LLM via ctx.sample() to refine recommendations.
        ctx: FastMCP Context object providing access to sample() for LLM refinement.

    Returns:
        Dict[str, Any]: Recommendation payload:
            - success: bool
            - recommendations or sampling_prompt or merged result (depending on mode)
            - session_id: echoed/preserved when provided
            - error/guidance: present on failure

    Examples:
        After analyzing web scenario:
            recommend_libraries(
                scenario="Test login form with username and password",
                context="web",
                session_id="web_test"
            )
            # Returns: ["Browser", "SeleniumLibrary"] with usage guidance
    """

    mode_norm = (mode or "direct").strip().lower()
    if mode_norm in {"sampling", "sampling_prompt"}:
        from robotmcp.config.library_registry import get_recommendation_info

        libs = available_libraries or get_recommendation_info()
        for lib in libs:
            lib.setdefault("conflicts", [])
        sample_count = k or 4
        prompt_text = _build_recommend_libraries_sampling_prompt(
            scenario, sample_count, libs
        )
        return {
            "success": True,
            "mode": "sampling_prompt",
            "prompt": prompt_text,
            "available_libraries": libs,
            "recommended_sampling": {"count": sample_count, "temperature": 0.4},
        }

    if mode_norm in {"merge", "merge_samples"}:
        if not samples:
            return {
                "success": False,
                "mode": "merge_samples",
                "error": "samples are required when mode='merge_samples'",
            }
        prompt_text = _build_choose_recommendations_prompt(samples)
        return {
            "success": True,
            "mode": "merge_samples",
            "prompt": prompt_text,
        }

    # Get explicit library preference from session if available
    explicit_pref = None
    if session_id:
        try:
            session_for_pref = execution_engine.session_manager.get_session(session_id)
            if session_for_pref and hasattr(
                session_for_pref, "explicit_library_preference"
            ):
                explicit_pref = session_for_pref.explicit_library_preference
        except Exception:
            pass

    rec = library_recommender.recommend_libraries(
        scenario,
        context=context,
        max_recommendations=max_recommendations,
        explicit_library_preference=explicit_pref,
    )
    if not rec.get("success"):
        return {"success": False, "error": rec.get("error", "Recommendation failed")}

    recommendations = rec.get("recommendations", [])
    recommended_names = [
        r.get("library_name") for r in recommendations if r.get("library_name")
    ]

    def _attach_keywords(recs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        if not recs:
            return recs
        # Only enrich the top recommendation to keep payload small
        target = recs[0]
        lib_name = target.get("library_name")
        if not lib_name:
            return recs

        from robotmcp.plugins.manager import get_library_plugin_manager
        from robotmcp.utils.rf_libdoc_integration import get_rf_doc_storage

        keywords: List[str] = []
        source = "none"

        # Try plugin hints first
        mgr = get_library_plugin_manager()
        hints = mgr.get_hints(lib_name)
        if hints and hints.standard_keywords:
            keywords = list(hints.standard_keywords)
            source = "plugin_hints"
        else:
            # Fallback to libdoc cache (full keyword list to avoid truncation)
            try:
                storage = get_rf_doc_storage()
                kw_docs = storage.get_keywords_by_library(lib_name) or []
                keywords = [kw.name for kw in kw_docs]
                if keywords:
                    source = "libdoc_cache"
            except Exception:
                keywords = []
                source = "none"

        if keywords:
            target["keywords"] = keywords
            target["keyword_source"] = source
            target["keyword_hint"] = (
                "Call get_keyword_info for keyword arguments and documentation."
            )
        return recs

    result: Dict[str, Any] = {
        "success": True,
        "mode": "direct",
        "scenario": scenario,
        "context": context,
        "recommended_libraries": recommended_names,
        "recommendations": _attach_keywords(recommendations)
        if include_keywords
        else recommendations,
    }

    availability_info = None
    if check_availability and recommended_names:
        availability_info = execution_engine.check_library_requirements(
            recommended_names
        )
        result["availability"] = availability_info

    session = None
    if session_id:
        session = execution_engine.session_manager.get_or_create_session(session_id)

    auto_imported: List[str] = []
    auto_import_errors: List[Dict[str, Any]] = []

    if session and recommended_names:
        explicit = getattr(session, "explicit_library_preference", None)

        if explicit:
            recommended_names = [explicit] + [
                n for n in recommended_names if n != explicit
            ]
            if explicit == "SeleniumLibrary" and "Browser" in recommended_names:
                recommended_names = [n for n in recommended_names if n != "Browser"]
            if explicit == "Browser" and "SeleniumLibrary" in recommended_names:
                recommended_names = [
                    n for n in recommended_names if n != "SeleniumLibrary"
                ]

            name_to_rec = {r.get("library_name"): r for r in recommendations}
            recommendations = [
                name_to_rec[n] for n in recommended_names if n in name_to_rec
            ]
            result["recommendations"] = recommendations
            result["recommended_libraries"] = recommended_names

        for lib in recommended_names:
            try:
                session.import_library(lib, force=True)
            except Exception as e:
                logger.debug(f"Could not import {lib} into session {session_id}: {e}")

        available_set = set(
            (availability_info.get("available_libraries") or [])
            if availability_info
            else []
        )

        rf_mgr = get_rf_native_context_manager()
        processed: set[str] = set()
        for entry in recommendations:
            name = entry.get("library_name")
            if not name or name in processed:
                continue
            processed.add(name)
            if entry.get("is_builtin"):
                continue
            if availability_info and name not in available_set:
                continue
            try:
                import_result = rf_mgr.import_library_for_session(
                    session_id, name, args=(), alias=None
                )
            except Exception as exc:  # pragma: no cover - defensive
                auto_import_errors.append({"library": name, "error": str(exc)})
                continue
            if import_result.get("success"):
                auto_imported.append(name)
            else:
                auto_import_errors.append(
                    {"library": name, "error": import_result.get("error")}
                )

        session_setup_info: Dict[str, Any] = {
            "session_id": session_id,
            "auto_imports": {
                "imported": auto_imported,
                "errors": auto_import_errors,
            },
        }

        if apply_search_order:
            old_order = session.get_search_order()
            preferred = (
                availability_info.get("available_libraries", [])
                if availability_info
                else recommended_names
            )
            if explicit:
                preferred = [explicit] + [n for n in preferred if n != explicit]
                if explicit == "SeleniumLibrary":
                    preferred = [n for n in preferred if n != "Browser"]
                if explicit == "Browser":
                    preferred = [n for n in preferred if n != "SeleniumLibrary"]
            new_order = list(
                dict.fromkeys(
                    preferred + [lib for lib in old_order if lib not in preferred]
                )
            )
            session.set_library_search_order(new_order)
            session_setup_info.update(
                {
                    "old_search_order": old_order,
                    "new_search_order": new_order,
                    "applied": True,
                }
            )
        else:
            session_setup_info["applied"] = False

        result["session_setup"] = session_setup_info

    # Use LLM to refine/generate recommendations when enabled
    from robotmcp.utils.sampling import is_sampling_enabled as _sampling_on

    _do_llm = use_llm_refinement or (_sampling_on() and ctx is not None)
    if _do_llm:
        try:
            from robotmcp.utils.sampling import sample_recommend_libraries

            llm_recs = await sample_recommend_libraries(
                ctx, scenario, context, result.get("recommendations", [])
            )
            if llm_recs:
                # Use LLM recommendations, keeping rule-based metadata
                rule_recs = {
                    r.get("library_name", r.get("name", "")): r
                    for r in result.get("recommendations", [])
                }
                merged = []
                for llm_rec in llm_recs:
                    lib_name = llm_rec.get("library_name", "")
                    if lib_name in rule_recs:
                        # Enrich rule-based rec with LLM confidence/rationale
                        enriched = dict(rule_recs[lib_name])
                        enriched["llm_confidence"] = llm_rec.get("confidence", 0.8)
                        enriched["llm_rationale"] = llm_rec.get("rationale", "")
                        merged.append(enriched)
                    else:
                        merged.append(llm_rec)
                if merged:
                    result["recommendations"] = merged
                    result["recommended_libraries"] = [
                        r.get("library_name", r.get("name", "")) for r in merged
                    ]
                    result["llm_refined"] = True
                    result["sampling_enhanced"] = True
                    logger.info(f"LLM sampling generated {len(merged)} recommendations")
                else:
                    # Fallback to existing refinement
                    refined = await _refine_recommendations_with_llm(
                        ctx, scenario, context, result.get("recommendations", [])
                    )
                    if refined:
                        result["recommendations"] = refined
                        result["llm_refined"] = True
            else:
                # Fallback to existing refinement
                refined = await _refine_recommendations_with_llm(
                    ctx, scenario, context, result.get("recommendations", [])
                )
                if refined:
                    result["recommendations"] = refined
                    result["llm_refined"] = True
        except Exception as e:
            logger.debug(f"LLM recommendation failed, using rule-based: {e}")
            result["llm_refined"] = False

    # Steer API sessions to the proactive RequestsLibrary cookbook (change:
    # api-cookbook) so the agent pulls the response-access patterns UP FRONT
    # instead of rediscovering them through failed Evaluate steps.
    try:
        _rec_names = result.get("recommended_libraries") or [
            r.get("library_name") for r in (result.get("recommendations") or [])
        ]
        if any((n or "") == "RequestsLibrary" for n in _rec_names):
            result["api_guidance_hint"] = (
                "API testing: call get_locator_guidance(library='requests') for the "
                "RequestsLibrary request/response cookbook (session setup, "
                "${resp.json()[\"field\"]} access, Status Should Be, Cookie token "
                "header, expected_status= for non-2xx) BEFORE writing Evaluate-based "
                "assertions."
            )
    except Exception:  # pragma: no cover - defensive
        pass

    # Track for instruction learning
    if session_id:
        _track_tool_result(
            session_id,
            "recommend_libraries",
            {"scenario": scenario, "context": context},
            result,
        )

    return result


@mcp.tool
async def analyze_scenario(
    scenario: str, context: AutomationContext = "web", session_id: str = None, ctx: Context = None
) -> Dict[str, Any]:
    """Analyze a natural-language scenario into structured intent and create a session.

    WORKFLOW: This is the single front door — your FIRST tool call for any test
    scenario. It CREATES the session, so do NOT also call manage_session(action="init")
    for the same scenario (that causes redundant session churn). Reuse the returned
    session_id in every later call.

    What this tool does:
    1. Creates a new session with unique session_id (or reuses provided one)
    2. Analyzes scenario to detect context (web/api/mobile/desktop)
    3. Auto-configures libraries based on scenario text
    4. Returns session_id for use in ALL subsequent tool calls

    CRITICAL: Save the session_id from the response and use it in all other tool calls.

    Args:
        scenario: Human-language description of the task to automate.
        context: Application context (e.g., "web", "mobile", "api", "desktop");
            defaults to "web". An explicit context="desktop" DETERMINISTICALLY
            forces a native desktop (PlatynUI) session regardless of scenario
            wording — phrasing or word order cannot flip it to mobile/Appium.
            Use it for Linux/GNOME desktop GUI scenarios.
        session_id: Optional existing session id to reuse; if omitted, a new one is created.

    Returns:
        Dict[str, Any]: Structured intent and session metadata:
            - success: bool
            - session_id: created/resolved id (reuse for subsequent tools)
            - session_info: auto-configured libraries, search order, next-step guidance
            - intent/requirements/risk: parsed scenario details
            - error/guidance: present on failure

    Examples:
        analyze_scenario(
            scenario="Test REST API endpoint /users with GET request",
            context="api"
        )
        # Returns: {"session_id": "auto_generated_id", "recommended_libraries": ["RequestsLibrary"], ...}

        # Use session_id in ALL subsequent calls:
        execute_step(
            keyword="Create Session",
            arguments=["api", "https://api.example.com"],
            session_id="auto_generated_id"  # Use the returned session_id
        )
    """
    # Analyze the scenario first
    result = await nlp_processor.analyze_scenario(scenario, context)

    # Enhance with LLM sampling when feature flag is enabled
    from robotmcp.utils.sampling import is_sampling_enabled

    if is_sampling_enabled() and ctx:
        try:
            from robotmcp.utils.sampling import sample_analyze_scenario

            sampling_result = await sample_analyze_scenario(ctx, scenario, context)
            if sampling_result:
                # Merge LLM insights into rule-based result
                result["sampling_enhanced"] = True
                analysis = result.get("analysis", {})
                if sampling_result.get("session_type"):
                    analysis["detected_session_type"] = sampling_result["session_type"]
                # v5 (ADR-024 §11 — sampling override coherence Site A):
                # ONLY `library_preference` writes to `explicit_library_preference`.
                # `primary_library` is the LLM's "main library detected"
                # (a recommendation), not the user-stated explicit preference,
                # so it is no longer mapped to the explicit field. When the
                # override fires, evidence/conflicts are cleared and
                # preference_source flips to "sampling".
                if sampling_result.get("library_preference"):
                    analysis["explicit_library_preference"] = sampling_result[
                        "library_preference"
                    ]
                    analysis["preference_source"] = "sampling"
                    analysis.pop("explicit_library_evidence", None)
                    analysis.pop("library_preference_conflicts", None)
                    if sampling_result.get("rationale"):
                        analysis["sampling_evidence"] = sampling_result["rationale"]
                if sampling_result.get("detected_context"):
                    analysis["detected_context"] = sampling_result["detected_context"]
                result["analysis"] = analysis
                logger.info("Scenario analysis enhanced with LLM sampling")
        except Exception as e:
            logger.debug(f"LLM sampling enhancement failed, using rule-based: {e}")
            result["sampling_enhanced"] = False

    # ALWAYS create a session - either use provided ID or generate one
    if not session_id:
        session_id = execution_engine.session_manager.create_session_id()
        logger.info(f"Auto-generated session ID: {session_id}")
    else:
        logger.info(f"Using provided session ID: {session_id}")

    logger.info(
        f"Creating and auto-configuring session '{session_id}' based on scenario analysis"
    )

    # Get or create session using execution coordinator
    session = execution_engine.session_manager.get_or_create_session(session_id)

    # --- Attach bridge awareness (R2) ---
    # When a Debug Attach Bridge is configured, pre-populate the session from
    # the live RF process instead of relying solely on NLP scenario analysis.
    # This prevents accidental analyze_scenario calls from creating sessions
    # that are disconnected from the actual RF state.
    attach_bridge_active = False
    attach_client = _get_external_client_if_configured()
    if attach_client is not None:
        try:
            diag = attach_client.diagnostics()
            if diag.get("success"):
                attach_bridge_active = True
                bridge_libs = diag.get("result", {}).get("libraries", [])
                logger.info(
                    f"Attach bridge active: pre-populating session '{session_id}' "
                    f"with {len(bridge_libs)} libraries from live RF process"
                )
                # Import libraries discovered from the live RF process
                for lib_name in bridge_libs:
                    if lib_name not in session.imported_libraries:
                        try:
                            session.import_library(lib_name)
                            session.loaded_libraries.add(lib_name)
                        except Exception:
                            pass
                # Sync variables from the live RF process
                try:
                    var_resp = attach_client.get_variables()
                    if var_resp.get("success"):
                        bridge_vars = var_resp.get("result", {})
                        for var_name, var_value in bridge_vars.items():
                            # Strip ${} wrapper for session storage
                            base = var_name
                            if base.startswith("${") and base.endswith("}"):
                                base = base[2:-1]
                            session.variables[base] = var_value
                except Exception as ve:
                    logger.debug(f"Could not sync variables from bridge: {ve}")
                # Mark libraries as loaded since they come from the live process
                session.libraries_loaded = True
        except Exception as be:
            logger.debug(f"Attach bridge diagnostics failed: {be}")

    # Detect platform type from scenario
    platform_type = execution_engine.session_manager.detect_platform_from_scenario(
        scenario
    )

    # An explicit desktop context (or a text-detected desktop platform) forces a
    # native desktop session. This must win over the mobile path: the generic
    # "app" token in a desktop "application" scenario used to route to Appium
    # (maintainer-report #1). change: desktop-mcp-workflow-correctness.
    explicit_desktop = (context or "").lower() == "desktop"

    if explicit_desktop or platform_type == PlatformType.DESKTOP:
        # Auto-configure as a desktop (PlatynUI) session. Pass the context so an
        # explicit desktop request overrides any text-classifier ambiguity.
        session.configure_from_scenario(
            scenario, context="desktop" if explicit_desktop else None
        )
        logger.info(
            f"Initialized desktop session '{session_id}' "
            f"(explicit_context={explicit_desktop}, platform={platform_type.value})"
        )
    elif platform_type == PlatformType.MOBILE:
        execution_engine.session_manager.initialize_mobile_session(session, scenario)
        logger.info(
            f"Initialized mobile session for platform: {session.mobile_config.platform_name if session.mobile_config else 'Unknown'}"
        )
    else:
        # Auto-configure session based on scenario (existing web flow)
        session.configure_from_scenario(scenario)

    # Override session config with LLM-detected preferences when sampling enabled
    from robotmcp.utils.sampling import is_sampling_enabled as _is_sampling_on

    if _is_sampling_on() and ctx:
        try:
            from robotmcp.utils.sampling import (
                sample_detect_library_preference,
                sample_detect_session_type,
            )

            llm_lib_pref = await sample_detect_library_preference(ctx, scenario)
            if llm_lib_pref:
                session.explicit_library_preference = llm_lib_pref
                # v5 (ADR-024 §11 — sampling override coherence Site B):
                # tag the session aggregate's provenance so downstream
                # consumers can distinguish rule-based from LLM-driven.
                session.preference_source = "sampling"
                logger.info(f"LLM sampling detected library preference: {llm_lib_pref}")
            llm_session_type = await sample_detect_session_type(ctx, scenario, context)
            if llm_session_type:
                from robotmcp.models.session_models import SessionType

                try:
                    session.session_type = SessionType(llm_session_type)
                    logger.info(
                        f"LLM sampling detected session type: {llm_session_type}"
                    )
                except ValueError:
                    pass
        except Exception as e:
            logger.debug(f"LLM session config enhancement failed: {e}")

    # Compact session info — verbose guidance removed to reduce token cost
    result["session_type"] = session.session_type.value
    result["libraries_loaded"] = list(session.loaded_libraries)

    if attach_bridge_active:
        result["attach_bridge_active"] = True

    # API upfront guidance (change: refactor-mcp-instructions §4/§7.2): the lean default
    # steers agents through analyze_scenario (the front door) and NOT manage_session(init),
    # so the guaranteed api_guidance bundle must ride the analyze_scenario response too —
    # otherwise RequestsLibrary's non-obvious response-access rules (the #1 API turn-sink,
    # F-API1) never reach the flow agents actually take. Same gate/opt-out as init.
    try:
        if os.environ.get("ROBOTMCP_API_GUIDANCE", "on").lower() not in (
            "off", "0", "false", "no",
        ):
            # RequestsLibrary is only *recommended* at analyze time (not yet loaded),
            # so key off the detected API signal, not loaded_libraries.
            _suggested = (result.get("analysis") or {}).get("suggested_libraries") or []
            _api_session = (
                any(lib == "RequestsLibrary" for lib in session.loaded_libraries)
                or getattr(session.session_type, "value", "") == "api_testing"
                or "RequestsLibrary" in _suggested
            )
            if _api_session:
                from robotmcp.utils.requests_guidance import build_api_init_guidance

                _api_bundle = build_api_init_guidance()
                if _api_bundle:
                    result["api_guidance"] = _api_bundle
    except Exception:  # pragma: no cover - defensive
        pass

    logger.info(
        f"Session '{session_id}' configured: type={session.session_type.value}, preference={session.explicit_library_preference}"
    )

    result["session_id"] = session_id
    result["context"] = context

    # Start instruction learning tracking for this session
    try:
        hooks = _get_instruction_hooks()
        # Detect scenario type from context
        scenario_type = "unknown"
        if context == "web":
            scenario_type = "web_automation"
        elif context == "api":
            scenario_type = "api_testing"
        elif context == "mobile":
            scenario_type = "mobile_testing"
        elif context == "desktop":
            scenario_type = "desktop_automation"

        hooks.on_session_start(
            session_id=session_id,
            instruction_mode=os.environ.get("ROBOTMCP_INSTRUCTION_MODE", "default"),
            scenario_type=scenario_type,
        )
        # Track the analyze_scenario call
        _track_tool_result(
            session_id,
            "analyze_scenario",
            {"scenario": scenario, "context": context},
            result,
        )
    except Exception as e:
        logger.debug(f"Failed to start instruction learning: {e}")

    # ADR-014.2: Augment analyze_scenario with memory hints
    result = await _augment_with_memory(
        session_id, "analyze_scenario",
        {"scenario": scenario, "context": context}, result,
    )

    return result


def _filter_keywords_by_session_library(
    keywords: List[Dict[str, Any]],
    session_id: str | None,
    session_library_preference: str | None,
    strict_library: bool = False,
) -> tuple[List[Dict[str, Any]], List[Dict[str, str]]]:
    """Filter keywords to only include those compatible with session library preference.

    Uses plugin system to determine incompatible libraries and keyword alternatives.

    Args:
        keywords: List of keyword dicts with 'name' and 'library' fields
        session_id: Session ID for logging
        session_library_preference: Explicit library preference (e.g., "Browser", "SeleniumLibrary")
        strict_library: OBS-33 — when True AND a preference is set,
            exclude EVERY library that isn't the named one (not just
            the plugin's incompatible siblings). Compatible "neutral"
            libraries like BuiltIn/Collections/etc. are dropped too.
            Default False preserves the existing "incompatible-only"
            behaviour.

    Returns:
        Tuple of (filtered_keywords, excluded_keywords_with_alternatives)
    """
    if not session_library_preference or not keywords:
        return keywords, []

    # Get incompatible libraries from plugin
    plugin_manager = get_library_plugin_manager()
    excluded_libraries = set(
        plugin_manager.get_incompatible_libraries(session_library_preference)
    )

    if strict_library:
        # OBS-33 — extend excluded_libraries to cover ALL non-preferred
        # libraries. Compute from the actual keywords list so we don't
        # have to enumerate every possible library globally.
        all_libs_in_input = {kw.get("library", "") for kw in keywords if kw.get("library")}
        excluded_libraries = excluded_libraries | (
            all_libs_in_input - {session_library_preference}
        )

    if not excluded_libraries:
        return keywords, []

    # Get keyword alternatives from plugin for helpful messages
    keyword_alternatives = plugin_manager.get_keyword_alternatives(
        session_library_preference
    )

    filtered_keywords = []
    excluded_with_alternatives = []

    for kw in keywords:
        kw_library = kw.get("library", "")
        kw_name = kw.get("name", "")

        if kw_library in excluded_libraries:
            # This keyword is from an incompatible library
            kw_lower = kw_name.lower()
            alt_info = keyword_alternatives.get(kw_lower, {})

            excluded_info = {
                "keyword": kw_name,
                "incompatible_library": kw_library,
                "session_library": session_library_preference,
                "reason": f"Keyword '{kw_name}' is from {kw_library}, but session uses {session_library_preference}",
            }

            if alt_info:
                excluded_info["alternative"] = alt_info.get("alternative")
                excluded_info["example"] = alt_info.get("example")

            excluded_with_alternatives.append(excluded_info)
        else:
            filtered_keywords.append(kw)

    if excluded_with_alternatives:
        logger.info(
            f"Session {session_id}: Filtered out {len(excluded_with_alternatives)} "
            f"keywords from incompatible libraries: {list(excluded_libraries)} "
            f"(strict_library={strict_library})"
        )

    return filtered_keywords, excluded_with_alternatives


def _rebuild_post_filter_recommendations(
    matches: List[Dict[str, Any]],
) -> List[str]:
    """Regenerate the semantic matcher's usage recommendations using
    post-filter matches.

    ``KeywordMatcher.discover_keywords`` computes ``recommendations``
    inline from the *pre-filter* ranked matches and embeds them in its
    response. When ``find_keywords`` applies a library filter, the
    pre-filter top match (the "Best match: X (confidence: Y)" line)
    can reference an excluded keyword — contradicting the post-filter
    ``matches`` list and pointing the agent at an unavailable keyword.

    Reproduced 2026-05-17: with ``library_name="Browser"`` and query
    "open browser page navigate to url", the matches list contained
    only Browser keywords (Go To, New Page, Open Browser) but
    recommendations[0] was ``"Best match: Get Browser Aliases
    (confidence: 0.84)"`` — a SeleniumLibrary keyword that had just
    been filtered out.

    This helper mirrors the matcher's format
    (``KeywordMatcher._generate_usage_recommendations``) but operates
    on the post-filter dict shape (matches come in as dicts with
    ``keyword_name``, ``confidence``, ``arguments`` rather than
    ``KeywordMatch`` dataclasses). Kept in server.py rather than the
    matcher because the matcher has no visibility into the filter.
    """
    if not matches:
        return [
            "No matching keywords found. Consider:",
            "- Check if required libraries are imported",
            "- Rephrase the action description",
            "- Use more specific terms",
        ]
    recs: List[str] = []
    top = matches[0]
    name = top.get("keyword_name") or top.get("name") or "<unknown>"
    confidence = top.get("confidence")
    if isinstance(confidence, (int, float)):
        recs.append(f"Best match: {name} (confidence: {confidence:.2f})")
    else:
        recs.append(f"Best match: {name}")
    args = top.get("arguments") or []
    if args:
        recs.append(f"Required arguments: {', '.join(args)}")
    if len(matches) > 1:
        alt_names = [
            (m.get("keyword_name") or m.get("name") or "<unknown>")
            for m in matches[1:4]
        ]
        recs.append(f"Alternative options: {', '.join(alt_names)}")
    return recs


def _build_session_recommendations(
    matches: List[Dict[str, Any]], query: str,
) -> List[str]:
    """OBS-23B-impl — build honest recommendations prose for the
    session strategy.

    Session strategy is a literal name-substring lookup. There's no
    ranking, so the prose names the kind of match found (exact name
    vs substring) WITHOUT a fake confidence number (round-1 review
    flagged ``confidence: 1.00`` as dishonest).
    """
    if not matches:
        return [
            "No keywords match the query in this session.",
            "- Verify the query string",
            "- Check the session's imported libraries",
        ]
    q_lower = (query or "").lower().strip()
    exact = None
    if q_lower:
        for m in matches:
            if m.get("keyword_name", "").lower() == q_lower:
                exact = m
                break
    top = exact or matches[0]
    top_name = top.get("keyword_name", "")
    top_lib = top.get("library") or top.get("source") or "session"
    if exact:
        recs = [f"Exact match: {top_name} ({top_lib})"]
    else:
        if q_lower:
            recs = [
                f"Substring match: {top_name} ({top_lib}); "
                f"no exact name match for '{query}'"
            ]
        else:
            recs = [f"First in session: {top_name} ({top_lib})"]
    # Required-arguments line intentionally OMITTED — session strategy
    # doesn't have per-keyword arg info from list_available_keywords.
    # Agents fetch full info via get_keyword_info(mode="keyword",
    # keyword_name=..., session_id=...) if needed.
    if len(matches) > 1:
        alt_names = [m.get("keyword_name", "") for m in matches[1:4]]
        recs.append(f"Alternative options: {', '.join(alt_names)}")
    return recs


def _build_filter_diagnostics(
    excluded: List[Dict[str, Any]],
    applied: str,
    source: str,
    strict_library: bool = False,
) -> Dict[str, Any]:
    """Build compact response diagnostics for a library filter pass.

    Replaces the legacy verbose ``excluded_keywords`` shape (7+ entries
    × ~150 tokens each, with ``incompatible_library``/``session_library``/
    ``reason`` fields repeated identically) with a compact summary:

      library_filter: {applied, source, from_library, count}
      excluded_alternatives: [{keyword, alternative, example}, ...]
        — only entries that carry actionable SL→Browser (or vice versa)
        translation info from the plugin's KEYWORD_ALTERNATIVES table.

    For the typical Browser-filter-applied response (~7 excluded SL
    keywords with one or two alternatives), this cuts the inline
    response from ~1100 tokens to ~75 tokens. Bare excluded keyword
    names are dropped — the agent already learns "X was filtered" from
    X's absence in the ``matches`` list, so re-listing them adds zero
    information.
    """
    # Derive the unique-incompatible-library label. In practice it's a
    # single library (Browser ↔ SeleniumLibrary in current plugins) but
    # the table semantics allow multiples; surface as a comma-joined
    # label rather than a list, since the agent reads a string.
    libs = sorted({
        e.get("incompatible_library")
        for e in excluded
        if e.get("incompatible_library")
    })
    from_library: str | None = libs[0] if len(libs) == 1 else (
        ", ".join(libs) if libs else None
    )

    diagnostics: Dict[str, Any] = {
        "library_filter": {
            "applied": applied,
            "source": source,
            "count": len(excluded),
            # OBS-33 — agent visibility into which filter rule fired.
            # "strict" = ALL non-preferred libraries excluded.
            # "compatible" = only plugin-table-incompatible siblings
            # excluded (BuiltIn, Collections, etc. stay visible).
            "mode": "strict" if strict_library else "compatible",
        }
    }
    if from_library:
        diagnostics["library_filter"]["from_library"] = from_library

    actionable = [
        {
            "keyword": e["keyword"],
            "alternative": e["alternative"],
            "example": e.get("example"),
        }
        for e in excluded
        if e.get("alternative")
    ]
    if actionable:
        diagnostics["excluded_alternatives"] = actionable
    return diagnostics


@mcp.tool
async def find_keywords(
    query: str,
    strategy: KeywordStrategy = "semantic",
    context: AutomationContext = "web",
    session_id: str | None = None,
    library_name: str | None = None,
    current_state: Dict[str, Any] | None = None,
    limit: int | None = None,
    strict_library: bool = False,
) -> Dict[str, Any]:
    """Discover Robot Framework keywords using multiple strategies.

    WHEN TO USE THIS TOOL:
    - ALWAYS before calling execute_step with an unfamiliar keyword
    - When you're unsure of exact keyword name or spelling
    - To discover what keywords are available in imported libraries
    - When error says "No keyword with name 'X' found"

    Args:
        query: Search text or intent description.
               Examples: "click a button", "validate json", "get*request"
        strategy: Discovery approach:
                  - "semantic": Hybrid keyword search combining name/doc
                    pattern matching, tag/action-class classification, and
                    (when installed) sentence-transformers embedding
                    similarity. For best semantic ranking, install the
                    optional extra: ``uv add robotmcp[semantic]``. Without
                    the extra, falls back to pattern + tag + difflib
                    SequenceMatcher ranking; the strategy is still useful
                    but ranking quality is reduced.
                  - "pattern": Glob/regex matching (best when you know partial name)
                  - "catalog": List all available keywords. This is a LITERAL
                    substring filter on keyword/library names — a multi-word
                    natural-language query will return 0; use library_name= to
                    list a library (e.g. "PlatynUI"/"PlatynUI.BareMetal"), or
                    strategy="semantic" for intent matching.
                  - "session": List keywords from session's loaded libraries
        context: Scenario context (e.g., "web", "mobile", "api") used by semantic discovery.
        session_id: Required for strategy="session" to search the live RF namespace.
        library_name: Optional library filter applied to ALL strategies.
                      When set, restricts results to the named library and its
                      compatible siblings (e.g., library_name="Browser" excludes
                      SeleniumLibrary but keeps BuiltIn, Collections, String).
                      Takes precedence over the session's
                      explicit_library_preference when both are present.
                      Catalog strategy additionally scopes the underlying
                      lookup to this library.
        current_state: Optional state payload to improve semantic matching.
        limit: Optional maximum number of results to return.
        strict_library: OBS-33 — when True AND a library preference is
                        set (via ``library_name`` or session
                        ``explicit_library_preference``), exclude EVERY
                        library that isn't the preferred one. Default
                        behaviour (False) preserves "compatible siblings"
                        — BuiltIn / Collections / String / DateTime etc.
                        remain visible alongside the preferred library.
                        Use strict mode to scope discovery tightly to
                        a single library (e.g., pattern ``"Get*"`` +
                        ``library_name="Browser"`` +
                        ``strict_library=True`` → Browser keywords only,
                        no BuiltIn helpers).

    Returns:
        Dict[str, Any]: Discovery result:
            - success: bool
            - strategy: strategy used
            - query: original query
            - result/results: strategy-specific payload
            - error: present on failure

    Examples:
        Discover button-clicking keywords:
            find_keywords(
                query="click a button",
                strategy="semantic",
                session_id="web_session"
            )
            # Returns: ["Click", "Click Button", "Click Element", ...]

        Find keywords matching pattern:
            find_keywords(
                query="Get*",
                strategy="pattern",
                session_id="api_session"
            )
            # Returns: ["GET", "Get Request", "Get Element", ...]
    """

    strategy_norm = (strategy or "semantic").strip().lower()

    # Resolve a short library alias (e.g. "PlatynUI" -> "PlatynUI.BareMetal")
    # so desktop keyword discovery works under either name.
    # change: desktop-mcp-workflow-correctness (maintainer-report #5).
    if library_name:
        from robotmcp.components.library_recommender import LibraryRecommender

        library_name = LibraryRecommender.resolve_library_alias(library_name)

    # BDD prefix stripping for query (ADR-019)
    from robotmcp.domains.keyword_resolution.services import BddPrefixService
    if query:
        bdd_query_result = BddPrefixService.strip_prefix(query)
        if bdd_query_result.has_prefix:
            query = bdd_query_result.stripped_name
            logger.debug(
                f"Stripped BDD prefix from find_keywords query: "
                f"'{bdd_query_result.original_name}' -> '{query}'"
            )

    # OBS-24 — Empty/whitespace-only queries against semantic/pattern
    # strategies fall through to the matcher and produce bogus low-
    # confidence "hits" (e.g. confidence=0.35 against an empty action
    # description). Short-circuit before that with a clear hint to
    # use catalog strategy when an unfiltered listing is needed.
    # Catalog + session strategies handle empty queries by design
    # (list everything in scope) and are intentionally not gated.
    if strategy_norm in {"semantic", "intent", "pattern", "search"}:
        if not query or not query.strip():
            return {
                "success": False,
                "strategy": strategy_norm,
                "query": query,
                "error": (
                    f"Query string is required for strategy='{strategy_norm}'"
                ),
                "hint": (
                    "Use strategy='catalog' to list available keywords "
                    "without a query, or strategy='session' if a session is "
                    "active."
                ),
            }

    current_state = current_state or {}
    limit_value: int | None = None
    if limit is not None:
        try:
            limit_value = int(limit)  # type: ignore[arg-type]
        except (TypeError, ValueError):
            limit_value = None

    # Resolve effective library preference for filtering.
    # Precedence (highest wins):
    #   1. Explicit ``library_name`` parameter (per-call override)
    #   2. Session's ``explicit_library_preference`` (session-wide default)
    #   3. None (no filter)
    # The same filter (plugin-driven incompatibility table) applies in
    # both cases — ``library_name="Browser"`` excludes the same libraries
    # as a Browser-preference session would.  Catalog strategy ALSO uses
    # ``library_name`` to scope its underlying lookup; the per-strategy
    # branches below preserve that behaviour and additionally apply the
    # post-filter for consistency.
    effective_library_preference: str | None = None
    library_filter_source: str = ""
    if library_name:
        effective_library_preference = library_name
        library_filter_source = "library_name"
    elif session_id:
        session = execution_engine.session_manager.get_session(session_id)
        if session:
            session_pref = getattr(
                session, "explicit_library_preference", None
            )
            if session_pref:
                effective_library_preference = session_pref
                library_filter_source = "session"
            else:
                # OBS-20 — discovery/execution filter symmetry. The
                # Browser plugin's execute-time validation at
                # ``browser_plugin.py:312-321`` rejects SeleniumLibrary
                # keywords whenever Browser is imported (regardless of
                # explicit preference). The SeleniumLibrary plugin is
                # ASYMMETRIC — it only acts on explicit
                # ``selenium*``-prefixed preference. Mirror those exact
                # rules here so discovery surfaces match what
                # execute_step will accept.
                imported = set(
                    getattr(session, "imported_libraries", []) or []
                )
                # Browser is the only plugin with imported-fallback.
                # SL plugin does NOT mirror this — keep the asymmetry.
                if "Browser" in imported:
                    effective_library_preference = "Browser"
                    library_filter_source = "session_imported"

    if strategy_norm in {"semantic", "intent"}:
        # OBS-22 — thread ``limit`` into the matcher so the matcher's
        # hard cap (default 10 at keyword_matcher.py:307) honours
        # caller intent. Without this the semantic branch silently
        # ignored ``limit`` — pattern/catalog branches applied it via
        # ``matches[:limit_value]`` but semantic didn't.
        discovery = await keyword_matcher.discover_keywords(
            query, context, current_state, limit=limit_value,
        )

        # Apply library filtering when an effective preference is set
        # (from library_name OR session preference).
        excluded = []
        if effective_library_preference and discovery.get("matches"):
            # Convert semantic matches to format expected by filter function
            matches_for_filter = [
                {"name": m.get("keyword_name"), "library": m.get("library"), **m}
                for m in discovery.get("matches", [])
            ]
            filtered_matches, excluded = _filter_keywords_by_session_library(
                matches_for_filter, session_id, effective_library_preference,
                strict_library=strict_library,
            )
            # Convert back to original format
            discovery["matches"] = [
                {k: v for k, v in m.items() if k not in ("name",)}
                for m in filtered_matches
            ]
            discovery["filtered_count"] = len(excluded)

            # OBS-18B post-filter cap MUST run BEFORE the
            # recommendation rebuild so the rebuild can read the
            # capped confidence value (round-3 review caught: pre-fix
            # ordering produced contradictory output where
            # ``matches[0].confidence`` was 0.50 but
            # ``recommendations[0]`` still said "confidence: 0.72").
            # The matcher's pre-filter cap may have targeted a match
            # the filter then removed, leaving the actual user-
            # visible top match uncapped.
            try:
                from robotmcp.components.keyword_matcher import (
                    _classify_query_action_class,
                    _reranker_enabled,
                    apply_confidence_cap_dict,
                )
                if _reranker_enabled() and discovery.get("matches"):
                    qclass = _classify_query_action_class(query)
                    capped_matches, low_conf = apply_confidence_cap_dict(
                        discovery["matches"], qclass,
                    )
                    discovery["matches"] = capped_matches
                    # CLEAR the flag if no trigger fired post-filter
                    # (otherwise a matcher-set flag would persist as a
                    # false positive once the filter shuffled the top
                    # match into a non-divergent set).
                    if low_conf:
                        discovery["low_confidence_top_match"] = True
                    else:
                        discovery.pop("low_confidence_top_match", None)
            except Exception:
                # Reranker enrichment is best-effort.
                pass

            # Regenerate recommendations against the post-filter,
            # post-cap matches — the matcher emits its
            # recommendations BEFORE we apply the library filter +
            # post-filter cap. Only rebuild when the filter actually
            # trimmed entries — if ``excluded`` is empty, the
            # matcher's recommendations are still accurate.
            if excluded:
                discovery["recommendations"] = (
                    _rebuild_post_filter_recommendations(
                        discovery["matches"]
                    )
                )

        # Make the session's OWN project keywords discoverable alongside rf-mcp's
        # catalogue (change: project-keyword-discovery).
        _merge_project_keywords(
            discovery, query, session_id,
            # Only an EXPLICIT per-call library_name scopes project keywords. The
            # session-derived preference is "Browser"/"SeleniumLibrary" in any web
            # session; passing it here matched no project source, so a web
            # session's own project keywords were excluded from every query.
            library_name=library_name,
            strict_library=strict_library,
        )

        result = {
            "success": bool(discovery.get("success", True)),
            "strategy": "semantic",
            "query": query,
            "result": discovery,
        }
        if excluded:
            result.update(
                _build_filter_diagnostics(
                    excluded,
                    effective_library_preference,
                    library_filter_source,
                    strict_library=strict_library,
                )
            )
        # ADR-015: Externalize large fields to artifacts
        if session_id:
            result = _externalize_response("find_keywords", session_id, result)
        # Track for instruction learning
        if session_id:
            _track_tool_result(
                session_id,
                "find_keywords",
                {"query": query, "strategy": strategy},
                result,
            )
        return result

    if strategy_norm in {"pattern", "search"}:
        await _ensure_all_session_libraries_loaded()
        matches = execution_engine.search_keywords(query)

        # Apply library filtering when an effective preference is set.
        excluded = []
        if effective_library_preference:
            matches, excluded = _filter_keywords_by_session_library(
                matches, session_id, effective_library_preference,
                strict_library=strict_library,
            )

        if limit_value is not None:
            matches = matches[:limit_value]

        # ADR-019: Annotate embedded argument keywords
        import re as _re
        for kw in matches:
            kw_name = kw.get("name", "")
            if "${" in kw_name:
                kw["embedded_args"] = True
                kw["usage_example"] = _re.sub(
                    r'\$\{([^}:]+)(?::[^}]*)?\}', r'<\1>', kw_name
                )

        # Add compact top_matches summary for LLM (full results may be externalized)
        top_names = [m.get("name", "") for m in matches[:5]]
        result = {
            "success": True,
            "strategy": "pattern",
            "query": query,
            "match_count": len(matches),
            "top_matches": top_names,
            "results": matches,
        }
        if excluded:
            result.update(
                _build_filter_diagnostics(
                    excluded,
                    effective_library_preference,
                    library_filter_source,
                    strict_library=strict_library,
                )
            )
        # ADR-015: Externalize large fields to artifacts
        if session_id:
            result = _externalize_response("find_keywords", session_id, result)
        # Track for instruction learning
        if session_id:
            _track_tool_result(
                session_id,
                "find_keywords",
                {"query": query, "strategy": strategy},
                result,
            )
        return result

    if strategy_norm in {"catalog", "library"}:
        await _ensure_all_session_libraries_loaded()
        project_catalog = _project_catalog_entries(session_id, library_name)
        if library_name and project_catalog:
            # Scoped to a project source: the engine does not know it by name.
            catalog = project_catalog
        else:
            catalog = execution_engine.get_available_keywords(library_name)
            if not library_name and project_catalog:
                seen = {(c.get("name"), c.get("library")) for c in project_catalog}
                catalog = project_catalog + [
                    c for c in catalog if (c.get("name"), c.get("library")) not in seen
                ]
        if query:
            lowered = query.lower()
            catalog = [
                item
                for item in catalog
                if lowered in (item.get("name") or "").lower()
                or lowered in (item.get("library") or "").lower()
            ]

        # Apply library filtering when an effective preference is set.
        # NB: ``execution_engine.get_available_keywords(library_name)``
        # already scopes the engine lookup by library_name; the post-
        # filter is largely a no-op when library_name is set, but stays
        # consistent with the semantic/pattern branches and catches
        # cross-library matches the engine might return for sibling-
        # library queries (rare).
        excluded = []
        if effective_library_preference:
            catalog, excluded = _filter_keywords_by_session_library(
                catalog, session_id, effective_library_preference,
                strict_library=strict_library,
            )

        # OBS-25 — Hard-cap unscoped catalog dumps to prevent the 97k
        # token whale observed in benchmark S20
        # (find_keywords(strategy="catalog") with no session, no
        # library_name, no query returns 658 keywords across 10
        # libraries). The cap only applies when ALL three scoping
        # mechanisms are absent — a scoped catalog call is intentional
        # and shouldn't be truncated.
        catalog_truncated = False
        full_catalog_size = 0
        if (
            not session_id
            and not library_name
            and not query
            and not effective_library_preference
        ):
            # Codex round-3 review caught: raw ``int()`` raises on
            # invalid env values (e.g., ``ROBOTMCP_CATALOG_HARD_CAP="abc"``),
            # turning a discovery call into a 500. Fall back to 100
            # on parse failure with a single WARNING-level log so
            # operators see the misconfiguration.
            try:
                hard_cap = int(os.getenv("ROBOTMCP_CATALOG_HARD_CAP", "100"))
                if hard_cap <= 0:
                    raise ValueError("must be > 0")
            except (TypeError, ValueError) as _e:
                logger.warning(
                    "Invalid ROBOTMCP_CATALOG_HARD_CAP=%r; falling back to 100",
                    os.getenv("ROBOTMCP_CATALOG_HARD_CAP"),
                )
                hard_cap = 100
            if len(catalog) > hard_cap:
                full_catalog_size = len(catalog)
                libraries = sorted({c.get("library", "?") for c in catalog})
                catalog = catalog[:hard_cap]
                catalog_truncated = True
                catalog_hint = (
                    f"Catalog returned {full_catalog_size} keywords across "
                    f"{len(libraries)} libraries. Use library_name= or a "
                    f"query= filter to narrow the result, or pass "
                    f"session_id= to enable externalisation. First "
                    f"{hard_cap} entries returned."
                )

        if limit_value is not None:
            catalog = catalog[:limit_value]

        # ADR-019: Annotate embedded argument keywords
        import re as _re
        for kw in catalog:
            kw_name = kw.get("name", "")
            if "${" in kw_name:
                kw["embedded_args"] = True
                kw["usage_example"] = _re.sub(
                    r'\$\{([^}:]+)(?::[^}]*)?\}', r'<\1>', kw_name
                )

        # Add compact top_matches summary for LLM (full results may be externalized)
        top_names = [c.get("name", "") for c in catalog[:5]]
        result = {
            "success": True,
            "strategy": "catalog",
            "query": query,
            "library": library_name,
            "match_count": len(catalog),
            "top_matches": top_names,
            "results": catalog,
        }
        if excluded:
            result.update(
                _build_filter_diagnostics(
                    excluded,
                    effective_library_preference,
                    library_filter_source,
                    strict_library=strict_library,
                )
            )

        # OBS-25: surface the hard-cap diagnostic + full size when the
        # cap fired so the agent knows the response was truncated and
        # how to scope down.
        if catalog_truncated:
            result["catalog_truncated"] = True
            result["full_catalog_size"] = full_catalog_size
            result["hint"] = catalog_hint

        # ADR-010 I3: Hint when catalog returns empty without active session
        if not catalog and not session_id and not query:
            result["hint"] = (
                "Catalog is empty because no session with libraries is active. "
                "Create a session first with manage_session(action='init', "
                "libraries=[...]), or use strategy='semantic' which works "
                "without a session."
            )
        # The catalog strategy is a LITERAL substring filter on keyword/library
        # names. A multi-word natural-language query (e.g. "get window find
        # element ui tree") will not match and returns 0 — do not strand the
        # agent. change: desktop-mcp-workflow-correctness (maintainer-report #5).
        elif not catalog and query:
            result["hint"] = (
                f"Catalog strategy is a literal substring filter; the query "
                f"'{query}' matched no keyword or library name. To list a "
                f"library's keywords use library_name= (e.g. "
                f"library_name='PlatynUI.BareMetal'), or use strategy='semantic' "
                f"for natural-language intent matching."
            )
        # ADR-015: Externalize large fields to artifacts
        if session_id:
            result = _externalize_response("find_keywords", session_id, result)
        # Track for instruction learning
        if session_id:
            _track_tool_result(
                session_id,
                "find_keywords",
                {"query": query, "strategy": strategy},
                result,
            )
        return result

    if strategy_norm in {"session", "namespace"}:
        if not session_id:
            return {
                "success": False,
                "error": "session_id is required when strategy='session'",
            }
        mgr = get_rf_native_context_manager()
        # OBS-23A — pass the caller's ``query`` as a name_filter and
        # ``limit_value`` as the trim cap. Pre-OBS-23A behaviour
        # (no filter, no limit) is preserved when both are absent.
        payload = mgr.list_available_keywords(
            session_id,
            name_filter=query if query else None,
            limit=limit_value,
        )

        # OBS-23B-impl Phase 1 — dual-emit:
        # 1. Build the unified ``result.matches`` shape that matches
        #    semantic/pattern/catalog strategies.
        # 2. Preserve the legacy top-level ``library_keywords`` /
        #    ``resource_keywords`` / ``libraries_count`` fields for
        #    backwards-compat through Phase 2 (target v0.34) →
        #    Phase 3 removal (target v0.36).
        # Per round-1 review fixes: match_type replaces dishonest
        # confidence=1.00; match_count dropped (redundant with
        # len(matches)).
        unified_matches: List[Dict[str, Any]] = []
        for kw in (payload.get("library_keywords") or []):
            unified_matches.append({
                "keyword_name": kw.get("name", ""),
                "library": kw.get("library"),
                "full_name": kw.get("full_name", kw.get("name", "")),
                "match_type": "exact_substring",
                "source_type": "library",
                "source": None,
            })
        for kw in (payload.get("resource_keywords") or []):
            unified_matches.append({
                "keyword_name": kw.get("name", ""),
                "library": None,
                "full_name": kw.get("full_name", kw.get("name", "")),
                "match_type": "exact_substring",
                "source_type": "resource",
                "source": kw.get("resource"),
            })

        # OBS-33 (Wave-3 round-1 review fix) — apply library filter +
        # strict_library to the unified matches in session strategy.
        # Pre-fix: the session branch entirely bypassed
        # ``_filter_keywords_by_session_library``, so OBS-33 had no
        # effect on this strategy. Now we apply the SAME resolved
        # preference (effective_library_preference) + strict_library
        # flag that semantic/pattern/catalog use. Wraps each match
        # into the filter's expected ``{name, library, ...}`` shape,
        # then converts back. Resource entries (library=None) are
        # exempt — filter operates on library names only.
        session_excluded: List[Dict[str, Any]] = []
        if effective_library_preference and unified_matches:
            lib_matches = [
                {"name": m["keyword_name"], "library": m["library"], **m}
                for m in unified_matches if m.get("library")
            ]
            resource_matches = [m for m in unified_matches if not m.get("library")]
            kept, session_excluded = _filter_keywords_by_session_library(
                lib_matches, session_id, effective_library_preference,
                strict_library=strict_library,
            )
            unified_matches = [
                {k: v for k, v in m.items() if k != "name"} for m in kept
            ] + resource_matches

        # OBS-23B recommendations (no fake confidence — honest prose
        # about how the match was found).
        recommendations = _build_session_recommendations(
            unified_matches, query,
        )

        # Build the response with BOTH the unified shape under `result`
        # AND the legacy top-level fields (Phase 1 dual-emit).
        response: Dict[str, Any] = {
            "success": payload.get("success", True),
            "strategy": "session",
            "query": query,
            # OBS-23B-impl backwards-compat fix (Wave-3 round-1):
            # propagate ``session_id`` from the legacy backend payload
            # so callers reading it at top level continue to work.
            "session_id": payload.get("session_id", session_id),
            "result": {
                "matches": unified_matches,
                "library_count": len({
                    m["library"] for m in unified_matches if m["library"]
                }),
                "resource_count": len({
                    m["source"] for m in unified_matches if m["source"]
                }),
                "recommendations": recommendations,
            },
            # OBS-23B Phase 1 legacy fields (target removal: OBS-35 / v0.36)
            "library_keywords": payload.get("library_keywords") or [],
            "resource_keywords": payload.get("resource_keywords") or [],
            "libraries_count": payload.get("libraries_count", 0),
        }
        # OBS-23A diagnostic fields surface under ``result``
        # (pre-trim vs post-filter visibility for the agent).
        if "total_before_trim" in payload:
            response["result"]["total_before_trim"] = payload["total_before_trim"]
        if "total_after_filter" in payload:
            response["result"]["total_after_filter"] = payload["total_after_filter"]
        # OBS-33 — surface filter diagnostics when filtering applied
        if session_excluded:
            response.update(
                _build_filter_diagnostics(
                    session_excluded,
                    effective_library_preference,
                    library_filter_source,
                    strict_library=strict_library,
                )
            )
        # Propagate session error path if applicable
        if not payload.get("success") and payload.get("error"):
            response["error"] = payload["error"]

        # ADR-015: Externalize large fields to artifacts
        response = _externalize_response("find_keywords", session_id, response)
        # Track for instruction learning
        _track_tool_result(
            session_id, "find_keywords", {"query": query, "strategy": strategy}, response
        )
        return response

    return {"success": False, "error": f"Unsupported strategy '{strategy}'"}


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def discover_keywords(
    action_description: str, context: str = "web", current_state: Dict[str, Any] = None
) -> Dict[str, Any]:
    """Find matching Robot Framework keywords for an action.

    Args:
        action_description: Description of the action to perform
        context: Current context (web, mobile, API, etc.)
        current_state: Current application state
    """
    if current_state is None:
        current_state = {}
    return await keyword_matcher.discover_keywords(
        action_description, context, current_state
    )


@mcp.tool
async def manage_session(
    action: SessionAction,
    session_id: str = "",
    libraries: OptionalCoercedStringList = None,
    variables: CoercedVariables = None,
    resource_path: str | None = None,
    library_name: str | None = None,
    args: OptionalCoercedStringList = None,
    alias: str | None = None,
    scope: Literal["test", "suite", "global"] = "suite",
    variable_file_path: str | None = None,
    # ADR-005: Multi-test parameters
    test_name: str | None = None,
    test_documentation: str = "",
    test_tags: OptionalCoercedStringList = None,
    test_setup: Dict[str, Any] | None = None,
    test_teardown: Dict[str, Any] | None = None,
    template: str | None = None,  # ADR-019: template keyword for data-driven [Template]
    test_status: TestStatus = "pass",
    test_message: str = "",
    keyword: str | None = None,
    # ADR-006: Tool profile parameters
    tool_profile: ToolProfileName | None = None,
    model_tier: ModelTierLiteral | None = None,
    scenario: str | None = None,
    profile: ToolProfileName | None = None,
    # ADR-016: Auto-detect model tier from model name
    model_name: str | None = None,
) -> Dict[str, Any]:
    """Manage session lifecycle: initialize, configure libraries/variables, and organize tests.

    For a NEW scenario, prefer analyze_scenario — it is the front door that CREATES
    the session (and auto-configures libraries). Use manage_session for explicit session
    ops on an existing session (importing extra libraries/resources/variables, multi-test
    structure). Do NOT call action="init" right after analyze_scenario — the session
    already exists; that only causes redundant churn.

    Workflows:
        Single test:  analyze_scenario -> execute_step (repeat) -> build_test_suite
        Multi-test:   analyze_scenario -> set_suite_setup -> start_test -> execute_step
                      (repeat) -> end_test -> start_test -> ... -> build_test_suite
        (action="init" is the explicit alternative when you are NOT starting from
        analyze_scenario, e.g. driving a bare session directly.)

    Actions and parameters (session_id is always required):

        init             - Create session and load libraries (explicit entry; for a new
                           scenario prefer analyze_scenario instead).
                           Params: libraries (list of library names),
                                   variables (dict or list to pre-set).

        import_library   - Add a library to an existing session.
                           Params: library_name, args (constructor args), alias.

        import_resource  - Import a Robot Framework resource file.
                           Params: resource_path, args.

        set_variables    - Set variables in the session.
                           Params: variables (dict {"NAME": "value"} or list ["NAME=value"]),
                                   scope ("test" | "suite" | "global", default "suite").

        import_variables - Load variables from a Python variable file.
                           Params: variable_file_path, args (passed to get_variables()).

        start_test       - Begin a named test (enables multi-test mode). Local mode only.
                           Params: test_name (required),
                                   test_documentation, test_tags,
                                   test_setup (dict {"keyword": "...", "arguments": [...]}),
                                   test_teardown (same format as test_setup).
                           Alias: start_task.

        end_test         - End the current test. Local mode only.
                           Params: test_status ("pass" or "fail", default "pass"),
                                   test_message (optional error description).
                           NOTE: test_status and test_message are session tracking metadata.
                           They do NOT affect the .robot file generated by build_test_suite.
                           Alias: end_task.

        add_data_row     - Add a data row to the current data-driven (template) test.
                           Requires an active test with template set via start_test.
                           Params: args (list of values matching the template keyword's [Arguments]).
                           Alias: data_row.
                           Example:
                             manage_session(action="start_test", test_name="Cart Test",
                                          template="Add And Verify Product")
                             manage_session(action="add_data_row", args=["Backpack", "1", "$29.99"])
                             manage_session(action="add_data_row", args=["Bike Light", "2", "$39.98"])
                             manage_session(action="end_test")
                           The data rows appear under [Template] in the generated .robot file.

        list_tests       - List all tests in the session with their status and step counts.
                           Params: (none).

        set_suite_setup    - Set a suite-level setup keyword (appears in *** Settings ***).
                             Params: keyword (required), args (keyword arguments).

        set_suite_teardown - Set a suite-level teardown keyword (appears in *** Settings ***).
                             Params: keyword (required), args (keyword arguments).

    Returns:
        Dict with success, session_id, and action-specific details.
        On failure: error and guidance fields are present.

    Examples:
        Initialize session with libraries:
            manage_session(action="init", session_id="s1",
                           libraries=["Browser", "BuiltIn", "Collections"])

        Set suite-level variables:
            manage_session(action="set_variables", session_id="s1",
                           variables={"BASE_URL": "https://example.com", "TIMEOUT": "30"})

        Import a library with constructor arguments:
            manage_session(action="import_library", session_id="s1",
                           library_name="Browser", args=["chromium"])

        Load a Python variable file:
            manage_session(action="import_variables", session_id="s1",
                           variable_file_path="config/variables.py",
                           args=["production", "secret_key"])

        Start a named test (multi-test mode):
            manage_session(action="start_test", session_id="s1",
                           test_name="Login Test", test_tags=["smoke"],
                           test_setup={"keyword": "Open Browser", "arguments": ["chromium"]})

        End the current test:
            manage_session(action="end_test", session_id="s1")

        Set suite setup (for generated .robot file):
            manage_session(action="set_suite_setup", session_id="s1",
                           keyword="New Browser", args=["chromium"])

        Set suite teardown:
            manage_session(action="set_suite_teardown", session_id="s1",
                           keyword="Close Browser")
    """

    action_norm = (action or "").strip().lower()

    # ADR-010 I5: Auto-generate session_id when empty/missing for init action
    if not session_id and action_norm in {"init", "initialize", "bootstrap"}:
        session_id = execution_engine.session_manager.create_session_id()

    # P1 改造 2：显式关闭 session（释放浏览器 context / Playwright 进程）
    if action_norm in {"close_session", "close"}:
        target = execution_engine.session_manager.get_session(session_id)
        if target is None:
            return {
                "success": False,
                "action": "close_session",
                "session_id": session_id,
                "error": f"Session '{session_id}' not found",
            }
        target.lifecycle_status = "closed"
        execution_engine.session_manager.remove_session(session_id)
        return {
            "success": True,
            "action": "close_session",
            "session_id": session_id,
            "closed": True,
            "note": "Session removed and browser context released.",
        }

    session = execution_engine.session_manager.get_or_create_session(session_id)

    if action_norm in {"init", "initialize", "bootstrap"}:
        # Start instruction learning tracking for this session
        try:
            hooks = _get_instruction_hooks()
            # Detect scenario type from libraries or use default
            scenario_type = "unknown"
            if libraries:
                if any(
                    "browser" in lib.lower() or "selenium" in lib.lower()
                    for lib in libraries
                ):
                    scenario_type = "web_automation"
                elif any(
                    "api" in lib.lower() or "request" in lib.lower()
                    for lib in libraries
                ):
                    scenario_type = "api_testing"
                elif any(
                    "mobile" in lib.lower() or "appium" in lib.lower()
                    for lib in libraries
                ):
                    scenario_type = "mobile_testing"

            hooks.on_session_start(
                session_id=session_id,
                instruction_mode=os.environ.get("ROBOTMCP_INSTRUCTION_MODE", "default"),
                scenario_type=scenario_type,
            )
        except Exception as e:
            logger.debug(f"Failed to start instruction learning: {e}")

        loaded: List[str] = []
        problems: List[Dict[str, Any]] = []

        if libraries:
            # Ensure BuiltIn is always included (standard RF behaviour)
            if "BuiltIn" not in libraries:
                libraries = ["BuiltIn"] + list(libraries)
            for library in libraries:
                try:
                    session.import_library(library)
                    session.loaded_libraries.add(library)
                    loaded.append(library)
                except Exception as lib_error:
                    problems.append({"library": library, "error": str(lib_error)})
        else:
            # Even when no libraries are specified, ensure BuiltIn is present
            try:
                session.import_library("BuiltIn")
                session.loaded_libraries.add("BuiltIn")
                loaded.append("BuiltIn")
            except Exception as lib_error:
                problems.append({"library": "BuiltIn", "error": str(lib_error)})

        set_vars: List[str] = []
        if variables:
            if isinstance(variables, dict):
                iterable = variables.items()
            else:
                iterable = []
                for item in variables:
                    if isinstance(item, str) and "=" in item:
                        name, value = item.split("=", 1)
                        iterable.append((name, value))
            # Ensure suite_level_variables set exists for variable tracking
            if (
                not hasattr(session, "suite_level_variables")
                or session.suite_level_variables is None
            ):
                session.suite_level_variables = set()
            for name, value in iterable:
                key = name if name.startswith("${") else f"${{{name}}}"
                session.set_variable(key, value)
                set_vars.append(name)
                # Track for *** Variables *** section in generated test suite
                session.suite_level_variables.add(name)

        # Register any library that is NOT one of rf-mcp's own for DISCOVERY. A
        # project's custom library declared at init reached the RF namespace - so
        # execute_step worked - but never the store find_keywords reads
        # (change: project-keyword-discovery).
        _registered = _register_session_project_libraries(
            session_id, session.loaded_libraries
        )

        result = {
            "success": True,
            "action": "init",
            "session_id": session_id,
            "libraries_loaded": list(session.loaded_libraries),
            "variables_set": set_vars,
            "import_issues": problems,
            **({"discovery": _registered} if _registered else {}),
            "note": "Context mode is managed via session namespace; use execute_step(use_context=True) when needed.",
            # ADR-010 I6: Prominent session_id guidance for small LLMs
            "next_step": f"Use session_id='{session_id}' in all subsequent tool calls.",
        }

        # Desktop upfront guidance (change: desktop-turn-economy-guidance):
        # deliver the PlatynUI keyword surface + locator crib at init so desktop
        # agents don't burn ~60% of their turns on find_keywords. Soft-fail —
        # a libdoc hiccup must never break session init.
        try:
            _is_desktop = getattr(session, "is_desktop_session", None)
            _desktop = bool(_is_desktop() if callable(_is_desktop) else False) or any(
                lib in {"PlatynUI.BareMetal", "PlatynUI"} for lib in (libraries or [])
            )
            if _desktop:
                from robotmcp.components.execution.desktop_guidance import (
                    get_desktop_guidance,
                )

                _bundle = get_desktop_guidance()
                if _bundle:
                    result["desktop_guidance"] = _bundle
        except Exception:
            pass

        # API upfront guidance (change: refactor-mcp-instructions §4): mirror the
        # desktop injection for RequestsLibrary. The non-obvious response-access rules
        # (${resp.json()}, On Session, native status asserts) are the #1 API turn-sink
        # (F-API1) and are otherwise unreachable first-try. Deliver a COMPACT bundle in
        # the init response the agent always reads. On by default when RequestsLibrary is
        # present; opt out with ROBOTMCP_API_GUIDANCE=off. Soft-fail like desktop.
        try:
            if os.environ.get("ROBOTMCP_API_GUIDANCE", "on").lower() not in (
                "off", "0", "false", "no",
            ) and any(
                lib == "RequestsLibrary" for lib in session.loaded_libraries
            ):
                from robotmcp.utils.requests_guidance import build_api_init_guidance

                _api_bundle = build_api_init_guidance()
                if _api_bundle:
                    result["api_guidance"] = _api_bundle
        except Exception:
            pass

        # ── ADR-006/ADR-016: Auto-activate tool profile (params > env vars) ──
        effective_profile = tool_profile or os.environ.get("ROBOTMCP_TOOL_PROFILE")
        effective_model_tier = model_tier or os.environ.get("ROBOTMCP_MODEL_TIER")
        # ADR-016: Auto-detect tier from model_name when no explicit tier given
        if not effective_model_tier and model_name:
            try:
                from robotmcp.domains.shared.kernel import ModelTier as _MT

                detected_tier = _MT.from_model_name(model_name)
                effective_model_tier = detected_tier.value
                result["model_tier_detected"] = detected_tier.value
                result["model_name"] = model_name
            except Exception:
                pass
        if effective_profile or effective_model_tier:
            if _tool_profile_manager is None:
                try:
                    await _initialize_adr_006_007_008()
                except Exception:
                    pass
            if _tool_profile_manager is not None:
                try:
                    if effective_profile:
                        activated = await _tool_profile_manager.activate_profile(
                            effective_profile
                        )
                        result["tool_profile"] = activated.name
                    elif effective_model_tier:
                        from robotmcp.domains.tool_profile.value_objects import (
                            ModelTier,
                        )

                        tier = ModelTier(effective_model_tier)
                        scenario_desc = scenario or " ".join(loaded) if loaded else ""
                        suggested = _tool_profile_manager.suggest_profile(
                            scenario_desc, tier
                        )
                        activated = await _tool_profile_manager.activate_profile(
                            suggested.name
                        )
                        result["tool_profile"] = activated.name
                        result["tool_profile_suggested_for"] = effective_model_tier
                except Exception as e:
                    logger.warning("Tool profile activation during init failed: %s", e)
        # ── End ADR-006 ──────────────────────────────────────────────

        _track_tool_result(
            session_id,
            "manage_session",
            {"action": action, "libraries": libraries},
            result,
        )
        return result

    if action_norm in {"import_resource", "resource"}:
        if not resource_path:
            return {"success": False, "error": "resource_path is required"}

        def _store_session_variables(
            session, variables_map: Dict[str, Any]
        ) -> List[str]:
            loaded: List[str] = []
            for name, value in variables_map.items():
                base = (
                    name[2:-1] if name.startswith("${") and name.endswith("}") else name
                )
                decorated = f"${{{base}}}"
                session.variables[base] = value
                session.variables[decorated] = value
                loaded.append(base)
            return loaded

        def _local_call() -> Dict[str, Any]:
            mgr = get_rf_native_context_manager()
            return mgr.import_resource_for_session(session_id, resource_path)

        def _external_call(client: ExternalRFClient) -> Dict[str, Any]:
            return client.import_resource(resource_path)

        result = _call_attach_tool_with_fallback(
            "import_resource", _external_call, _local_call
        )
        # Sync returned variables (local mode only) into the ExecutionSession store
        try:
            session = execution_engine.session_manager.get_or_create_session(session_id)
            variables_map = result.get("variables_map") or {}
            if variables_map:
                _store_session_variables(session, variables_map)
            for vf in result.get("variable_files", []) or []:
                key = (vf.get("path"), tuple(vf.get("args") or ()))
                existing = {
                    (item.get("path"), tuple(item.get("args") or ()))
                    for item in session.loaded_variable_files
                }
                if key not in existing:
                    session.loaded_variable_files.append(vf)
        except Exception:
            # Best-effort sync; do not fail the import if syncing fails
            pass

        # Register the resource's user keywords for DISCOVERY. Execution already
        # worked (RF's namespace resolves them); find_keywords/get_keyword_info read
        # a LibDoc-backed store that had no representation of resources at all
        # (change: project-keyword-discovery).
        if result.get("success"):
            result["discovery"] = _register_project_source(session_id, resource_path)

        result.update({"action": "import_resource", "session_id": session_id})
        return result

    if action_norm in {"import_library", "library"}:
        if not library_name:
            return {"success": False, "error": "library_name is required"}

        def _local_call() -> Dict[str, Any]:
            mgr = get_rf_native_context_manager()
            return mgr.import_library_for_session(
                session_id, library_name, tuple(args or ()), alias
            )

        def _external_call(client: ExternalRFClient) -> Dict[str, Any]:
            return client.import_library(library_name, list(args or ()), alias)

        result = _call_attach_tool_with_fallback(
            "import_custom_library", _external_call, _local_call
        )

        # ── Sync the session model with the RF namespace import ─────
        # import_library_for_session() imports into the RF Namespace but
        # does NOT update session.imported_libraries / loaded_libraries /
        # search_order.  Without this sync, set_library_search_order()
        # will reject the library because the session model doesn't know
        # about it (P16 fix).
        if result.get("success"):
            # Register for DISCOVERY too (change: project-keyword-discovery). A
            # library imported into a session reached the RF namespace - so
            # execute_step worked - but never the store find_keywords reads.
            result["discovery"] = _register_project_source(
                session_id, library_name, args=args, alias=alias
            )
            try:
                session.import_library(library_name, force=True)
                session.loaded_libraries.add(library_name)
            except Exception as sync_err:
                logger.debug(
                    "Session model sync after import_library failed: %s", sync_err
                )
                # Best-effort: the RF namespace import succeeded, so at
                # minimum ensure imported_libraries tracks the library.
                if library_name not in session.imported_libraries:
                    session.imported_libraries.append(library_name)
                if library_name not in session.search_order:
                    session.search_order.append(library_name)

        result.update({"action": "import_library", "session_id": session_id})
        return result

    if action_norm in {"set_variables", "variables"}:
        data: Dict[str, Any] = {}
        if isinstance(variables, dict):
            data = variables
        elif isinstance(variables, list):
            for item in variables:
                if isinstance(item, str) and "=" in item:
                    name, value = item.split("=", 1)
                    data[name.strip()] = value

        if not data:
            return {
                "success": False,
                "action": "set_variables",
                "session_id": session_id,
                "error": "No variables to set. Provide a non-empty 'variables' parameter.",
                "hint": (
                    "Pass variables as a dict: variables={\"MY_VAR\": \"value\"} "
                    "or as a list: variables=[\"MY_VAR=value\", \"OTHER=123\"]"
                ),
            }

        set_kw = {
            "test": "Set Test Variable",
            "suite": "Set Suite Variable",
            "global": "Set Global Variable",
        }.get(scope.lower(), "Set Suite Variable")

        results: Dict[str, bool] = {}
        errors: Dict[str, str] = {}
        client = _get_external_client_if_configured()
        if client is not None:
            for name, value in data.items():
                try:
                    resp = client.set_variable(name, value, scope=scope)
                    results[name] = bool(resp.get("success"))
                    if not results[name]:
                        errors[name] = resp.get("error", "Bridge returned success=false")
                except Exception as e:
                    results[name] = False
                    errors[name] = str(e)
            result_payload: Dict[str, Any] = {
                "success": all(results.values()),
                "action": "set_variables",
                "session_id": session_id,
                "set": [k for k, v in results.items() if v],
                "scope": scope,
                "external": True,
            }
            if errors:
                result_payload["errors"] = errors
                result_payload["hint"] = (
                    "Some variables failed to set via bridge. "
                    "Check that the RF process is running and the bridge is reachable. "
                    "Use manage_attach(action='status') to verify bridge health."
                )
            return result_payload

        for name, value in data.items():
            # Pass value directly with ${name} syntax - RF 7 handles Python
            # list/dict types automatically and stores them appropriately
            res = await execution_engine.execute_step(
                set_kw,
                [f"${{{name}}}", value],
                session_id,
                detail_level="minimal",
                use_context=True,
            )
            results[name] = bool(res.get("success"))
            if not results[name]:
                errors[name] = res.get("error", "Keyword execution returned success=false")

        # Track ALL manage_session variables for *** Variables *** section generation
        # Variables set via manage_session (any scope) should be included in the Variables
        # section to ensure generated test suites are complete and executable.
        # Without this, tests would reference variables that aren't defined.
        try:
            session = execution_engine.session_manager.get_or_create_session(session_id)
            if (
                not hasattr(session, "suite_level_variables")
                or session.suite_level_variables is None
            ):
                session.suite_level_variables = set()
            for name in data.keys():
                session.suite_level_variables.add(name)
            logger.debug(
                f"Tracked {len(data)} variables from manage_session for Variables section"
            )
        except Exception as track_error:
            logger.warning(f"Failed to track manage_session variables: {track_error}")

        result_payload = {
            "success": all(results.values()),
            "action": "set_variables",
            "session_id": session_id,
            "set": [k for k, v in results.items() if v],
            "scope": scope,
        }
        if errors:
            result_payload["errors"] = errors
            result_payload["hint"] = (
                "Some variables failed to set. Ensure the session was initialized "
                "with manage_session(action='init') first and that BuiltIn library is loaded."
            )
        return result_payload

    if action_norm in {"import_variables", "load_variables"}:
        if not variable_file_path:
            return {"success": False, "error": "variable_file_path is required"}

        def _local_call() -> Dict[str, Any]:
            mgr = get_rf_native_context_manager()
            return mgr.import_variables_for_session(
                session_id, variable_file_path, args or []
            )

        def _external_call(client: ExternalRFClient) -> Dict[str, Any]:
            return client.import_variables(variable_file_path, args or [])

        result = _call_attach_tool_with_fallback(
            "import_variables", _external_call, _local_call
        )

        # Sync returned variables (local mode only) into the ExecutionSession store
        try:
            session = execution_engine.session_manager.get_or_create_session(session_id)
            variables_map = result.get("variables_map") or {}
            if variables_map:
                for name, value in variables_map.items():
                    # Store variables in session with proper normalization
                    base = (
                        name[2:-1]
                        if name.startswith("${") and name.endswith("}")
                        else name
                    )
                    decorated = f"${{{base}}}"
                    session.variables[base] = value
                    session.variables[decorated] = value

            # Track variable file metadata in session
            variable_file_record = {
                "path": variable_file_path,
                "args": args or [],
                "variables_loaded": list(variables_map.keys()) if variables_map else [],
            }

            if not hasattr(session, "loaded_variable_files"):
                session.loaded_variable_files = []

            # Check if already imported (by path and args combination)
            existing_key = (variable_file_path, tuple(args or []))
            existing_keys = {
                (item.get("path"), tuple(item.get("args", [])))
                for item in session.loaded_variable_files
            }

            if existing_key not in existing_keys:
                session.loaded_variable_files.append(variable_file_record)

        except Exception as sync_error:
            # Best-effort sync; do not fail the import if syncing fails
            logger.warning(
                f"Failed to sync variable file metadata to session: {sync_error}"
            )
            pass

        result.update({"action": "import_variables", "session_id": session_id})
        return result

    # ── ADR-005: Multi-test session management ─────────────────────────

    if action_norm in {"start_test", "start_task"}:
        if not test_name:
            return {"success": False, "error": "test_name is required for start_test action"}

        # Guard: multi-test not supported with active attach bridge
        if _get_external_client_if_configured() is not None:
            return {
                "success": False,
                "error": (
                    "Multi-test mode is not supported with attach bridge. "
                    "Use separate sessions or generate .robot files."
                ),
            }

        session = execution_engine.session_manager.get_or_create_session(session_id)

        # Atomic start_test (change: desktop-test-scoping-and-close-lifecycle,
        # D1/D2): establish the RF context FIRST (auto-create when start_test
        # is called before any execute_step — run-3 root cause of "No context
        # for session"), then the context-layer test, and activate the
        # registry LAST. A failure at any layer fails the WHOLE call — the
        # old soft-success left the registry multi-test-active while the
        # context had no test, silently routing 43/46 steps out of the suite.
        mgr = get_rf_native_context_manager()
        try:
            ctx_info = mgr.get_session_context_info(session_id)
            if not ctx_info.get("context_exists"):
                if getattr(session, "search_order", None):
                    _libs = list(session.search_order)
                elif getattr(session, "loaded_libraries", None):
                    _libs = list(session.loaded_libraries)
                else:
                    _libs = []
                ctx_create = mgr.create_context_for_session(session_id, _libs)
                if not ctx_create.get("success"):
                    return {
                        "success": False,
                        "error": (
                            "start_test could not create the RF context: "
                            f"{ctx_create.get('error')}"
                        ),
                        "session_id": session_id,
                        "action": action_norm,
                    }
        except Exception as e:
            return {
                "success": False,
                "error": f"start_test could not establish the RF context: {e}",
                "session_id": session_id,
                "action": action_norm,
            }

        # Start test in RF context (pushes test scope)
        try:
            ctx_result = mgr.start_test_in_context(
                session_id, test_name, test_documentation, test_tags or []
            )
        except Exception as e:
            ctx_result = {"success": False, "error": str(e)}
        if not ctx_result.get("success"):
            return {
                "success": False,
                "error": (
                    "start_test failed in the RF context layer: "
                    f"{ctx_result.get('error')}"
                ),
                "session_id": session_id,
                "action": action_norm,
                "context_result": ctx_result,
            }

        # Registry activation last — the irreversible layer only flips after
        # both context layers succeeded.
        session.test_registry.start_test(
            name=test_name,
            documentation=test_documentation,
            tags=test_tags or [],
            setup=test_setup,
            teardown=test_teardown,
            template=template,  # ADR-019
        )

        result = {
            "success": True,
            "session_id": session_id,
            "action": action_norm,
            "test_name": test_name,
            "context_result": ctx_result,
        }
        if template:
            result["template"] = template
            result["hint"] = (
                "Data-driven test created. Add data rows with: "
                "manage_session(action='add_data_row', args=['val1', 'val2', ...]). "
                "For named rows (separate test cases in reports): "
                "manage_session(action='add_data_row', test_name='Row Name', args=[...]). "
                "Then call manage_session(action='end_test') and build_test_suite."
            )
        # Fix 4: Inform when start_test is called after steps were already
        # executed. Those pre-start steps are EXCLUDED from the generated suite
        # body by default (change: desktop-mcp-workflow-correctness); pass
        # build_test_suite(include_pre_start=True) to adopt them.
        if session.steps:
            result["warning"] = (
                f"Session has {len(session.steps)} step(s) executed before start_test. "
                "By default these exploratory pre-start steps are EXCLUDED from the "
                "generated suite body (build_test_suite reports excluded_pre_start_count). "
                "Pass build_test_suite(include_pre_start=True) to adopt them. "
                "For best results, call start_test BEFORE executing steps."
            )
        return result

    if action_norm in {"end_test", "end_task"}:
        # Guard: multi-test not supported with active attach bridge
        if _get_external_client_if_configured() is not None:
            return {
                "success": False,
                "error": "Multi-test mode is not supported with attach bridge.",
            }

        session = execution_engine.session_manager.get_or_create_session(session_id)
        _status = test_status.lower() if test_status else "pass"

        # Registry-first end_test (change: desktop-test-scoping-and-close-
        # lifecycle, D2): the registry is the source of truth for suite
        # generation. No active registry test -> the call fails; an active
        # registry test always ends successfully, and a context-layer miss
        # is downgraded to a warning (the RF layer self-heals on next start).
        test_info = session.test_registry.end_test(
            status=_status,
            message=test_message,
        )
        if test_info is None:
            return {
                "success": False,
                "error": "No active test to end (call start_test first)",
                "session_id": session_id,
                "action": action_norm,
            }

        # End test in RF context (pops test scope, sets PREV_TEST_*)
        ctx_result = {}
        try:
            mgr = get_rf_native_context_manager()
            rf_status = "PASS" if _status == "pass" else "FAIL"
            ctx_result = mgr.end_test_in_context(session_id, rf_status, test_message)
        except Exception as e:
            logger.warning(f"RF context end_test failed (non-fatal): {e}")
            ctx_result = {"success": False, "error": str(e)}

        result = {
            "success": True,
            "session_id": session_id,
            "action": action_norm,
            "test_name": test_info.name,
            "test_status": _status,
            "context_result": ctx_result,
        }
        if not ctx_result.get("success"):
            result["warning"] = (
                f"Registry test '{test_info.name}' ended normally, but the RF "
                "context layer reported: "
                f"{ctx_result.get('error', 'no active context test')}. The "
                "context layer self-heals on the next start_test."
            )
        return result

    # ── Data-driven: add_data_row ───────────────────────────────────
    if action_norm in {"add_data_row", "data_row"}:
        session = execution_engine.session_manager.get_or_create_session(session_id)
        current_test = session.test_registry.get_current_test()

        if not current_test:
            return {
                "success": False,
                "error": "No active test. Call manage_session(action='start_test', template='...') first.",
            }
        if not current_test.template:
            return {
                "success": False,
                "error": (
                    "Current test has no template. "
                    "Use manage_session(action='start_test', template='Keyword Name') to enable data-driven mode."
                ),
            }
        if not args:
            return {
                "success": False,
                "error": "args is required for add_data_row. Provide a list of values for the template keyword's [Arguments].",
            }

        # Store the data row — named or unnamed
        row_values = [str(a) for a in args]
        row_test_name = test_name  # Optional: names this row as a separate test case

        if row_test_name:
            current_test.named_data_rows.append((row_test_name, row_values))
        else:
            current_test.data_rows.append(row_values)

        total = len(current_test.data_rows) + len(current_test.named_data_rows)
        result_dict = {
            "success": True,
            "session_id": session_id,
            "action": action_norm,
            "template": current_test.template,
            "row_added": row_values,
            "total_rows": total,
        }
        if row_test_name:
            result_dict["row_test_name"] = row_test_name
            result_dict["mode"] = "suite_template"
            result_dict["hint"] = (
                "Named row added. Use build_test_suite(data_driven_mode='suite_template') "
                "to generate Test Template in Settings with each row as a named test case."
            )
        return result_dict

    if action_norm in {"list_tests"}:
        session = execution_engine.session_manager.get_or_create_session(session_id)
        tests = []
        for name, ti in session.test_registry.tests.items():
            tests.append({
                "name": name,
                "status": ti.status,
                "step_count": len(ti.steps),
                "tags": ti.tags,
                "started_at": ti.started_at.isoformat() if ti.started_at else None,
                "ended_at": ti.ended_at.isoformat() if ti.ended_at else None,
                "error_message": ti.error_message,
            })
        return {
            "success": True,
            "session_id": session_id,
            "action": "list_tests",
            "multi_test_mode": session.test_registry.is_multi_test_mode(),
            "current_test": session.test_registry.current_test_name,
            "tests": tests,
            "total_tests": len(tests),
        }

    if action_norm in {"set_suite_setup"}:
        if not keyword:
            return {"success": False, "error": "keyword is required for set_suite_setup"}
        kw_args = list(args or [])
        session = execution_engine.session_manager.get_or_create_session(session_id)
        session.suite_setup = {"keyword": keyword, "arguments": kw_args}
        return {
            "success": True,
            "session_id": session_id,
            "action": "set_suite_setup",
            "keyword": keyword,
            "arguments": kw_args,
        }

    if action_norm in {"set_suite_teardown"}:
        if not keyword:
            return {"success": False, "error": "keyword is required for set_suite_teardown"}
        kw_args = list(args or [])
        session = execution_engine.session_manager.get_or_create_session(session_id)
        session.suite_teardown = {"keyword": keyword, "arguments": kw_args}
        return {
            "success": True,
            "session_id": session_id,
            "action": "set_suite_teardown",
            "keyword": keyword,
            "arguments": kw_args,
        }

    # ── End ADR-005 ──────────────────────────────────────────────────

    # ── ADR-006: set_tool_profile action ─────────────────────────────
    if action_norm in {"set_tool_profile", "tool_profile"}:
        profile_name = profile or ((libraries or [None])[0] if libraries else None)
        if not profile_name:
            return {
                "success": False,
                "error": (
                    "Missing profile name. Pass the profile name as the "
                    "first item in the 'libraries' parameter, e.g. "
                    "libraries=['browser_exec']. Available: browser_exec, "
                    "api_exec, discovery, minimal_exec, full"
                ),
            }
        if _tool_profile_manager is None:
            try:
                await _initialize_adr_006_007_008()
            except Exception:
                pass
        if _tool_profile_manager is None:
            return {
                "success": False,
                "error": "Tool profile system not initialized",
            }
        try:
            profile = await _tool_profile_manager.activate_profile(profile_name)
            return {
                "success": True,
                "action": "set_tool_profile",
                "session_id": session_id,
                "active_profile": profile.name,
                "tools_visible": sorted(profile.tool_names),
                "tool_count": profile.tool_count,
            }
        except KeyError as e:
            available = _tool_profile_manager.list_profiles()
            return {
                "success": False,
                "error": str(e),
                "available_profiles": available,
            }
    # ── End ADR-006 ──────────────────────────────────────────────────

    valid_actions = (
        "init/initialize/bootstrap, import_library/library, import_resource/resource, "
        "set_variables/variables, import_variables/load_variables, "
        "start_test/start_task, end_test/end_task, add_data_row/data_row, list_tests, "
        "set_suite_setup, set_suite_teardown, set_tool_profile/tool_profile"
    )
    return {
        "success": False,
        "error": f"Unsupported action '{action}'. Valid actions: {valid_actions}",
    }


def _chunk_string(value: str, size: int) -> List[str]:
    if size <= 0:
        size = 65536
    return [value[i : i + size] for i in range(0, len(value), size)]


@mcp.tool
async def execute_flow(
    structure: FlowStructure,
    session_id: str,
    condition: str | None = None,
    then_steps: List[Dict[str, Any]] | None = None,
    else_steps: List[Dict[str, Any]] | None = None,
    items: List[Any] | None = None,
    item_var: str = "item",
    stop_on_failure: bool = True,
    max_iterations: int = 1000,
    try_steps: List[Dict[str, Any]] | None = None,
    except_patterns: List[str] | None = None,
    except_steps: List[Dict[str, Any]] | None = None,
    finally_steps: List[Dict[str, Any]] | None = None,
    rethrow: bool = False,
) -> Dict[str, Any]:
    """Execute structured flow (if/for/try) within a session.

    Args:
        structure: Flow type ("if", "for", "try").
        session_id: Session id to run the flow in.
        condition: Expression for if/conditional flows.
        then_steps: Steps for the main branch (if/loop body/try block).
        else_steps: Steps for the else branch (if).
        items: Items to iterate when structure="for".
        item_var: Variable name to bind each item in for-each loops.
        stop_on_failure: Whether to stop loop/branch execution on first failure.
        max_iterations: Maximum iterations for for-each loops.
        try_steps: Steps for the try block (when structure="try").
        except_patterns: Error patterns to match for except handling.
        except_steps: Steps for the except block.
        finally_steps: Steps for the finally block.
        rethrow: Whether to rethrow after except/finally.

    Returns:
        Dict[str, Any]: Flow execution result:
            - success: bool
            - structure: flow type executed
            - session_id: echoed id
            - per-branch results/errors
    """

    structure_norm = (structure or "").strip().lower()

    if structure_norm in {"if", "conditional"}:
        return await _execute_if_impl(
            session_id=session_id,
            condition=condition or "",
            then_steps=then_steps or [],
            else_steps=else_steps or [],
            stop_on_failure=stop_on_failure,
        )

    if structure_norm in {"for", "foreach", "for_each"}:
        return await _execute_for_each_impl(
            session_id=session_id,
            items=items or [],
            steps=then_steps or [],
            item_var=item_var,
            stop_on_failure=stop_on_failure,
            max_iterations=max_iterations,
        )

    if structure_norm in {"try", "try_except", "trycatch"}:
        return await _execute_try_except_impl(
            session_id=session_id,
            try_steps=try_steps or [],
            except_patterns=except_patterns or [],
            except_steps=except_steps or [],
            finally_steps=finally_steps or [],
            rethrow=rethrow,
        )

    return {"success": False, "error": f"Unsupported flow structure '{structure}'"}


@mcp.tool
async def get_session_state(
    session_id: str,
    sections: OptionalCoercedStringList = None,
    state_type: str = "all",
    elements_of_interest: OptionalCoercedStringList = None,
    page_source_filtered: bool = False,
    page_source_filtering_level: FilteringLevel = "standard",
    include_reduced_dom: bool = True,
    include_dom_stream: bool = False,
    dom_chunk_size: int = 65536,
    mode: Literal["full", "delta", "auto", "none"] = "auto",
    since_version: int | None = None,
) -> Dict[str, Any]:
    """Retrieve aggregated session state for debugging and visibility.

    Primary uses:
        - UI inspection: DOM tree/page source/ARIA snapshots for Browser/Selenium/Appium sessions.
        - Variable inspection: current RF variables, assigned values, and context search order.
        - Validation/health checks: validation summaries, library lists, and attach/bridge status.
        - Application insight: application_state (dom/api/database) when provided by plugins.

    Args:
        session_id: Active session identifier to inspect.
        sections: Specific data blocks to include (e.g., summary, page_source, variables, application_state, ui_tree).
            ui_tree (desktop/PlatynUI sessions only): accessibility-tree snapshot.
            Lists applications; pass application names via elements_of_interest
            to expand their subtrees (bounded depth, ADR-025).
        state_type: Type of application state to fetch when requesting application_state (dom|api|database|all).
        elements_of_interest: Targeted element identifiers passed to application state collectors.
        page_source_filtered: When True, returns sanitized/filtered DOM text instead of the full source.
        page_source_filtering_level: Filtering aggressiveness for DOM output (standard|aggressive).
        include_reduced_dom: Whether to include lightweight semantic DOM (ARIA snapshots) for quick inspection.
        include_dom_stream: Chunk large page_source payloads into page_source_stream entries for easier transport.
        dom_chunk_size: Maximum size of each DOM chunk when streaming is enabled (minimum 1024 bytes).

    Returns:
        Dict[str, Any]: Payload with:
            - success: bool indicating retrieval success.
            - session_id: resolved session id.
            - sections: list of sections included.
            - data: per-section content (e.g., variables, page_source/ARIA snapshots, validation, libraries,
              application_state).
            - error: present only on failure, with guidance if available.
    """

    sections = sections or ["summary", "page_source", "variables"]
    requested = {s.lower() for s in sections}

    # Desktop (PlatynUI) sessions inspect the accessibility tree, never the
    # mobile/Appium source path (maintainer-report #4). Auto-include ui_tree and
    # serve page_source as a desktop stub. change: desktop-mcp-workflow-correctness.
    _state_session = execution_engine.session_manager.get_session(session_id)
    is_desktop_session = bool(
        _state_session is not None and _state_session.is_desktop_session()
    )
    if is_desktop_session:
        requested.add("ui_tree")

    payload: Dict[str, Any] = {
        "success": True,
        "session_id": session_id,
        "sections": {},
        "requested": sections,
    }

    if "summary" in requested:
        summary = await _get_session_info_payload(session_id)
        payload["sections"]["summary"] = summary

    if "application_state" in requested or "state" in requested:
        app_state = await _get_application_state_payload(
            state_type=state_type,
            elements_of_interest=elements_of_interest or [],
            session_id=session_id,
        )
        payload["sections"]["application_state"] = app_state

    if "page_source" in requested:
        if is_desktop_session:
            # Desktop sessions have no HTML/DOM page source. Return a stub that
            # points to ui_tree instead of attempting the mobile-source lookup
            # ("Failed to get mobile source: No application is open").
            payload["sections"]["page_source"] = {
                "success": True,
                "source": "desktop",
                "library": "PlatynUI.BareMetal",
                "page_source": None,
                "message": (
                    "Desktop (PlatynUI) sessions expose no HTML page source — "
                    "there is no desktop application DOM. Use the 'ui_tree' "
                    "section for the accessibility-tree snapshot of the running "
                    "application."
                ),
                "hint": "Inspect the 'ui_tree' section for desktop application state.",
            }
        else:
            page_source = await _get_page_source_payload(
                session_id=session_id,
                full_source=not page_source_filtered,
                filtered=page_source_filtered,
                filtering_level=page_source_filtering_level,
                include_reduced_dom=include_reduced_dom,
            )
            if (
                include_dom_stream
                and isinstance(page_source, dict)
                and isinstance(page_source.get("page_source"), str)
            ):
                page_source["page_source_stream"] = _chunk_string(
                    page_source["page_source"], max(int(dom_chunk_size), 1024)
                )
            payload["sections"]["page_source"] = page_source

    if "variables" in requested:
        variables = await _get_context_variables_payload(session_id)
        payload["sections"]["variables"] = variables

    if "validation" in requested:
        validation = await _get_session_validation_status_payload(session_id)
        payload["sections"]["validation"] = validation

    if "libraries" in requested:
        libraries = await _get_loaded_libraries_payload()
        # This session's own project sources (custom libraries, resource files):
        # name to call them by, how they were imported, and their keywords. The
        # loaded-libraries payload lists rf-mcp's catalogue only, so a session's
        # resources did not appear anywhere in its state.
        try:
            from robotmcp.utils.rf_libdoc_integration import get_rf_doc_storage

            storage = get_rf_doc_storage()
            project = []
            for ns_name, info in storage.project_libraries(session_id).items():
                spec = storage.project_import_spec(session_id, ns_name) or {}
                project.append({
                    "name": ns_name,
                    "type": info.type,
                    "source": info.source,
                    "import": spec.get("spec"),
                    "args": spec.get("args") or [],
                    "alias": spec.get("alias"),
                    "keywords": sorted(info.keywords.keys()),
                })
            if isinstance(libraries, dict) and project:
                libraries["project_sources"] = project
        except Exception as exc:  # pragma: no cover - defensive
            logger.debug("project_sources section failed: %s", exc)
        payload["sections"]["libraries"] = libraries

    if "rf_context" in requested or "context" in requested:
        rf_context = await _diagnose_rf_context_payload(session_id)
        payload["sections"]["rf_context"] = rf_context

    if "ui_tree" in requested:
        # Desktop (PlatynUI) accessibility tree (ADR-025). Application
        # names passed via elements_of_interest get their subtrees
        # expanded (bounded depth/children); otherwise lists apps only.
        from robotmcp.components.execution.ui_tree_service import get_ui_tree

        _session_obj = execution_engine.session_manager.get_session(session_id)
        if _session_obj is None:
            payload["sections"]["ui_tree"] = {
                "success": False,
                "error": f"Session '{session_id}' not found",
            }
        else:
            payload["sections"]["ui_tree"] = await get_ui_tree(
                _session_obj,
                app_filters=elements_of_interest or None,
            )
            # desktop_environment: display identity + isolation classification
            # + upstream desktop_info(), so an agent can prove "app visible on
            # display :N, input confined to it" before interacting
            # (change: platynui-visible-safe-targeting, task 3.3).
            try:
                _is_desktop = getattr(_session_obj, "is_desktop_session", None)
                if callable(_is_desktop) and _is_desktop() is True:
                    from robotmcp.components.execution.ui_tree_service import (
                        get_desktop_environment,
                    )

                    payload["sections"]["desktop_environment"] = (
                        get_desktop_environment(_session_obj)
                    )
            except Exception as _denv_exc:  # pragma: no cover - defensive
                logger.debug("desktop_environment section skipped: %s", _denv_exc)

    if "actionable_controls" in requested:
        # Flat, AUT-scoped, budget-bounded interactive-control view — the desktop
        # analog of the web actionable_elements view. Replaces per-element Query
        # probing (change: desktop-actionable-controls). elements_of_interest
        # selects the anchor application.
        from robotmcp.components.execution.ui_tree_service import (
            get_actionable_controls,
        )

        _ac_session = execution_engine.session_manager.get_session(session_id)
        if _ac_session is None:
            payload["sections"]["actionable_controls"] = {
                "success": False,
                "error": f"Session '{session_id}' not found",
            }
        else:
            payload["sections"]["actionable_controls"] = await get_actionable_controls(
                _ac_session,
                app_filters=elements_of_interest or None,
            )

    # ADR-018: Delta-based state retrieval
    # mode="auto" (default): auto-detect delta when prior version exists
    _use_delta = False
    if mode == "delta" and since_version is not None:
        _use_delta = True
    elif mode in ("full", "auto") and since_version is not None:
        _use_delta = True  # auto-detect: client sent since_version
    elif mode == "auto" and since_version is None:
        # Check if a previous version exists for this session
        try:
            from robotmcp.container import get_container as _gc
            _dsvc = _gc().delta_state_service
            if _dsvc.has_version(session_id):
                # Return full this time but record for future delta
                _use_delta = False
        except Exception:
            pass

    if _use_delta and since_version is not None:
        try:
            from robotmcp.container import get_container

            delta_svc = get_container().delta_state_service
            delta, new_version = delta_svc.compute_delta(
                session_id, since_version, payload.get("sections", {}), list(requested),
            )
            # Add sections_changed summary for quick LLM overview
            changed_sections = [s.section_name for s in delta.sections if s.change_type.value != "unchanged"]
            payload = {
                "success": True,
                "session_id": session_id,
                "mode": "delta",
                "state_version": new_version.version_number,
                "sections_changed": changed_sections,
                "delta": delta.to_dict(),
            }
        except Exception as e:
            logger.debug(f"Delta computation failed, returning full state: {e}")
            payload["mode"] = "full"
    elif mode != "none":
        # Record full state version for future deltas
        try:
            from robotmcp.container import get_container

            delta_svc = get_container().delta_state_service
            version = delta_svc.record_full_state(
                session_id, payload.get("sections", {}), list(requested),
            )
            payload["state_version"] = version.version_number
        except Exception:
            pass  # Non-critical; don't fail the response

    # ADR-014.2: Augment get_session_state with memory hints
    payload = await _augment_with_memory(
        session_id, "get_session_state", {"sections": sections}, payload,
    )

    # ADR-015: Externalize large fields to artifacts
    payload = _externalize_response("get_session_state", session_id, payload)

    # Track for instruction learning
    _track_tool_result(session_id, "get_session_state", {"sections": sections}, payload)

    return payload


# ── P0 改造 4：失败自愈（规则版，无 LLM 依赖）──────────────────────────
_LOCATOR_FAILURE_MARKERS = (
    "locator", "no element", "unable to locate", "could not find",
    "strict mode", "not found", "timed out", "timeout", "no such element",
    "element not", "waiting for selector",
)


def _is_locator_failure(result: Dict[str, Any]) -> bool:
    """判断失败是否「元素定位类」错误（这类错误抓 DOM + 换定位器有救）。"""
    err = (result.get("error") or "").lower()
    return any(m in err for m in _LOCATOR_FAILURE_MARKERS)


def _extract_locator(arguments: List[str]) -> Optional[str]:
    """从参数里提取第一个显式定位器（text=/css=/xpath=/id=/class= 等前缀）。"""
    for a in arguments or []:
        a = str(a)
        for prefix in ("text=", "css=", "xpath=", "id=", "class=", "name=", "data-testid="):
            if a.startswith(prefix):
                return a
    return None


def _candidate_locators(locator: str) -> List[str]:
    """规则生成候选定位器。text= 是最高频漂移，给 xpath contains 变体；css/xpath 原样重试。"""
    if not locator:
        return []
    cands = []
    if locator.startswith("text="):
        text = locator[len("text="):]
        cands.append(f'xpath=//*[contains(normalize-space(text()), "{text}")]')
        collapsed = " ".join(text.split())
        if collapsed and collapsed != text:
            cands.append(f"text={collapsed}")
    elif locator.startswith(("css=", "xpath=", "id=", "class=", "name=")):
        cands.append(locator)  # timing 类问题：原样重试一次
    return cands


def _dom_summary(dom_text: str, locator: str, limit: int = 1200) -> str:
    """从 DOM 文本里摘取与定位器相关的片段，压缩成短摘要（省 token）。"""
    if not dom_text:
        return ""
    keyword = ""
    if locator:
        keyword = locator.split("=", 1)[-1].strip('"')[:30]
    lines = []
    for line in dom_text.splitlines():
        if keyword and keyword in line:
            lines.append(line.strip())
            if len(lines) >= 10:
                break
    if lines:
        return "\n".join(lines)[:limit]
    return dom_text[:limit]


_LOCATOR_PREFIXES = (
    "text=", "css=", "xpath=", "id=", "class=", "name=", "data-testid=", "role=",
)


def _clean_locator(raw: str) -> Optional[str]:
    """从 LLM 返回里清洗出一个 Playwright 定位器（去 markdown / 引号 / 解释）。"""
    if not raw:
        return None
    text = raw.strip()
    # 去 ``` 代码块围栏
    if text.startswith("```"):
        text = "\n".join(
            ln for ln in text.splitlines() if not ln.strip().startswith("```")
        ).strip()
    for line in text.splitlines():
        line = line.strip().strip("`").strip().strip('"').strip("'").strip()
        if not line:
            continue
        if line.startswith(_LOCATOR_PREFIXES) or line.startswith(("//", "#", ".", "[")):
            return line
    return None


async def _llm_suggest_locator(
    ctx: Context,
    keyword: str,
    locator: str,
    dom_text: str,
    error: str,
) -> Optional[str]:
    """P3：用宿主 sampling 让 LLM 根据 DOM 生成一个能命中元素的定位器。"""
    dom_excerpt = dom_text[:4000]
    prompt = f"""A Robot Framework Browser keyword failed because its locator did not match.

Keyword: {keyword}
Failed locator: {locator}
Error: {error}

Current page DOM (filtered excerpt):
{dom_excerpt}

Give ONE Playwright-style locator that matches the intended element. Use one of:
  text=<visible text>
  css=<css selector>
  xpath=<xpath>
  id=<element id>

Respond with ONLY the locator, no explanation, no markdown, no quotes."""

    result = await ctx.sample(
        messages=prompt,
        system_prompt="You are a Playwright locator expert. Respond with only one locator string.",
        temperature=0.1,
        max_tokens=128,
    )
    raw = result.text if hasattr(result, "text") else str(result)
    return _clean_locator(raw)


async def _self_heal_step(
    session_id: str,
    keyword: str,
    arguments: List[str],
    failed_result: Dict[str, Any],
    ctx: Context = None,
) -> Dict[str, Any]:
    """定位类失败自愈：抓 filtered DOM → 规则候选重试 → 规则全败后回退 LLM sampling。

    成功返回新的成功 result（self_healed=True，self_healed_by=rule|llm）；
    失败返回原 result，附加 self_heal_attempted + self_heal_dom 供 AI 继续修。
    """
    locator = _extract_locator(arguments)
    if not locator:
        return failed_result

    # 1) 抓 DOM（filtered 省 token）
    dom_text = ""
    try:
        dom = await execution_engine.get_page_source(
            session_id,
            full_source=False,
            filtered=True,
            filtering_level="standard",
            include_reduced_dom=True,
        )
        if isinstance(dom, dict):
            dom_text = (
                dom.get("page_source")
                or dom.get("page_source_preview")
                or dom.get("source")
                or ""
            )
    except Exception as e:
        logger.debug("Self-heal DOM fetch failed: %s", e)

    # 2) 规则候选重试
    candidates = _candidate_locators(locator)
    attempts = []
    for cand in candidates:
        new_args = [cand if str(a) == locator else a for a in (arguments or [])]
        try:
            r = await execution_engine.execute_step(
                keyword, new_args, session_id,
                detail_level="minimal", use_context=True,
            )
        except Exception as e:
            r = {"success": False, "error": str(e)}
        attempts.append({"locator": cand, "success": bool(r.get("success"))})
        if r.get("success"):
            r["self_healed"] = True
            r["self_healed_by"] = "rule"
            r["healed_locator"] = cand
            r["self_heal_attempts"] = attempts
            logger.info("Self-heal (rule) 成功: %s -> %s", locator, cand)
            return r

    # 3) P3：规则全败 → 回退宿主 sampling（LLM 生成定位器）
    if ctx is not None and hasattr(ctx, "sample") and dom_text:
        llm_locator = None
        try:
            llm_locator = await _llm_suggest_locator(
                ctx, keyword, locator, dom_text, failed_result.get("error", "") or "",
            )
        except Exception as e:
            logger.debug("LLM locator suggestion failed: %s", e)
            failed_result["self_heal_llm_error"] = str(e)[:200]

        if llm_locator:
            new_args = [llm_locator if str(a) == locator else a for a in (arguments or [])]
            try:
                r = await execution_engine.execute_step(
                    keyword, new_args, session_id,
                    detail_level="minimal", use_context=True,
                )
            except Exception as e:
                r = {"success": False, "error": str(e)}
            attempts.append({
                "locator": llm_locator, "source": "llm",
                "success": bool(r.get("success")),
            })
            if r.get("success"):
                r["self_healed"] = True
                r["self_healed_by"] = "llm"
                r["healed_locator"] = llm_locator
                r["self_heal_attempts"] = attempts
                logger.info("Self-heal (LLM) 成功: %s -> %s", locator, llm_locator)
                return r
        failed_result["self_heal_llm_attempted"] = bool(llm_locator)

    # 4) 全部失败：附 DOM 摘要，让 AI 继续修
    failed_result["self_heal_attempted"] = True
    failed_result["self_heal_attempts"] = attempts
    summary = _dom_summary(dom_text, locator)
    if summary:
        failed_result["self_heal_dom"] = summary
    return failed_result


@mcp.tool
async def execute_step(
    keyword: str,
    arguments: CoercedStringList = None,
    session_id: str = "default",
    raise_on_failure: bool = True,
    detail_level: DetailLevel = "minimal",
    scenario_hint: str = None,
    assign_to: Optional[Union[str, List[str]]] = None,
    use_context: bool | None = None,
    mode: ExecutionMode = "keyword",
    expression: str | None = None,
    timeout_ms: int | None = None,
    bdd_group: str = "",
    bdd_intent: str = "",
    record: bool | None = None,
    pre_validate_timeout_ms: int | None = None,
    ctx: Context = None,
) -> Dict[str, Any]:
    """Execute a single Robot Framework keyword (or Evaluate) within a session.

    IMPORTANT: Do NOT invent or guess keyword names. Use find_keywords or get_keyword_info
               to discover available keywords first. Common mistakes:
               - Using "Press Button" (doesn't exist - use "Click" or "Click Button")
               - Using "Verify" (doesn't exist - use "Should Be Equal" or similar)
               - Using "Validate Json" (doesn't exist - use library-specific validation)

    Args:
        keyword: Keyword name (Library.Keyword supported).
                 Use find_keywords to discover correct keyword names before calling.
        arguments: Keyword arguments; positional and named (`name=value`) supported.
        session_id: Session to execute in; resolves default if omitted.
        raise_on_failure: If True, raise on failure; otherwise return error in payload.
        detail_level: Response verbosity: "minimal" | "standard" | "full".
        scenario_hint: Optional scenario text to auto-configure libraries on first call.
        assign_to: Variable name(s) to assign the result to (string or list).
                   CRITICAL: Use this to capture results for later steps.
                   Example: assign_to="response" captures ${response} variable
        use_context: Whether to run inside RF native context; defaults via config/attach.
        mode: "keyword" (default) or "evaluate" (runs BuiltIn.Evaluate).
        expression: Expression for mode="evaluate"; falls back to keyword/first argument.
        timeout_ms: Optional timeout in milliseconds for keyword execution.
                    If not provided, uses smart defaults based on keyword type:
                    - Element actions (Click, Fill): 5000ms
                    - Navigation (Go To, New Page): 60000ms
                    - Read operations (Get Text): 2000ms
                    - API calls (GET, POST): 30000ms
                    Set to 0 or negative to disable timeout.
        bdd_group: Optional group name for BDD keyword generation. Steps with the same
                   bdd_group are clustered into a single behavioral keyword when
                   build_test_suite(bdd_style=True) is called.
                   Example: bdd_group="add product to cart"
        bdd_intent: BDD intent prefix for the group: "given", "when", "then", "and", "but".
                    Used with bdd_group to assign Given/When/Then prefixes in the
                    generated BDD test suite.
        record: Override the record gate that decides whether a successful step
                is appended to session.steps for build_test_suite output.
                - None (default): auto-classify. Read-only inspection keywords
                  (Get Title, Log, etc.) are NOT recorded; everything else IS.
                  Carve-outs that always record: ``assign_to`` is set, or a
                  named test is currently open (after start_test).
                - True: force-record this step regardless of classification.
                - False: drop this step regardless of classification.
                The decision is surfaced as ``recorded: bool`` in the response.
        pre_validate_timeout_ms: Override the pre-validation gate's timeout
                for this single call. Pre-validation is the fast
                ~500ms-default check that verifies an element is visible /
                enabled before the keyword runs; it auto-retries once with
                a 200ms backoff on transient failures.
                - None (default): use ``ExecutionConfig.PRE_VALIDATION_TIMEOUT``
                  (500ms) for slow-loading pages this is sometimes too tight.
                - A positive int (e.g. 2000): extend the gate to this many
                  milliseconds for this call only. Useful when a page
                  legitimately takes ~1–2s to settle.
                - 0 or negative: skip pre-validation entirely for this call
                  (last resort — also disables the keyword timeout).
                Failure responses include a ``pre_validate_timeout_hint``
                entry explaining how to use this when the gate trips.

    Returns:
        Dict[str, Any]: Execution result:
            - success: bool
            - result/output: keyword return value or stringified output
            - assigned_variables / session_variables: when applicable
            - error/guidance: present on failure

    Examples:
        Execute with variable assignment:
            execute_step(
                keyword="GET",
                arguments=["https://api.example.com/users"],
                assign_to="api_response",  # Stores result in ${api_response}
                session_id="api_session"
            )

        Use captured variable:
            execute_step(
                keyword="Should Be Equal",
                arguments=["${api_response.status_code}", "200"],
                session_id="api_session"
            )

        Execute with custom timeout:
            execute_step(
                keyword="Go To",
                arguments=["https://slow-website.com"],
                timeout_ms=120000,  # 2 minutes for slow page
                session_id="web_session"
            )
    """
    arguments = list(arguments or [])

    # Auto-coerce non-string arguments to strings to prevent validation errors
    # Models sometimes pass boolean True instead of "True", or integers instead of strings
    coerced_arguments = []
    for arg in arguments:
        if isinstance(arg, str):
            coerced_arguments.append(arg)
        elif arg is None:
            # Skip None arguments - they're likely optional params the model shouldn't have included
            continue
        elif isinstance(arg, bool):
            # Convert boolean to RF-style string (Python bool to string)
            coerced_arguments.append(str(arg))
        else:
            # Convert other types (int, float, etc.) to string
            coerced_arguments.append(str(arg))
    arguments = coerced_arguments

    # BDD prefix stripping (ADR-019)
    from robotmcp.domains.keyword_resolution.services import BddPrefixService
    bdd_result = None
    if keyword:
        bdd_result = BddPrefixService.strip_prefix(keyword)
        if bdd_result.has_prefix:
            keyword = bdd_result.stripped_name
            logger.debug(
                f"Stripped BDD prefix '{bdd_result.prefix_type.value}' from keyword: "
                f"'{bdd_result.original_name}' -> '{bdd_result.stripped_name}'"
            )

    # Handle assign_to=None explicitly passed by models
    if assign_to is None:
        assign_to = None  # Explicitly set to None (no-op, but clarifies intent)

    mode_norm = (mode or "keyword").strip().lower()
    keyword_to_run = keyword

    if mode_norm == "evaluate":
        expr = expression
        if expr is None:
            if arguments:
                expr = arguments[0]
            elif keyword:
                expr = keyword
        if not expr:
            return {
                "success": False,
                "error": "expression is required when mode='evaluate'",
                "mode": mode_norm,
            }
        keyword_to_run = "Evaluate"
        arguments = [expr]
        if use_context is None:
            use_context = True

    # Determine routing based on attach mode and default settings
    client = _get_external_client_if_configured()
    effective_use_context, mode, strict = _compute_effective_use_context(
        use_context, client, keyword_to_run
    )

    # External routing path
    if client is not None and effective_use_context:
        logger.info(
            f"ATTACH mode: routing execute_step '{keyword_to_run}' to bridge at {client.host}:{client.port}"
        )
        attach_resp = client.run_keyword(keyword_to_run, arguments, assign_to)
        if not attach_resp.get("success"):
            err = attach_resp.get("error", "attach call failed")

            # Distinguish between connectivity errors and application errors.
            # Connectivity errors (bridge unreachable) should fall back to local;
            # application errors (keyword failed on bridge) should be returned
            # directly — falling back to local would fail differently because
            # the local RF context doesn't share browser/page state with the bridge.
            is_connectivity_error = (
                "connection error" in err.lower()
                or "connection refused" in err.lower()
                or "timed out" in err.lower()
                or err == "attach call failed"
                or err == "timeout"
            )

            if is_connectivity_error:
                logger.error(f"ATTACH mode connectivity error: {err}")
                if strict or mode == "force":
                    from robotmcp.compat.fastmcp_compat import tool_error
                    raise tool_error(
                        f"Attach bridge call failed: {err}. Is MCP Serve running and token/port correct?"
                    )
                # Only fall back to local execution for connectivity errors
                logger.warning("ATTACH unreachable; falling back to local execution")
            else:
                # Application-level error from the bridge (keyword actually ran but failed).
                # Return the error directly instead of falling back to local execution,
                # which would fail differently (e.g., "Could not find active page" because
                # browser state lives in the bridge process, not locally).
                logger.error(f"ATTACH mode keyword error: {err}")
                return {
                    "success": False,
                    "keyword": keyword_to_run,
                    "arguments": arguments,
                    "assign_to": assign_to,
                    "mode": mode_norm,
                    "error": err,
                    "source": "attach_bridge",
                }
        else:
            return {
                "success": True,
                "keyword": keyword_to_run,
                "arguments": arguments,
                "assign_to": assign_to,
                "mode": mode_norm,
                "result": attach_resp.get("result"),
                "assigned": attach_resp.get("assigned"),
            }

    # Validate keyword matches session library preference using plugin system
    session = execution_engine.session_manager.get_or_create_session(session_id)
    session_library_preference = getattr(session, "explicit_library_preference", None)

    # Infer library preference from imported_libraries when no explicit preference
    if not session_library_preference:
        _imported = getattr(session, "imported_libraries", []) or []
        if "Browser" in _imported and "SeleniumLibrary" not in _imported:
            session_library_preference = "Browser"
        elif "SeleniumLibrary" in _imported and "Browser" not in _imported:
            session_library_preference = "SeleniumLibrary"

    if session_library_preference and keyword_to_run != "Evaluate":
        try:
            # Try to find the keyword's source library
            plugin_manager = get_library_plugin_manager()
            keyword_source_library = plugin_manager.get_library_for_keyword(
                keyword_to_run.lower()
            )

            # If we found a source library, validate compatibility using plugin
            if keyword_source_library:
                validation_result = plugin_manager.validate_keyword_for_session(
                    session_library_preference,
                    session,
                    keyword_to_run,
                    keyword_source_library,
                )
                if validation_result:
                    # Plugin returned an error - return it directly
                    return validation_result
        except Exception as e:
            logger.debug(f"Could not validate keyword library via plugin: {e}")

    # Local execution path
    result = await execution_engine.execute_step(
        keyword_to_run,
        arguments,
        session_id,
        detail_level,
        scenario_hint=scenario_hint,
        assign_to=assign_to,
        use_context=bool(use_context),
        timeout_ms=timeout_ms,
        record=record,
        pre_validate_timeout_ms=pre_validate_timeout_ms,
    )

    # P0 改造 4：定位类失败自动抓 DOM + 规则重试 1 次（先于 memory 增强）
    if not result.get("success", False) and _is_locator_failure(result):
        try:
            result = await _self_heal_step(
                session_id, keyword_to_run, arguments, result, ctx=ctx,
            )
        except Exception as heal_err:  # 自愈自身失败不影响主流程
            logger.debug("Self-heal failed: %s", heal_err)
            result.setdefault("self_heal_error", str(heal_err))

    # ADR-014.2: Augment failed step results with memory hints
    if not result.get("success", False):
        result = await _augment_with_memory(
            session_id, "execute_step",
            {"keyword": keyword_to_run, "arguments": arguments}, result,
        )

    # For proper MCP protocol compliance, failed steps should raise exceptions
    # This ensures AI agents see failures as red/failed instead of green/successful
    if not result.get("success", False) and raise_on_failure:
        error_msg = result.get("error", f"Step '{keyword}' failed")

        # ADR-010 I4: Extract deprecation suggestion from error
        alias = resolve_deprecated_alias(keyword)
        if alias:
            result["suggested_keyword"] = alias
            result["hint"] = f"'{keyword}' is deprecated. Use '{alias}' instead."
        elif "deprecated" in error_msg.lower():
            suggested = extract_deprecation_suggestion(error_msg)
            if suggested:
                result["suggested_keyword"] = suggested
                result["hint"] = f"'{keyword}' is deprecated. Use '{suggested}' instead."

        # Create detailed error message including suggestions if available
        detailed_error = f"Step execution failed: {error_msg}"
        if result.get("suggested_keyword"):
            detailed_error += f"\nUse '{result['suggested_keyword']}' instead."
        if "suggestions" in result:
            detailed_error += f"\nSuggestions: {', '.join(result['suggestions'])}"
        # Include structured hints for better guidance
        hints = result.get("hints") or []
        if hints:
            try:
                hint_lines = []
                for h in hints:
                    title = h.get("title") or "Hint"
                    message = h.get("message") or ""
                    hint_lines.append(f"- {title}: {message}")
                if hint_lines:
                    detailed_error += "\nHints:\n" + "\n".join(hint_lines)
            except Exception:
                pass
        if "step_id" in result:
            detailed_error += f"\nStep ID: {result['step_id']}"

        # Expected step failure: signal as a FastMCP ToolError logged at WARNING
        # (no traceback on FastMCP 3.x), payload preserved for the agent
        # (change: fastmcp3-failed-step-warning).
        from robotmcp.compat.fastmcp_compat import tool_error
        raise tool_error(detailed_error)

    result["mode"] = mode_norm
    result.setdefault("keyword", keyword_to_run)

    # ADR-019: Annotate BDD prefix in result
    if bdd_result and bdd_result.has_prefix:
        result["bdd_prefix"] = bdd_result.prefix_type.value
        result["original_keyword"] = bdd_result.original_name

    # ADR-019 Phase 2: Annotate BDD group/intent on the ExecutionStep
    if bdd_group or bdd_intent:
        _session = execution_engine.session_manager.get_session(session_id)
        if _session:
            if _session.test_registry.is_multi_test_mode():
                _current_test = _session.test_registry.get_current_test()
                _steps = _current_test.steps if _current_test else []
            else:
                _steps = _session.steps
            if _steps:
                _steps[-1].bdd_group = bdd_group or None
                _steps[-1].bdd_intent = bdd_intent or None
        # Include in response payload
        if bdd_group:
            result["bdd_group"] = bdd_group
        if bdd_intent:
            result["bdd_intent"] = bdd_intent

    # ADR-015: Externalize large fields to artifacts
    result = _externalize_response("execute_step", session_id, result)

    # Track for instruction learning
    _track_tool_result(
        session_id,
        "execute_step",
        {"keyword": keyword_to_run, "arguments": arguments},
        result,
    )

    return result


# ── P0 改造 1：持久化浏览器（跨进程 / 跨 server 重启免登录）────────────────
def _clear_stale_profile_lock(profile_dir: str) -> bool:
    """清理 crash 残留的 Chromium SingletonLock（尽力而为，失败不阻塞）。

    Chromium 对同一 user_data_dir 加 SingletonLock，旧浏览器未退出前第二次 launch
    会失败；进程 crash 后会留残留锁。这里解析锁文件里的 PID，若进程已死则删锁。
    """
    if not profile_dir or not os.path.isdir(profile_dir):
        return False
    lock_names = ("SingletonLock", "SingletonCookie", "SingletonSocket", "lockfile")
    cleaned = False
    for name in lock_names:
        lock_path = os.path.join(profile_dir, name)
        if not os.path.exists(lock_path):
            continue
        try:
            pid = None
            with open(lock_path, "r", errors="ignore") as f:
                raw = f.read().strip()
            if "-" in raw:  # Windows 形如 "127.0.0.1-12345"
                pid = int(raw.rsplit("-", 1)[-1])
            elif raw.isdigit():
                pid = int(raw)
            alive = False
            if pid:
                try:
                    import psutil
                    alive = psutil.pid_exists(pid)
                except Exception:
                    try:
                        os.kill(pid, 0)
                        alive = True
                    except OSError:
                        alive = False
            if not alive:
                os.remove(lock_path)
                cleaned = True
                logger.info("清理残留浏览器锁: %s (PID %s)", lock_path, pid)
        except Exception:
            continue
    return cleaned


async def _clean_browser_state(session_id: str) -> bool:
    """清空浏览器业务状态：localStorage / sessionStorage（保留 cookies/登录态）。

    持久化 profile 会保留业务状态（如购物车），测试重跑前重置可避免元素状态漂移
    （例：saucedemo 商品已在购物车时 Add to cart 按钮变 Remove）。
    注意：不删 cookie；但若站点把登录态存在 localStorage/sessionStorage（如 saucedemo），
    清理后需重新登录。要连 cookie 一起清用 fresh_profile=True。
    """
    try:
        r = await execute_step(
            keyword="Browser.Evaluate JavaScript",
            arguments=["${None}", "() => { localStorage.clear(); sessionStorage.clear(); }"],
            session_id=session_id,
            raise_on_failure=False,
        )
        return bool(r.get("success"))
    except Exception as e:
        logger.debug("Clean storage failed: %s", e)
        return False


@mcp.tool
async def open_persistent_browser(
    user_data_dir: str = None,
    url: str = None,
    session_id: str = "default",
    headless: bool = True,
    browser: str = "chromium",
    reuse_existing: bool = False,
    fresh_profile: bool = False,
    clean_state: bool = False,
) -> Dict[str, Any]:
    """打开（或复用）一个浏览器。

    三种模式：
      - reuse_existing=False（默认）：New Persistent Context，profile 落盘，跨重启免登录。
      - reuse_existing=True：New Browser(reuse_existing=True)，复用 Browser 库已开的
        同配置浏览器（「AI 手动开的浏览器，脚本接着用」）。
      - fresh_profile=True：用临时全新 profile（每次全新状态，不复用旧 cookie/存储）。

    Args:
        user_data_dir: 持久化模式的 profile 目录，缺省 ~/.robotmcp/browser-profiles/<session_id>/
        url: 打开后直接导航到的地址（可选）
        session_id: 会话 ID
        headless: 无头模式（默认 True）
        browser: 浏览器引擎（chromium/firefox/webkit）
        reuse_existing: True 时复用已开浏览器（走 New Browser），False 时走持久化（新开）
        fresh_profile: True 时用临时全新 profile，忽略 user_data_dir（避免旧状态污染）
        clean_state: True 时打开后清空 localStorage/sessionStorage 并重新导航
                     （保留 profile 与 cookie；若站点把登录态存 storage，需重新登录）

    Returns:
        success / reused / user_data_dir / state_cleaned 等。
    """
    # P3 修复：确保 session 登记 Browser 库。open_persistent_browser 直接建 session，
    # 不走 analyze_scenario/init，未登记 Browser 会让 get_page_source 的 web 库自检
    # 直接返回空（DOM 抓不到 → 自愈失效）。
    _session = execution_engine.session_manager.get_or_create_session(session_id)
    if "Browser" not in _session.imported_libraries:
        _session.imported_libraries.append("Browser")
    _session.loaded_libraries.add("Browser")
    if "Browser" not in _session.search_order:
        _session.search_order.append("Browser")

    # 根因修复：若该 session 之前执行过其他关键字（如 BuiltIn.Log / analyze_scenario），
    # session.libraries_loaded 已是 True，execute_step 会跳过 _load_session_libraries，
    # 于是新登记的 Browser 永远进不了 library_manager / RF 上下文，
    # 表现为 execute_step 报 "Browser not loaded in library manager" 然后长时间卡住。
    # 这里在进入 execute_step 前主动把 Browser 加载进 library_manager。
    try:
        _kdisc = execution_engine.keyword_executor.keyword_discovery
        if "Browser" not in _kdisc.library_manager.libraries:
            _kdisc.library_manager.load_library_on_demand(
                "Browser", _kdisc.keyword_discovery
            )
    except Exception as _preload_err:
        logger.debug("Preload Browser library failed: %s", _preload_err)

    # ── P1 改造 5：复用已开浏览器（不走 profile 持久化）──
    if reuse_existing:
        args = [
            browser,
            f"headless={'True' if headless else 'False'}",
            "reuse_existing=True",
        ]
        result = await execute_step(
            keyword="Browser.New Browser",
            arguments=args,
            session_id=session_id,
            raise_on_failure=False,
        )
        if result.get("success") and url:
            nav = await execute_step(
                keyword="Browser.New Page",
                arguments=[url],
                session_id=session_id,
                raise_on_failure=False,
            )
            if not nav.get("success"):
                return nav
            result["navigated_url"] = url
        result.setdefault("reuse_existing", True)
        return result

    # ── 改造 1：持久化浏览器（profile 落盘）──
    if fresh_profile:
        # 每次全新临时 profile，避免旧状态（cookie/localStorage）污染
        import tempfile
        profile_dir = tempfile.mkdtemp(prefix=f"robotmcp-fresh-{session_id}-")
    else:
        profile_dir = user_data_dir or os.path.expanduser(
            f"~/.robotmcp/browser-profiles/{session_id}"
        )
        os.makedirs(profile_dir, exist_ok=True)

    # 1) 复用检测：该 session 已开持久化浏览器则直接返回
    if getattr(_session.browser_state, "context_id", None):
        return {
            "success": True,
            "reused": True,
            "session_id": session_id,
            "user_data_dir": profile_dir,
        }


    # 2) 锁清理：crash 残留 SingletonLock 会阻塞 launch
    _clear_stale_profile_lock(profile_dir)

    # 3) 复用 execute_step 执行真实关键字（走完整 RF 上下文，浏览器常驻）
    args = [profile_dir, browser, f"headless={'True' if headless else 'False'}"]
    if url:
        args.append(f"url={url}")
    result = await execute_step(
        keyword="Browser.New Persistent Context",
        arguments=args,
        session_id=session_id,
        raise_on_failure=False,
    )
    result.setdefault("user_data_dir", profile_dir)

    # clean_state：清空业务状态并重新导航（页面用干净状态重新渲染）
    if clean_state and result.get("success"):
        result["state_cleaned"] = await _clean_browser_state(session_id)
        if url:
            nav = await execute_step(
                keyword="Browser.Go To",
                arguments=[url],
                session_id=session_id,
                raise_on_failure=False,
            )
            if not nav.get("success"):
                return nav
            result["renavigated_url"] = url

    return result


async def _get_application_state_payload(
    state_type: str = "all",
    elements_of_interest: List[str] | None = None,
    session_id: str = "default",
) -> Dict[str, Any]:
    if elements_of_interest is None:
        elements_of_interest = []

    # S3: Bridge path - build application state from bridge data
    client = _get_external_client_if_configured()
    if client is not None:
        try:
            result: Dict[str, Any] = {"success": True, "source": "attach_bridge"}

            if state_type in ("dom", "all"):
                # Reuse _get_page_source_payload for DOM state via bridge
                page_data = await _get_page_source_payload(
                    session_id=session_id,
                    include_reduced_dom=True,
                )
                result["dom_state"] = {
                    "page_source": page_data.get("page_source"),
                    "aria_snapshot": page_data.get("aria_snapshot"),
                    "metadata": page_data.get("metadata"),
                    "success": page_data.get("success", False),
                }

            if state_type in ("api", "all"):
                result["api_state"] = {
                    "note": "API state inspection not available via attach bridge",
                    "success": False,
                }

            if state_type in ("database", "all"):
                result["database_state"] = {
                    "note": "Database state inspection not available via attach bridge",
                    "success": False,
                }

            # Include variables from bridge
            var_data = await _get_context_variables_payload(session_id)
            if var_data.get("success"):
                result["variables"] = var_data.get("variables", {})
                result["variable_count"] = var_data.get("variable_count", 0)

            return result
        except Exception as e:
            logger.debug(f"Application state via bridge failed: {e}")

    # Local fallback
    return await state_manager.get_state(
        state_type, elements_of_interest, session_id, execution_engine
    )


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def get_application_state(
    state_type: str = "all",
    elements_of_interest: List[str] = None,
    session_id: str = "default",
) -> Dict[str, Any]:
    """Retrieve current application state.

    Args:
        state_type: Type of state to retrieve (dom, api, database, all)
        elements_of_interest: Specific elements to focus on
        session_id: Session identifier
    """
    return await _get_application_state_payload(
        state_type=state_type,
        elements_of_interest=elements_of_interest,
        session_id=session_id,
    )


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def suggest_next_step(
    current_state: Dict[str, Any],
    test_objective: str,
    executed_steps: List[Dict[str, Any]] = None,
    session_id: str = "default",
) -> Dict[str, Any]:
    """AI-driven suggestion for next test step.

    Args:
        current_state: Current application state
        test_objective: Overall test objective
        executed_steps: Previously executed steps
        session_id: Session identifier
    """
    if executed_steps is None:
        executed_steps = []
    return await nlp_processor.suggest_next_step(
        current_state, test_objective, executed_steps, session_id
    )


@mcp.tool
async def build_test_suite(
    test_name: str,
    session_id: str = "",
    tags: OptionalCoercedStringList = None,
    documentation: str = "",
    remove_library_prefixes: bool = True,
    bdd_style: bool = False,
    data_driven_mode: str = "auto",
    include_pre_start: bool = False,
    output_path: str = "",
) -> Dict[str, Any]:
    """Generate a Robot Framework test suite from previously executed steps.

    Args:
        test_name: Name for the generated test case.
        session_id: Session containing executed steps; auto-resolves if empty/invalid.
        tags: Optional test tags.
        documentation: Optional test case documentation.
        remove_library_prefixes: Whether to strip library prefixes from keywords.
        bdd_style: Generate BDD-style suite with a Keywords section. When True,
            steps are grouped into behavioral keywords (Given/When/Then) and a
            ``*** Keywords ***`` section is appended to the generated .robot content.
        data_driven_mode: How to render data-driven (template) test cases.
            "auto" (default) — auto-detect: named rows → suite_template, else per_test.
            "per_test" — [Template] per test case with data rows (current behavior).
            "suite_template" — Test Template in Settings, each named row is a separate
            test case with individual pass/fail in reports.
        include_pre_start: Whether to adopt exploratory steps executed BEFORE
            start_test into the generated test body. Default False excludes them
            (the response reports ``excluded_pre_start_count`` + a summary) so the
            suite reflects only intended in-test interactions. Set True to
            preserve the prior adoption behavior.
        output_path: Optional absolute path to persist the generated .robot suite
            to disk directly (UTF-8; parent directories created). ALWAYS use this
            to save a suite — do NOT write ``rf_text`` via the ``Create File``
            keyword: Robot Framework resolves ``${variables}`` and interprets
            ``\\n``/``\\t`` escapes inside the argument, which silently corrupts
            the suite content (assigned vars collapse to their runtime values,
            escaped newlines become raw line breaks). Writing here goes through
            plain file I/O and preserves the generated text byte-for-byte. When
            set, the response includes ``output_path`` and ``output_bytes`` (or
            ``output_error`` on a write failure — the build still succeeds).

    Returns:
        Dict[str, Any]: Suite generation result:
            - success: bool
            - session_id: resolved id
            - suite: structured suite metadata
            - rf_text: generated .robot content
            - output_path/output_bytes: present when output_path was written
            - statistics/optimization_applied: summary of generated steps
            - error/guidance: present on failure
    """
    if tags is None:
        tags = []

    # Import session resolver here to avoid circular imports
    from robotmcp.utils.session_resolution import SessionResolver

    session_resolver = SessionResolver(execution_engine.session_manager)

    # Resolve session with intelligent fallback
    resolution_result = session_resolver.resolve_session_with_fallback(session_id)

    if not resolution_result["success"]:
        # Return enhanced error with guidance
        return {
            "success": False,
            "error": "Session not ready for test suite generation",
            "error_details": resolution_result["error_guidance"],
            "guidance": [
                "Create a session and execute some steps first",
                "Use the session_id returned by analyze_scenario",
                "Check session status with get_session_validation_status",
            ],
            "validation_summary": {"passed": 0, "failed": 0},
            "recommendation": "Start with analyze_scenario() to create a properly configured session",
        }

    # Use resolved session ID
    resolved_session_id = resolution_result["session_id"]

    # Build the test suite with resolved session
    result = await test_builder.build_suite(
        resolved_session_id, test_name, tags, documentation, remove_library_prefixes,
        bdd_style=bdd_style,
        data_driven_mode=data_driven_mode,
        include_pre_start=include_pre_start,
        output_path=output_path,
    )

    # Add session resolution info to result
    if resolution_result.get("fallback_used", False):
        result["session_resolution"] = {
            "fallback_used": True,
            "original_session_id": session_id,
            "resolved_session_id": resolved_session_id,
            "message": f"Automatically used session '{resolved_session_id}' with {resolution_result['session_info']['step_count']} executed steps",
        }
    else:
        result["session_resolution"] = {
            "fallback_used": False,
            "session_id": resolved_session_id,
        }

    # ADR-015: Externalize large fields to artifacts
    result = _externalize_response("build_test_suite", resolved_session_id, result)

    return result


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def load_test_data(
    file_path: str,
    encoding: str = "utf-8",
    dialect: str = "Excel-EU",
    delimiter: str = ";",
    sheet_name: str = "0",
    limit: int = 100,
) -> Dict[str, Any]:
    """Load test data from an external file (CSV, Excel, JSON) for data-driven testing.

    Use this to inspect external data before building data-driven test suites.
    Works with DataDriver-compatible formats (CSV, Excel, JSON).
    If DataDriver is not installed, falls back to built-in CSV/JSON parsing.

    Args:
        file_path: Absolute path to the data file.
        encoding: File encoding (default utf-8).
        dialect: CSV dialect (Excel-EU, excel, unix).
        delimiter: Column delimiter for CSV files.
        sheet_name: Excel sheet index or name.
        limit: Maximum rows to return (default 100).

    Returns:
        Dict with test_cases list, count, format, and column_names.
    """
    try:
        from robotmcp.domains.keyword_resolution.services import (
            DataSourceLoaderService,
        )

        ds = DataSourceLoaderService.load(
            file_path, encoding, dialect, delimiter, sheet_name
        )
        rows = ds.rows[:limit]
        return {
            "success": True,
            "count": ds.count,
            "returned": len(rows),
            "format": ds.format.value,
            "column_names": list(ds.column_names),
            "test_cases": [
                {
                    "test_name": r.test_name,
                    "arguments": r.arguments,
                    "tags": list(r.tags),
                    "documentation": r.documentation,
                }
                for r in rows
            ],
        }
    except FileNotFoundError:
        return {"success": False, "error": f"File not found: {file_path}"}
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def validate_scenario(
    parsed_scenario: Dict[str, Any], available_libraries: List[str] = None
) -> Dict[str, Any]:
    """Pre-execution validation of scenario feasibility.

    Args:
        parsed_scenario: Parsed scenario from analyze_scenario
        available_libraries: List of available RF libraries
    """
    if available_libraries is None:
        available_libraries = []
    return await nlp_processor.validate_scenario(parsed_scenario, available_libraries)


# Note: Removed legacy disabled recommend_libraries_ tool to avoid confusion.


async def _get_page_source_payload(
    session_id: str = "default",
    full_source: bool = False,
    filtered: bool = False,
    filtering_level: str = "standard",
    include_reduced_dom: bool = True,
) -> Dict[str, Any]:
    """Get page source with ARIA snapshot, routing through bridge if available.

    Phase 3 implementation (ADR-003): Uses dedicated bridge methods (get_page_source,
    get_aria_snapshot) for cleaner and more efficient bridge communication.

    Args:
        session_id: Session identifier (used for local fallback)
        full_source: Whether to return full unfiltered source (deprecated, use filtered=False)
        filtered: Whether to apply DOM filtering to reduce content size
        filtering_level: Filtering aggressiveness - "standard" or "aggressive"
        include_reduced_dom: Whether to include ARIA snapshot for semantic DOM representation

    Returns:
        Dict with:
            - success: bool
            - source: "attach_bridge" or "local"
            - page_source: str (HTML/XML content)
            - library: str (Browser, SeleniumLibrary, AppiumLibrary, etc.)
            - metadata: {filtered: bool, full: bool}
            - aria_snapshot: {success: bool, content: str, format: str} or
                           {skipped: True} or {success: False, error: str}
    """
    # Bridge path: use dedicated get_page_source method for cleaner communication
    client = _get_external_client_if_configured()
    if client is not None:
        try:
            # Get page source via dedicated bridge method
            ps_resp = client.get_page_source()
            if ps_resp.get("success"):
                source = ps_resp.get("result", "")
                library_type = ps_resp.get("library", "unknown")

                # Apply local filtering if requested
                is_filtered = False
                if filtered and source:
                    try:
                        from robotmcp.components.execution.page_source_service import (
                            PageSourceService,
                        )

                        source = PageSourceService.filter_page_source(
                            source, filtering_level
                        )
                        is_filtered = True
                    except Exception as filter_err:
                        logger.debug(f"Page source filtering failed: {filter_err}")

                # Get ARIA snapshot if requested
                aria_payload: Dict[str, Any] = {"skipped": True}
                if include_reduced_dom:
                    if library_type == "Browser":
                        # ARIA snapshots only available with Browser Library (Playwright)
                        try:
                            aria_resp = client.get_aria_snapshot(
                                selector="css=html",
                                format_type="yaml",
                            )
                            if aria_resp.get("success"):
                                aria_payload = {
                                    "success": True,
                                    "content": aria_resp.get("result", ""),
                                    "format": aria_resp.get("format", "yaml"),
                                    "selector": "css=html",
                                    "library": "Browser",
                                    "source": "attach_bridge",
                                }
                            else:
                                aria_payload = {
                                    "success": False,
                                    "error": aria_resp.get("error", "unknown"),
                                    "note": aria_resp.get("note"),
                                }
                        except Exception as aria_err:
                            logger.debug(f"ARIA snapshot via bridge failed: {aria_err}")
                            aria_payload = {
                                "success": False,
                                "error": "aria_snapshot_failed_via_bridge",
                            }
                    else:
                        # Non-Browser library - ARIA not available
                        aria_payload = {
                            "success": False,
                            "error": "aria_not_available",
                            "note": f"ARIA snapshots are only available with Browser Library (Playwright), not {library_type}",
                        }

                return {
                    "success": True,
                    "source": "attach_bridge",
                    "page_source": source,
                    "library": library_type,
                    "metadata": {
                        "filtered": is_filtered,
                        "full": not is_filtered,
                    },
                    "aria_snapshot": aria_payload,
                }
            else:
                # Bridge returned failure - log and fall back
                logger.warning(
                    "Bridge get_page_source failed: %s; falling back to local execution",
                    ps_resp.get("error", "unknown error"),
                )
        except Exception as e:
            logger.debug(f"Bridge page source failed: {e}, falling back to local")

    # Local path - fall back to execution engine
    return await execution_engine.get_page_source(
        session_id,
        full_source,
        filtered,
        filtering_level,
        include_reduced_dom,
    )


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def get_page_source(
    session_id: str = "default",
    full_source: bool = False,
    filtered: bool = False,
    filtering_level: str = "standard",
    include_reduced_dom: bool = True,
) -> Dict[str, Any]:
    """Get page source and context for a browser session with optional DOM filtering."""
    return await _get_page_source_payload(
        session_id=session_id,
        full_source=full_source,
        filtered=filtered,
        filtering_level=filtering_level,
        include_reduced_dom=include_reduced_dom,
    )


@mcp.tool
async def check_library_availability(libraries: List[str]) -> Dict[str, Any]:
    """Verify that specified Robot Framework libraries can be imported/installed.

    Recommended as step 3 after analyze_scenario and recommend_libraries; use the recommended
    names to avoid unnecessary checks.

    Args:
        libraries: Library names to verify (preferably from recommend_libraries output).

    Returns:
        Dict[str, Any]: Availability report:
            - success: bool
            - results: per-library availability/install guidance
            - error/guidance: present on failure
    """
    # A project's own library or resource file, named by PATH, is not an installable
    # package: the package checker reported an existing, importable file as
    # "missing" with a pip install suggestion. Probe such paths with libdoc instead.
    local_ok: List[str] = []
    local_bad: Dict[str, str] = {}
    remaining: List[str] = []
    for lib in libraries or []:
        looks_like_path = any(ch in lib for ch in ("/", "\\")) or lib.lower().endswith(
            (".py", ".resource", ".robot")
        )
        if looks_like_path and os.path.exists(lib):
            try:
                from robot.libdoc import LibraryDocumentation

                LibraryDocumentation(lib)
                local_ok.append(lib)
            except Exception as exc:
                local_bad[lib] = str(exc).splitlines()[0][:200]
        else:
            remaining.append(lib)

    result = (
        execution_engine.check_library_requirements(remaining)
        if remaining
        else {"available_libraries": [], "missing_libraries": [],
              "installation_suggestions": []}
    )
    if local_ok or local_bad:
        result["available_libraries"] = list(result.get("available_libraries") or []) + local_ok
        result["missing_libraries"] = list(result.get("missing_libraries") or []) + list(local_bad)
        if local_bad:
            result["local_import_errors"] = local_bad
        if not result.get("missing_libraries"):
            result.pop("error", None)
            result["hint"] = "All requested libraries are available. No installation needed."
    if "success" not in result:
        result["success"] = not bool(result.get("error"))
    if local_bad:
        result["success"] = False
    return result


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def get_library_status(library_name: str) -> Dict[str, Any]:
    """Get detailed installation status for a specific library.

    Args:
        library_name: Name of the library to check (e.g., 'Browser', 'SeleniumLibrary')

    Returns:
        Dict with detailed status and installation information
    """
    return execution_engine.get_installation_status(library_name)


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def get_available_keywords(library_name: str = None) -> List[Dict[str, Any]]:
    """List available RF keywords with minimal metadata.

    Returns one entry per keyword with fields:
    - name: keyword name
    - library: library name
    - args: list of argument names
    - arg_types: list of argument types if available (empty when unknown)
    - short_doc: short documentation summary (no full docstrings)

    If `library_name` is provided, results are filtered to that library, loading it on demand if needed.
    """
    # CRITICAL FIX: Ensure all session libraries are loaded before discovery
    await _ensure_all_session_libraries_loaded()

    return execution_engine.get_available_keywords(library_name)


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def search_keywords(pattern: str) -> List[Dict[str, Any]]:
    """Search for Robot Framework keywords matching a pattern using native RF libdoc.

    Uses Robot Framework's native libdoc API for accurate search results and documentation.
    Searches through keyword names, documentation, short_doc, and tags.

    CRITICAL FIX: Now ensures all session libraries are loaded before search.

    Args:
        pattern: Search pattern to match against keyword names, documentation, or tags

    Returns:
        List of matching keywords with native RF libdoc metadata including short_doc,
        argument types, deprecation status, and enhanced tag information.
    """
    # CRITICAL FIX: Ensure all session libraries are loaded before search
    await _ensure_all_session_libraries_loaded()

    return execution_engine.search_keywords(pattern)


# =====================
# Flow/Control Tools v1
# =====================


def _normalize_step(step: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize a step dict to expected keys."""
    # Accept "args" as well as "arguments", matching execute_batch. Flow steps used
    # to drop "args" silently and then fail with "expected 1 argument, got 0" - an
    # error about the keyword rather than about the step's shape.
    arguments = step.get("arguments")
    if arguments is None:
        arguments = step.get("args")
    if isinstance(arguments, (str, int, float)):
        arguments = [arguments]
    return {
        "keyword": step.get("keyword", ""),
        "arguments": list(arguments or []),
        "assign_to": step.get("assign_to"),
    }


async def _run_steps_in_context(
    session_id: str,
    steps: List[Dict[str, Any]],
    stop_on_failure: bool = True,
) -> List[Dict[str, Any]]:
    """Execute a list of steps via execute_step with use_context=True and return per-step results.

    Does not raise on failure; captures each step's success/error.
    """
    results: List[Dict[str, Any]] = []
    for raw in steps or []:
        s = _normalize_step(raw)
        res = await execution_engine.execute_step(
            s["keyword"],
            s["arguments"],
            session_id,
            detail_level="minimal",
            assign_to=s.get("assign_to"),
            use_context=True,
        )
        results.append(res)
        if not res.get("success", False) and (
            stop_on_failure is True
            or str(stop_on_failure).lower() in ("1", "true", "yes", "on")
        ):
            break
    return results


# =====================
# Batch Execution (ADR-011)
# =====================

# Module-level batch singleton (lazy init)
_batch_runner: Optional[Any] = None


def _get_batch_runner() -> Any:
    """Get or create the batch runner with all adapters wired."""
    global _batch_runner
    if _batch_runner is not None:
        return _batch_runner

    from robotmcp.domains.batch_execution.services import BatchRunner
    from robotmcp.adapters.recovery_adapter import (
        RecoveryServiceAdapter,
        KeywordExecutorAdapter,
    )
    from robotmcp.adapters.page_state_adapter import (
        PageStateCaptureAdapter,
        EvidenceCollectorImpl,
    )
    from robotmcp.container import get_container

    container = get_container()
    kw_adapter = KeywordExecutorAdapter(execution_engine)
    page_state = PageStateCaptureAdapter(execution_engine)
    recovery_adapter = RecoveryServiceAdapter(
        engine=container.recovery_engine,
        keyword_runner=kw_adapter,
        page_state=page_state,
        session_manager=execution_engine.session_manager,
    )
    evidence_collector = EvidenceCollectorImpl(execution_engine)

    _batch_runner = BatchRunner(
        keyword_executor=kw_adapter,
        recovery_service=recovery_adapter,
        evidence_collector=evidence_collector,
    )
    return _batch_runner


@mcp.tool
async def execute_batch(
    session_id: str,
    steps: List[Dict[str, Any]],
    on_failure: str = "recover",
    max_recovery_attempts: int = 2,
    timeout_ms: int = 120000,
) -> Dict[str, Any]:
    """Execute multiple RF keywords in one call with recovery and variable chaining.

    Reduces N MCP round-trips to 1. Steps run sequentially; each step's return
    value is available to later steps via ${STEP_N} references in arguments.
    Both 0-based (${STEP_0} = first step) and 1-based (${STEP_1} = first step)
    indexing are accepted. When ambiguous, 1-based is preferred.

    Args:
        session_id: Session to execute within (must exist or be auto-created).
        steps: List of step dicts, each with:
            - keyword (str, required): RF keyword name
            - arguments (list[str], optional): Positional arguments, may contain ${STEP_N}
              (both 0-based and 1-based indexing supported). This is the canonical
              key (parity with execute_step). The legacy alias ``args`` is also
              accepted; supplying BOTH with different values is a validation error.
            - label (str, optional): Human-readable label
            - timeout (str, optional): Per-step RF timeout (e.g., "10s")
            - assign_to (str, optional): Variable name to capture return value (e.g., "cart_count")
            NOTE: batch steps do NOT support ``bdd_group``/``bdd_intent`` — use
            per-step ``execute_step(bdd_group=..., bdd_intent=...)`` for BDD grouping.
            A step missing ``keyword`` returns an actionable validation error.
        on_failure: Policy on step failure:
            - "stop": abort immediately
            - "retry": retry without recovery logic
            - "recover" (default): attempt tiered recovery before giving up
            On DESKTOP (PlatynUI) sessions, retries are restricted to failures
            where the input provably never fired (element-not-found); any other
            desktop failure records immediately instead of blindly re-firing a
            click/keystroke, and retries run with a capped descriptor-resolution
            timeout so a bad locator cannot burn the whole budget.
        max_recovery_attempts: Max recovery retries per failed step (1-10, default 2).
        timeout_ms: Total batch time budget in milliseconds (1000-600000, default 120000).

    Returns:
        Dict with:
            - status: "PASS" | "FAIL" | "RECOVERED" | "TIMEOUT"
            - summary: human-readable result string
            - total_time_ms: wall-clock execution time
            - steps_executed / steps_total: counts
            - steps: per-step results array
            - failure: diagnostic detail (only on FAIL)
            - batch_id: identifier for resume_batch (only on FAIL)
    """
    try:
        from robotmcp.domains.batch_execution.aggregates import BatchExecution
        from robotmcp.container import get_container

        # Validate session exists
        session = execution_engine.session_manager.get_or_create_session(session_id)

        # Create batch aggregate
        batch = BatchExecution.create(
            session_id=session_id,
            steps_data=steps,
            on_failure=on_failure,
            max_recovery_attempts=max_recovery_attempts,
            timeout_ms=timeout_ms,
        )

        # Execute via BatchRunner
        runner = _get_batch_runner()
        batch = await runner.execute(batch)

        # Store state for resume if failed
        if batch.status and batch.status.value == "FAIL" and batch.failure:
            from robotmcp.domains.batch_execution.aggregates import BatchState

            container = get_container()
            state = BatchState.from_execution(batch)
            container.batch_state_manager.store(state)

        response = batch.to_response_dict()

        # Add compact inline digest for LLM (full steps[] may be externalized)
        steps_list = response.get("steps", [])
        passed = sum(1 for s in steps_list if s.get("status") == "PASS")
        failed = sum(1 for s in steps_list if s.get("status") == "FAIL")
        response["digest"] = {
            "passed": passed,
            "failed": failed,
            "total": len(steps_list),
        }
        if failed > 0:
            # Find first failure for quick summary
            for i, s in enumerate(steps_list):
                if s.get("status") == "FAIL":
                    response["digest"]["failed_at_step"] = i
                    response["digest"]["error"] = (
                        f"{s.get('keyword', '?')}: {s.get('error', 'unknown')}"
                    )[:200]
                    break

        # ADR-015: Externalize large fields to artifacts
        response = _externalize_response("execute_batch", session_id, response)

        # Track for instruction learning
        _track_tool_result(
            session_id,
            "execute_batch",
            {"steps": steps, "on_failure": on_failure},
            {"success": response.get("status") == "PASS", **response},
        )

        return response

    except ValueError as e:
        return {"success": False, "error": str(e), "session_id": session_id}
    except Exception as e:
        logger.error("execute_batch failed: %s", e, exc_info=True)
        return {"success": False, "error": str(e), "session_id": session_id}


@mcp.tool
async def resume_batch(
    batch_id: str,
    fix_steps: List[Dict[str, Any]] | None = None,
    timeout_ms: int | None = None,
) -> Dict[str, Any]:
    """Resume a failed batch from its failure point, optionally inserting fix steps.

    After execute_batch returns status=FAIL with a batch_id, call this to:
    1. Re-run the failed step (with optional fix_steps injected before it)
    2. Continue executing remaining steps from the original batch

    Args:
        batch_id: The batch_id from a failed execute_batch response.
        fix_steps: Optional steps to execute before retrying the failed step.
            Same format as execute_batch steps.
        timeout_ms: Override remaining timeout budget (uses original if omitted).

    Returns:
        Same format as execute_batch response.
    """
    try:
        from robotmcp.domains.batch_execution.aggregates import (
            BatchExecution,
            BatchState,
        )
        from robotmcp.domains.batch_execution.entities import BatchStep
        from robotmcp.domains.batch_execution.value_objects import (
            BatchTimeout,
            StepTimeout,
        )
        from robotmcp.container import get_container

        container = get_container()
        state = container.batch_state_manager.get(batch_id)
        if state is None:
            return {
                "success": False,
                "error": f"No resumable batch found for '{batch_id}' (expired or not found)",
            }

        # Build the continuation steps
        continuation_steps: List[BatchStep] = []
        step_offset = 0

        # Add fix steps first (if any). Argument resolution MUST match
        # execute_batch: ``arguments`` is the canonical key, ``args`` the
        # alias — reading only ``args`` silently dropped fix-step arguments
        # (change: desktop-evidence-and-display-scoping, D5).
        if fix_steps:
            from robotmcp.domains.batch_execution.aggregates import (
                BatchExecution as _BatchExecution,
            )

            for i, s in enumerate(fix_steps):
                step_timeout = StepTimeout(s["timeout"]) if s.get("timeout") else None
                continuation_steps.append(
                    BatchStep(
                        index=i,
                        keyword=s["keyword"],
                        args=_BatchExecution._resolve_step_args(s, i),
                        label=s.get("label", f"fix_step_{i}"),
                        timeout=step_timeout,
                        assign_to=s.get("assign_to"),
                    )
                )
            step_offset = len(fix_steps)

        # Add the failed step
        failed = state.failed_step
        if failed:
            continuation_steps.append(
                BatchStep(
                    index=step_offset,
                    keyword=failed.keyword,
                    args=list(failed.args),
                    label=failed.label,
                    timeout=failed.timeout,
                    assign_to=failed.assign_to,
                )
            )
            step_offset += 1

        # Add remaining steps
        for s in state.remaining_steps:
            continuation_steps.append(
                BatchStep(
                    index=step_offset,
                    keyword=s.keyword,
                    args=list(s.args),
                    label=s.label,
                    timeout=s.timeout,
                    assign_to=s.assign_to,
                )
            )
            step_offset += 1

        if not continuation_steps:
            container.batch_state_manager.remove(batch_id)
            return {
                "success": True,
                "status": "PASS",
                "summary": "No remaining steps to execute",
                "steps": [],
            }

        # Determine timeout
        remaining_ms = timeout_ms or int(state.remaining_timeout_ms)
        remaining_ms = max(remaining_ms, 1000)  # At least 1s

        # Create new batch from continuation steps
        batch = BatchExecution(
            batch_id=state.batch_id,
            session_id=state.session_id,
            steps=continuation_steps,
            on_failure=state.on_failure,
            max_recovery_attempts=state.max_recovery_attempts,
            timeout=BatchTimeout(remaining_ms),
            results=list(state.results),
            results_map=dict(state.results_map),
        )

        # Execute
        runner = _get_batch_runner()
        batch = await runner.execute(batch)

        # Clean up state
        container.batch_state_manager.remove(batch_id)

        # Store new state if failed again
        if batch.status and batch.status.value == "FAIL" and batch.failure:
            new_state = BatchState.from_execution(batch)
            container.batch_state_manager.store(new_state)

        return batch.to_response_dict()

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except Exception as e:
        logger.error("resume_batch failed: %s", e, exc_info=True)
        return {"success": False, "error": str(e)}


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def evaluate_expression(
    session_id: str,
    expression: str,
    assign_to: str | None = None,
) -> Dict[str, Any]:
    """Evaluate a Python expression in RF context (BuiltIn.Evaluate).

    - Uses the current RF session variables; supports ${var} inside the expression.
    - Optionally assigns the result to a variable name (test scope).
    """
    res = await execution_engine.execute_step(
        "Evaluate",
        [expression],
        session_id,
        detail_level="minimal",
        assign_to=assign_to,
        use_context=True,
    )
    return res


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def set_variables(
    session_id: str,
    variables: Dict[str, Any] | List[str],
    scope: str = "test",
) -> Dict[str, Any]:
    """Set multiple variables in the RF session Variables store.

    - variables: either a dict {name: value} or a list of "name=value" strings.
    - scope: one of 'test', 'suite', 'global' (default 'test').
    """
    # Normalize input
    pairs: Dict[str, Any] = {}
    if isinstance(variables, dict):
        pairs = variables
    else:
        for item in variables:
            if isinstance(item, str) and "=" in item:
                n, v = item.split("=", 1)
                pairs[n.strip()] = v

    set_kw = {
        "test": "Set Test Variable",
        "suite": "Set Suite Variable",
        "global": "Set Global Variable",
    }.get(scope.lower(), "Set Test Variable")

    # If bridge configured, set in external context using client
    client = _get_external_client_if_configured()
    results: Dict[str, bool] = {}
    if client is not None:
        for name, value in pairs.items():
            try:
                resp = client.set_variable(name, value, scope=scope)
                results[name] = bool(resp.get("success"))
            except Exception:
                results[name] = False
        return {
            "success": all(results.values()),
            "session_id": session_id,
            "set": list(results.keys()),
            "scope": scope,
            "external": True,
        }
    for name, value in pairs.items():
        # Use RF keyword so scoping is honored
        res = await execution_engine.execute_step(
            set_kw,
            [f"${{{name}}}", value],
            session_id,
            detail_level="minimal",
            use_context=True,
        )
        results[name] = bool(res.get("success"))

    return {
        "success": all(results.values()),
        "session_id": session_id,
        "set": list(results.keys()),
        "scope": scope,
    }


async def _execute_if_impl(
    session_id: str,
    condition: str,
    then_steps: List[Dict[str, Any]],
    else_steps: List[Dict[str, Any]] | None = None,
    stop_on_failure: bool = True,
) -> Dict[str, Any]:
    """Evaluate a condition in RF context and run then/else blocks of steps."""
    # Record flow block
    try:
        sess = execution_engine.session_manager.get_or_create_session(session_id)
        block = {
            "type": "if",
            "condition": condition,
            "then": [_normalize_step(s) for s in (then_steps or [])],
            "else": [_normalize_step(s) for s in (else_steps or [])],
        }
        # ADR-005: route flow block to current test in multi-test mode
        if sess.test_registry.is_multi_test_mode():
            current = sess.test_registry.get_current_test()
            if current:
                current.flow_blocks.append(block)
            else:
                sess.flow_blocks.append(block)
        else:
            sess.flow_blocks.append(block)
    except Exception:
        pass

    cond = await execution_engine.execute_step(
        "Evaluate",
        [condition],
        session_id,
        detail_level="minimal",
        use_context=True,
    )
    truthy = False
    if cond.get("success"):
        out = str(cond.get("output", "")).strip().lower()
        truthy = out in ("true", "1", "yes", "on")
    branch = then_steps if truthy else (else_steps or [])
    step_results = await _run_steps_in_context(session_id, branch, stop_on_failure)
    ok = all(sr.get("success", False) for sr in step_results)
    return {
        "success": ok,
        "branch_taken": "then" if truthy else "else",
        "condition_result": cond.get("output") if cond.get("success") else None,
        "steps": step_results,
    }


async def _execute_for_each_impl(
    session_id: str,
    items: List[Any] | None,
    steps: List[Dict[str, Any]],
    item_var: str = "item",
    stop_on_failure: bool = True,
    max_iterations: int = 1000,
) -> Dict[str, Any]:
    """Run a sequence of steps for each item, setting ${item_var} in RF context per iteration."""
    # Record flow block (do not unroll items)
    try:
        sess = execution_engine.session_manager.get_or_create_session(session_id)
        block = {
            "type": "for_each",
            "item_var": item_var,
            "items": list(items or []),
            "body": [_normalize_step(s) for s in (steps or [])],
        }
        # ADR-005: route flow block to current test in multi-test mode
        if sess.test_registry.is_multi_test_mode():
            current = sess.test_registry.get_current_test()
            if current:
                current.flow_blocks.append(block)
            else:
                sess.flow_blocks.append(block)
        else:
            sess.flow_blocks.append(block)
    except Exception:
        pass

    if not items:
        return {"success": True, "iterations": [], "count": 0}

    iterations: List[Dict[str, Any]] = []
    count = 0
    for idx, it in enumerate(items):
        if idx >= int(max_iterations):
            break
        # Set ${item_var} in test scope using BuiltIn keyword
        _ = await execution_engine.execute_step(
            "Set Test Variable",
            [f"${{{item_var}}}", it],
            session_id,
            detail_level="minimal",
            use_context=True,
        )
        step_results = await _run_steps_in_context(session_id, steps, stop_on_failure)
        iterations.append({"index": idx, "item": it, "steps": step_results})
        count += 1
        if any(not sr.get("success", False) for sr in step_results) and stop_on_failure:
            break

    overall_success = all(
        all(sr.get("success", False) for sr in it["steps"]) for it in iterations
    )
    return {"success": overall_success, "iterations": iterations, "count": count}


async def _execute_try_except_impl(
    session_id: str,
    try_steps: List[Dict[str, Any]],
    except_patterns: List[str] | None = None,
    except_steps: List[Dict[str, Any]] | None = None,
    finally_steps: List[Dict[str, Any]] | None = None,
    rethrow: bool = False,
) -> Dict[str, Any]:
    """Execute steps in a TRY/EXCEPT/FINALLY structure."""
    # Record flow block
    try:
        sess = execution_engine.session_manager.get_or_create_session(session_id)
        block = {
            "type": "try",
            "try": [_normalize_step(s) for s in (try_steps or [])],
            "except_patterns": list(except_patterns or []),
            "except": [_normalize_step(s) for s in (except_steps or [])]
            if except_steps
            else [],
            "finally": [_normalize_step(s) for s in (finally_steps or [])]
            if finally_steps
            else [],
        }
        # ADR-005: route flow block to current test in multi-test mode
        if sess.test_registry.is_multi_test_mode():
            current = sess.test_registry.get_current_test()
            if current:
                current.flow_blocks.append(block)
            else:
                sess.flow_blocks.append(block)
        else:
            sess.flow_blocks.append(block)
    except Exception:
        pass

    # Stop try body at first failure (subsequent steps should not execute)
    try_res = await _run_steps_in_context(session_id, try_steps, stop_on_failure=True)
    first_fail = next((r for r in try_res if not r.get("success", False)), None)
    handled = False
    exc_res: List[Dict[str, Any]] | None = None
    fin_res: List[Dict[str, Any]] | None = None
    err_text = None

    if first_fail is not None:
        err_text = first_fail.get("error") or str(first_fail)
        pats = except_patterns or []
        # Glob-style match; '*' catches all
        match = False
        if not pats:
            match = True
        else:
            try:
                from fnmatch import fnmatch

                for p in pats:
                    if isinstance(p, str):
                        pat = p.strip()
                        if (
                            pat == "*"
                            or fnmatch(err_text.lower(), pat.lower())
                            or (pat.lower() in err_text.lower())
                        ):
                            match = True
                            break
            except Exception:
                match = any(
                    (isinstance(p, str) and p.lower() in err_text.lower()) for p in pats
                )
        if match and (except_steps or []):
            exc_res = await _run_steps_in_context(
                session_id, except_steps or [], stop_on_failure=False
            )
            handled = True

    if finally_steps:
        fin_res = await _run_steps_in_context(
            session_id, finally_steps, stop_on_failure=False
        )

    success = first_fail is None or handled
    result: Dict[str, Any] = {
        "success": success
        if not bool(rethrow)
        else False
        if (first_fail and not handled)
        else success,
        "handled": handled,
        "try_results": try_res,
    }
    if exc_res is not None:
        result["except_results"] = exc_res
    if fin_res is not None:
        result["finally_results"] = fin_res
    if err_text is not None and not handled:
        result["error"] = err_text
    return result


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def execute_if(
    session_id: str,
    condition: str,
    then_steps: List[Dict[str, Any]],
    else_steps: List[Dict[str, Any]] | None = None,
    stop_on_failure: bool = True,
) -> Dict[str, Any]:
    return await _execute_if_impl(
        session_id=session_id,
        condition=condition,
        then_steps=then_steps,
        else_steps=else_steps,
        stop_on_failure=stop_on_failure,
    )


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def execute_for_each(
    session_id: str,
    items: List[Any] | None,
    steps: List[Dict[str, Any]],
    item_var: str = "item",
    stop_on_failure: bool = True,
    max_iterations: int = 1000,
) -> Dict[str, Any]:
    return await _execute_for_each_impl(
        session_id=session_id,
        items=items,
        steps=steps,
        item_var=item_var,
        stop_on_failure=stop_on_failure,
        max_iterations=max_iterations,
    )


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def execute_try_except(
    session_id: str,
    try_steps: List[Dict[str, Any]],
    except_patterns: List[str] | None = None,
    except_steps: List[Dict[str, Any]] | None = None,
    finally_steps: List[Dict[str, Any]] | None = None,
    rethrow: bool = False,
) -> Dict[str, Any]:
    return await _execute_try_except_impl(
        session_id=session_id,
        try_steps=try_steps,
        except_patterns=except_patterns,
        except_steps=except_steps,
        finally_steps=finally_steps,
        rethrow=rethrow,
    )


@mcp.tool
async def get_keyword_info(
    mode: str = "keyword",
    keyword_name: str | None = None,
    library_name: str | None = None,
    session_id: str | None = None,
    arguments: List[str] | None = None,
) -> Dict[str, Any]:
    """Get keyword/library docs or parse a signature. Call this before execute_step
    when you know the keyword name but not its arguments.

    Modes: "keyword" (default — document one keyword), "library" (list a library's
    keywords), "session" (resolve against the live session namespace), "parse"
    (parse a signature string). Pass session_id to scope the lookup to that
    session's libraries.

    Args:
        mode: One of "keyword" (default), "library", "session", or "parse".
        keyword_name: Keyword to document (required for modes "keyword"/"session"/"parse").
        library_name: Library to document (required for mode "library";
                      optional for keyword mode — explicit per-call scope
                      that takes precedence over session-derived scope).
        session_id: Optional session id.
                    - mode="keyword" / "global" (OBS-19): when provided
                      without ``library_name``, restricts the keyword
                      lookup to libraries imported in that session
                      (plus neutral helpers like BuiltIn, Collections).
                      When the keyword exists only in other libraries,
                      the response carries a library-mismatch error +
                      plugin-generated alternative hint instead of the
                      keyword doc. Sessions without ``session_id`` get
                      the global lookup (cross-library matches[]).
                    - mode="session" / "namespace": required to address
                      the live RF namespace.
                    - **Externalisation gate (OBS-21)**: any mode with
                      ``session_id`` provided enables artifact
                      externalisation for large payloads (``library.doc``,
                      ``library.keywords``, ``keyword.doc``, ``matches``).
                      Without ``session_id``, payloads stay inline
                      regardless of size — there's no artifact store
                      to write to, so sessionless callers get the full
                      content. Preserves backwards compat.
        arguments: Optional arguments to parse when mode="parse".

    Returns:
        Dict[str, Any]: Documentation or parse payload:
            - success: bool
            - mode: resolved mode
            - doc/signature data or error on failure
            - hint: plugin library-mismatch hint when applicable
              (OBS-19 mode="keyword" + session-scope mismatch)
            - Large fields may be replaced by "Content saved to ..."
              artifact summary strings when ``session_id`` is provided
              and the field exceeds the inline threshold (OBS-21).
    """

    mode_norm = (mode or "keyword").strip().lower()

    if mode_norm in {"keyword", "global"}:
        if not keyword_name:
            return {"success": False, "error": "keyword_name is required"}
        result = await _get_keyword_documentation_payload(
            keyword_name, library_name, session_id=session_id,
        )
        result["mode"] = "keyword"
        # OBS-21 — externalise large keyword.doc / matches payloads.
        # The keyword-mode payload is usually small (200-400 tokens),
        # but verbose docstrings (e.g., New Persistent Context with
        # 40 args) can exceed the inline threshold. Gated on session_id
        # per the existing externalisation contract.
        if session_id:
            result = _externalize_response(
                "get_keyword_info", session_id, result
            )
        return result

    if mode_norm in {"library", "libdoc"}:
        if not library_name:
            return {"success": False, "error": "library_name is required"}
        result = _project_library_documentation(library_name, session_id)
        if result is None:
            result = await _get_library_documentation_payload(library_name)
        result["mode"] = "library"
        # OBS-21 — library mode is the major token whale (benchmark
        # K06 returned 71,521 tokens for full Browser libdoc).
        # Externalise the heavy fields (library.doc + library.keywords)
        # so the inline payload stays compact when session_id is
        # provided.
        if session_id:
            result = _externalize_response(
                "get_keyword_info", session_id, result
            )
        return result

    if mode_norm in {"session", "namespace"}:
        if not session_id or not keyword_name:
            return {
                "success": False,
                "error": "session_id and keyword_name are required for mode='session'",
            }
        result = await _get_session_keyword_documentation_payload(
            session_id, keyword_name
        )
        result["mode"] = "session"
        # OBS-21 — session-mode keyword payload may carry verbose doc
        # for library keywords; externalise on the same gate.
        result = _externalize_response(
            "get_keyword_info", session_id, result
        )
        return result

    if mode_norm in {"parse", "signature"}:
        if not keyword_name:
            return {"success": False, "error": "keyword_name is required"}
        parsed = await _debug_parse_keyword_arguments_payload(
            keyword_name=keyword_name,
            arguments=arguments or [],
            library_name=library_name,
            session_id=session_id,
        )
        parsed["mode"] = "parse"
        return parsed

    return {"success": False, "error": f"Unsupported mode '{mode}'"}


async def _get_keyword_documentation_payload(
    keyword_name: str,
    library_name: str | None = None,
    session_id: str | None = None,
) -> Dict[str, Any]:
    """OBS-19 — when ``session_id`` is provided, scope the lookup to
    the session's imported libraries so the response cannot document
    keywords unavailable in the live session.

    Precedence: ``library_name`` (explicit per-call scope) wins, then
    session-derived ``allowed_libraries``, then global lookup.

    When the keyword exists only in non-allowed libraries, the
    response is transformed into a library-mismatch error with an
    alternative hint via the existing plugin
    ``validate_keyword_for_session`` shared API at
    ``LibraryPluginManager.validate_keyword_for_session`` (manager.py:239).
    """
    allowed_libraries: Optional[List[str]] = None
    session_for_hint = None

    # Resolve session-scoped allowed libraries when caller passed a
    # session_id BUT did not pin to a specific library (library_name
    # already implies its own strict scope).
    if session_id and not library_name:
        session = execution_engine.session_manager.get_session(session_id)
        if session is None:
            return {
                "success": False,
                "error": f"Session '{session_id}' not found",
            }
        # imported_libraries is a list/set on ExecutionSession.
        # Neutral helpers always visible alongside the UI library —
        # mirrors keyword_discovery.py:264 neutral set so session-
        # scoped lookups still find BuiltIn helpers.
        # NB: even when ``imported`` is empty (fresh session, no
        # libraries imported yet), session_id is load-bearing — we
        # still scope to neutral libraries rather than silently fall
        # through to the global lookup. (Codex round-3 caught this:
        # the old ``if imported:`` guard let an empty list become a
        # de facto "no scoping" path, contradicting the session
        # contract.)
        imported = list(getattr(session, "imported_libraries", []) or [])
        neutral = {
            "BuiltIn", "Collections", "String", "DateTime",
            "OperatingSystem", "Process", "XML",
        }
        allowed_libraries = sorted(set(imported) | neutral)
        session_for_hint = session

    result = execution_engine.get_keyword_documentation(
        keyword_name, library_name, allowed_libraries=allowed_libraries,
        session_id=session_id or None,
    )

    # OBS-19 — if the lookup failed because the keyword exists only
    # in non-allowed libraries, enrich the response with a
    # library-mismatch hint via the active plugin's shared API.
    if (
        result.get("success") is False
        and result.get("found_in_other_libraries")
        and session_for_hint is not None
    ):
        # The first "other" library that the keyword lives in is the
        # source library for the mismatch hint. Pick the first; if
        # multiple, the plugin alternative table is typically library-
        # specific and only one will produce a hint anyway.
        source_lib = result["found_in_other_libraries"][0]
        try:
            from robotmcp.plugins.manager import get_library_plugin_manager
            plugin_manager = get_library_plugin_manager()
            # Determine which library the session is using for UI work.
            # Use the explicit_library_preference if set; else the
            # first imported UI library (Browser or SeleniumLibrary).
            session_lib = getattr(
                session_for_hint, "explicit_library_preference", None
            )
            if not session_lib:
                imported_libs = list(
                    getattr(session_for_hint, "imported_libraries", []) or []
                )
                for candidate in ("Browser", "SeleniumLibrary"):
                    if candidate in imported_libs:
                        session_lib = candidate
                        break
            if session_lib:
                hint = plugin_manager.validate_keyword_for_session(
                    session_lib,
                    session_for_hint,
                    keyword_name,
                    source_lib,
                )
                if hint:
                    # Preserve the existing error message; add the
                    # plugin's structured alternative info under
                    # ``hint`` so the agent can act on it.
                    result["hint"] = hint
        except Exception:
            # Hint enrichment is best-effort.
            pass

    return result


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def get_keyword_documentation(
    keyword_name: str, library_name: str = None
) -> Dict[str, Any]:
    """Get full documentation for a specific Robot Framework keyword using native RF libdoc.

    Uses Robot Framework's native LibraryDocumentation and KeywordDoc objects to provide
    comprehensive keyword information including source location, argument types, and
    deprecation status when available.

    Args:
        keyword_name: Name of the keyword to get documentation for
        library_name: Optional library name to narrow search

    Returns:
        Dict containing comprehensive keyword information:
        - success: Boolean indicating if keyword was found
        - keyword: Dict with keyword details including:
          - name, library, args: Basic keyword information
          - arg_types: Argument types from libdoc (when available)
          - doc: Full documentation text
          - short_doc: Native Robot Framework short_doc
          - tags: Keyword tags
          - is_deprecated: Deprecation status (libdoc only)
          - source: Source file path (libdoc only)
          - lineno: Line number in source (libdoc only)
    """
    return await _get_keyword_documentation_payload(keyword_name, library_name)


def _project_library_documentation(
    library_name: str, session_id: Optional[str]
) -> Optional[Dict[str, Any]]:
    """Library-mode docs for a project source (custom library or resource file).

    The catalogue lookup knows rf-mcp's bundled libraries only, so a resource
    imported into a session (``acme_keywords``) was "not found or not loaded" even
    though its keywords executed. Resolves by namespace name, alias or file path;
    without session_id, falls back to any session that registered the source.
    Returns None to defer to the catalogue.
    """
    try:
        from robotmcp.utils.rf_libdoc_integration import get_rf_doc_storage

        storage = get_rf_doc_storage()
        candidates = [session_id] if session_id else storage.sessions_with_project_sources()
        for sid in candidates:
            info = storage.resolve_project_source(sid, library_name)
            if info is None:
                continue
            spec = storage.project_import_spec(sid, library_name) or {}
            return {
                "success": True,
                "library": {
                    "name": spec.get("alias") or info.name,
                    "doc": info.doc,
                    "version": info.version,
                    "type": info.type,
                    "scope": info.scope,
                    "source": info.source,
                    "import": {k: spec.get(k) for k in ("spec", "args", "alias")},
                    "keywords": [
                        {
                            "name": ki.name, "library": ki.library, "args": ki.args,
                            "arg_types": ki.arg_types, "doc": ki.doc,
                            "short_doc": ki.short_doc, "tags": ki.tags,
                            "is_deprecated": ki.is_deprecated, "source": ki.source,
                            "lineno": ki.lineno,
                        }
                        for ki in info.keywords.values()
                    ],
                    "keyword_count": len(info.keywords),
                    "from_project": True,
                    **({} if session_id else {"session_id": sid}),
                },
            }
    except Exception as exc:  # pragma: no cover - defensive
        logger.debug("Project library lookup failed for %r: %s", library_name, exc)
    return None


async def _get_library_documentation_payload(library_name: str) -> Dict[str, Any]:
    return execution_engine.get_library_documentation(library_name)


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def get_library_documentation(library_name: str) -> Dict[str, Any]:
    """Get full documentation for a Robot Framework library using native RF libdoc.

    Uses Robot Framework's native LibraryDocumentation API to provide comprehensive
    library information including library metadata and all keywords with their
    documentation, arguments, and metadata.

    Args:
        library_name: Name of the library to get documentation for

    Returns:
        Dict containing comprehensive library information:
        - success: Boolean indicating if library was found
        - library: Dict with library details including:
          - name: Library name
          - doc: Library documentation
          - version: Library version
          - type: Library type
          - scope: Library scope
          - source: Source file path
          - keywords: List of all library keywords with full details including:
            - name: Keyword name
            - args: List of argument names
            - arg_types: List of argument types (when available from libdoc)
            - doc: Full keyword documentation text
            - short_doc: Native Robot Framework short_doc
            - tags: Keyword tags
            - is_deprecated: Deprecation status (libdoc only)
            - source: Source file path (libdoc only)
            - lineno: Line number in source (libdoc only)
          - keyword_count: Total number of keywords in library
          - data_source: 'libdoc' or 'inspection' indicating data source
    """
    return await _get_library_documentation_payload(library_name)


async def _debug_parse_keyword_arguments_payload(
    keyword_name: str,
    arguments: List[str],
    library_name: str = None,
    session_id: str = None,
) -> Dict[str, Any]:
    """Debug helper: Parse arguments into positional and named using RF-native logic.

    Uses the same parsing path as execution to verify how name=value pairs are handled
    for a given keyword and (optionally) library.

    Args:
        keyword_name: Keyword to parse for (e.g., 'Open Application').
        arguments: List of argument strings as they would be passed to execute_step.
        library_name: Optional library name to disambiguate (e.g., 'AppiumLibrary').
        session_id: Optional session to pull variables from for resolution.

    Returns:
        - success: True
        - parsed: { positional: [...], named: {k: v} }
        - notes: brief info on library and session impact
    """
    try:
        session_vars = {}
        if session_id:
            sess = execution_engine.get_session(session_id)
            if sess:
                session_vars = sess.variables

        parsed = execution_engine.keyword_executor.argument_processor.parse_arguments_for_keyword(
            keyword_name, arguments, library_name, session_vars
        )
        return {
            "success": True,
            "parsed": {"positional": parsed.positional, "named": parsed.named},
            "notes": {
                "library_name": library_name,
                "session_id": session_id,
                "positional_count": len(parsed.positional),
                "named_count": len(parsed.named or {}),
            },
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def debug_parse_keyword_arguments(
    keyword_name: str,
    arguments: List[str],
    library_name: str = None,
    session_id: str = None,
) -> Dict[str, Any]:
    return await _debug_parse_keyword_arguments_payload(
        keyword_name=keyword_name,
        arguments=arguments,
        library_name=library_name,
        session_id=session_id,
    )


# TOOL DISABLED: validate_step_before_suite
#
# Reason for removal: This tool is functionally redundant with execute_step().
# Analysis shows that it duplicates execution (performance impact) and adds
# minimal unique value beyond what execute_step() already provides.
#
# Key issues:
# 1. Functional redundancy - re-executes the same step as execute_step()
# 2. Performance overhead - double execution of steps
# 3. Agent confusion - two similar tools with overlapping purposes
# 4. Limited additional value - only adds guidance text and redundant metadata
#
# The validation workflow can be achieved with:
# execute_step() → validate_test_readiness() → build_test_suite()
#
# @mcp.tool
# async def validate_step_before_suite(
#     keyword: str,
#     arguments: List[str] = None,
#     session_id: str = "default",
#     expected_outcome: str = None,
# ) -> Dict[str, Any]:
#     """Validate a single step before adding it to a test suite.
#
#     This method enforces stepwise test development by requiring step validation
#     before suite generation. Use this to verify each keyword works as expected.
#
#     Workflow:
#     1. Call this method for each test step
#     2. Verify the step succeeds and produces expected results
#     3. Only after all steps are validated, use build_test_suite()
#
#     Args:
#         keyword: Robot Framework keyword to validate
#         arguments: Arguments for the keyword
#         session_id: Session identifier
#         expected_outcome: Optional description of expected result for validation
#
#     Returns:
#         Validation result with success status, output, and recommendations
#     """
#     if arguments is None:
#         arguments = []
#
#     # Execute the step with detailed error reporting
#     result = await execution_engine.execute_step(
#         keyword, arguments, session_id, detail_level="full"
#     )
#
#     # Add validation metadata
#     result["validated"] = result.get("success", False)
#     result["validation_time"] = result.get("execution_time")
#
#     if expected_outcome:
#         result["expected_outcome"] = expected_outcome
#         result["meets_expectation"] = "unknown"  # AI agent should evaluate this
#
#     # Add guidance for next steps
#     if result.get("success"):
#         result["next_step_guidance"] = (
#             "✅ Step validated successfully. Safe to include in test suite."
#         )
#     else:
#         result["next_step_guidance"] = (
#             "❌ Step failed validation. Fix issues before adding to test suite."
#         )
#         result["debug_suggestions"] = [
#             "Check keyword spelling and library availability",
#             "Verify argument types and values",
#             "Ensure required browser/context is open",
#             "Review error message for specific issues",
#         ]
#
#     return result


async def _get_session_validation_status_payload(
    session_id: str = "",
) -> Dict[str, Any]:
    # Import session resolver here to avoid circular imports
    from robotmcp.utils.session_resolution import SessionResolver

    session_resolver = SessionResolver(execution_engine.session_manager)

    # Resolve session with intelligent fallback
    resolution_result = session_resolver.resolve_session_with_fallback(session_id)

    if not resolution_result["success"]:
        # Return enhanced error with guidance
        return {
            "success": False,
            "error": f"Session '{session_id}' not found",
            "error_details": resolution_result["error_guidance"],
            "available_sessions": resolution_result["error_guidance"][
                "available_sessions"
            ],
            "sessions_with_steps": resolution_result["error_guidance"][
                "sessions_with_steps"
            ],
            "recommendation": "Use analyze_scenario() to create a session first",
        }

    # Use resolved session ID
    resolved_session_id = resolution_result["session_id"]

    # Get validation status for resolved session
    result = execution_engine.get_session_validation_status(resolved_session_id)

    # Add session resolution info to result
    if resolution_result.get("fallback_used", False):
        result["session_resolution"] = {
            "fallback_used": True,
            "original_session_id": session_id,
            "resolved_session_id": resolved_session_id,
            "message": f"Automatically checked session '{resolved_session_id}'",
        }
    else:
        result["session_resolution"] = {
            "fallback_used": False,
            "session_id": resolved_session_id,
        }

    return result


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def validate_test_readiness(session_id: str = "default") -> Dict[str, Any]:
    """Check if session is ready for test suite generation.

    Enforces stepwise workflow by verifying all steps have been validated.
    Use this before calling build_test_suite() to ensure quality.

    Args:
        session_id: Session identifier to validate

    Returns:
        Readiness status with guidance on next actions
    """
    return await execution_engine.validate_test_readiness(session_id)


@mcp.tool
async def set_library_search_order(
    libraries: CoercedStringList, session_id: str = "default"
) -> Dict[str, Any]:
    """Set explicit library search order for keyword resolution.

    Args:
        libraries: Library names in priority order (highest first).
        session_id: Session to apply the search order to.

    Returns:
        Dict[str, Any]: Result payload:
            - success: bool
            - session_id: echoed id
            - old_search_order/new_search_order: before/after lists
            - warnings: any invalid or missing libraries
    """
    try:
        # Get or create session
        session = execution_engine.session_manager.get_or_create_session(session_id)

        # Project sources (custom libraries, resource files) are recorded on the
        # session by PATH, but RF orders keywords by the source's NAME. Map each
        # requested entry - name, alias or path - to its namespace name.
        project_names: set = set()
        requested: List[str] = []
        try:
            from robotmcp.utils.rf_libdoc_integration import get_rf_doc_storage

            storage = get_rf_doc_storage()
            for lib in libraries:
                ns = storage._resolve_project_name(session_id, lib)
                if ns:
                    project_names.add(ns)
                    requested.append(ns)
                else:
                    requested.append(lib)
        except Exception:  # pragma: no cover - defensive
            requested = list(libraries)

        old_order = session.get_search_order()
        session.set_library_search_order(requested, extra_valid=project_names)
        new_order = session.get_search_order()
        # Previously an unknown entry was dropped with only a log line while the tool
        # still reported success - the project library the caller asked for simply
        # vanished from the order.
        rejected = [lib for lib in requested if lib not in new_order]

        result = {
            "success": not rejected,
            "session_id": session_id,
            "old_search_order": old_order,
            "new_search_order": new_order,
            "libraries_requested": libraries,
            "libraries_applied": new_order,
            "message": f"Library search order updated for session '{session_id}'",
        }
        if rejected:
            result["libraries_rejected"] = rejected
            result["message"] = (
                f"Search order updated, but {rejected} were not applied: not imported "
                f"in session '{session_id}'. Import them first with "
                f"manage_session(action='import_library'|'import_resource')."
            )
        return result

    except Exception as e:
        logger.error(f"Error setting library search order: {e}")
        return {"success": False, "error": str(e), "session_id": session_id}


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def initialize_context(
    session_id: str, libraries: List[str] = None, variables: Dict[str, Any] = None
) -> Dict[str, Any]:
    """Initialize a session with libraries and variables.

    NOTE: Full RF context mode is not yet implemented. This tool currently
    initializes a session with the specified libraries and variables using
    the existing session-based variable system.

    Args:
        session_id: Session identifier
        libraries: List of libraries to import in the session
        variables: Initial variables to set in the session

    Returns:
        Session initialization status with information
    """
    try:
        # Get or create session
        session = execution_engine.session_manager.get_or_create_session(session_id)

        # Import libraries into session
        if libraries:
            for library in libraries:
                try:
                    session.import_library(library)
                    # Also add to loaded_libraries for tracking
                    session.loaded_libraries.add(library)
                    logger.info(f"Imported {library} into session {session_id}")
                except Exception as lib_error:
                    logger.warning(f"Could not import {library}: {lib_error}")

        # Set initial variables in session
        if variables:
            for name, value in variables.items():
                # Normalize variable name to RF format
                if not name.startswith("$"):
                    var_name = f"${{{name}}}"
                else:
                    var_name = name
                session.set_variable(var_name, value)
                logger.info(
                    f"Set variable {var_name} = {value} in session {session_id}"
                )

        return {
            "success": True,
            "session_id": session_id,
            "context_enabled": False,  # Context mode not fully implemented
            "libraries_loaded": list(session.loaded_libraries),
            "variables_set": list(variables.keys()) if variables else [],
            "message": f"Session '{session_id}' initialized with libraries and variables",
            "note": "Using session-based variable system (context mode not available)",
        }

    except Exception as e:
        logger.error(f"Error initializing session {session_id}: {e}")
        return {"success": False, "error": str(e), "session_id": session_id}


async def _get_context_variables_payload(session_id: str) -> Dict[str, Any]:
    """Get variables, preferring bridge when available.

    This function implements Phase 4 of ADR-003 Debug Bridge Unification:
    - Uses _get_external_client_with_session_sync to auto-create session from bridge
    - Ensures first-call success when bridge is active with RF context
    """
    try:
        # Helper to sanitize values: return scalars as-is; for complex objects, return their type name.
        def _sanitize(val: Any) -> Any:
            if isinstance(val, (str, int, float, bool)) or val is None:
                return val
            # Avoid serializing complex/large objects
            return f"<{type(val).__name__}>"

        # --- Phase 4: Use unified client+session retrieval with auto-sync ---
        # This ensures sessions are auto-created from bridge state when needed,
        # fixing first-call failures when bridge is active.
        client, session = _get_external_client_with_session_sync(session_id)

        # --- Attach bridge routing (R3) ---
        # When an attach bridge is configured, read variables from the live RF
        # process.  This ensures variables created during RF execution (e.g. by
        # test setup, resource files, keyword returns) are visible to MCP.
        if client is not None:
            try:
                bridge_resp = client.get_variables()
                if bridge_resp.get("success"):
                    raw_vars = bridge_resp.get("result", {})
                    sanitized = {}
                    for k, v in raw_vars.items():
                        key = k
                        if key.startswith("${") and key.endswith("}"):
                            key = key[2:-1]
                        sanitized[key] = _sanitize(v)
                    return {
                        "success": True,
                        "session_id": session_id,
                        "variables": sanitized,
                        "variable_count": len(sanitized),
                        "source": "attach_bridge",
                        "truncated": bridge_resp.get("truncated", False),
                    }
            except Exception as bridge_err:
                logger.debug(
                    f"Attach bridge variable read failed, falling back: {bridge_err}"
                )

        # Prefer RF Namespace/Variables if an RF context exists for the session
        try:
            from robotmcp.components.execution.rf_native_context_manager import (
                get_rf_native_context_manager,
            )

            mgr = get_rf_native_context_manager()
            ctx_info = mgr.get_session_context_info(session_id)
            if ctx_info.get("context_exists"):
                # Extract variables from RF Variables object
                ctx = mgr._session_contexts.get(session_id)  # internal read-only access
                rf_vars_obj = ctx.get("variables") if ctx else None
                rf_vars: Dict[str, Any] = {}
                if rf_vars_obj is not None:
                    try:
                        if hasattr(rf_vars_obj, "store"):
                            rf_vars = dict(rf_vars_obj.store.data)
                        elif hasattr(rf_vars_obj, "current") and hasattr(
                            rf_vars_obj.current, "store"
                        ):
                            rf_vars = dict(rf_vars_obj.current.store.data)
                    except Exception:
                        rf_vars = {}

                # Attempt to resolve variable resolvers to concrete values via Variables API
                resolved: Dict[str, Any] = {}
                for k, v in rf_vars.items():
                    key = k if isinstance(k, str) else str(k)
                    try:
                        norm = key if key.startswith("${") else f"${{{key}}}"
                        concrete = rf_vars_obj[norm]
                    except Exception:
                        concrete = v
                    resolved[key if not key.startswith("${") else key.strip("${}")] = (
                        concrete
                    )

                sanitized = {str(k): _sanitize(v) for k, v in resolved.items()}
                return {
                    "success": True,
                    "session_id": session_id,
                    "variables": sanitized,
                    "variable_count": len(sanitized),
                    "source": "rf_context",
                }
        except Exception:
            # Fall back to session store below
            pass

        # Fallback: session-based variable store
        # Note: session may have been auto-created by _get_external_client_with_session_sync
        if not session:
            return {
                "success": False,
                "error": f"Session '{session_id}' not found and no active attach bridge",
                "session_id": session_id,
                "hint": "Call execute_step or manage_session(action='init') first, or configure attach bridge",
            }
        sess_vars_raw = dict(session.variables)
        sess_vars = {str(k): _sanitize(v) for k, v in sess_vars_raw.items()}
        return {
            "success": True,
            "session_id": session_id,
            "variables": sess_vars,
            "variable_count": len(sess_vars),
            "source": "session_store",
        }

    except Exception as e:
        logger.error(f"Error getting variables for session {session_id}: {e}")
        return {"success": False, "error": str(e), "session_id": session_id}


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def get_context_variables(session_id: str) -> Dict[str, Any]:
    """Get all variables from a session."""
    return await _get_context_variables_payload(session_id)


async def _get_session_info_payload(session_id: str = "default") -> Dict[str, Any]:
    """Get session info, auto-initializing from bridge if needed.

    This function implements Phase 1 of ADR-003 Debug Bridge Unification:
    - Uses _get_external_client_with_session_sync() to auto-create session from bridge
    - Does not fail if bridge is available even without local session
    """
    try:
        # Use unified client+session retrieval (auto-creates session from bridge if needed)
        client, session = _get_external_client_with_session_sync(session_id)
        base_info = session.get_session_info() if session else {}

        # S5: Enrich with bridge data when available
        if client is not None:
            try:
                diag = client.diagnostics()
                if diag.get("success"):
                    bridge_result = diag.get("result", {})
                    base_info["attach_bridge"] = {
                        "active": True,
                        "libraries": bridge_result.get("libraries", []),
                        "context_active": bridge_result.get("context", False),
                    }
            except Exception as bridge_err:
                logger.debug(
                    f"Bridge diagnostics for session info failed: {bridge_err}"
                )
                base_info["attach_bridge"] = {"active": False, "error": "unreachable"}

        # CRITICAL FIX (ADR-003 S1): Don't fail if bridge is available
        if not session and not base_info.get("attach_bridge", {}).get("active"):
            return {
                "success": False,
                "error": f"Session '{session_id}' not found and no active attach bridge",
                "available_sessions": execution_engine.session_manager.get_all_session_ids(),
                "hint": "Call execute_step or manage_session(action='init') first, or configure attach bridge",
            }

        # ADR-005: Expose multi-test info when active
        if session and session.test_registry.is_multi_test_mode():
            tests_info = []
            for name, ti in session.test_registry.tests.items():
                tests_info.append({
                    "name": name,
                    "status": ti.status,
                    "step_count": len(ti.steps),
                    "tags": ti.tags,
                })
            base_info["multi_test_mode"] = True
            base_info["current_test"] = session.test_registry.current_test_name
            base_info["tests"] = tests_info
            if session.suite_setup:
                base_info["suite_setup"] = session.suite_setup
            if session.suite_teardown:
                base_info["suite_teardown"] = session.suite_teardown
            base_info["suite_level_step_count"] = len(session.suite_level_steps)

        return {"success": True, "session_info": base_info}

    except Exception as e:
        logger.error(f"Error getting session info: {e}")
        return {"success": False, "error": str(e), "session_id": session_id}


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def get_session_info(session_id: str = "default") -> Dict[str, Any]:
    """Get comprehensive information about a session's configuration and state."""
    return await _get_session_info_payload(session_id)


@mcp.tool
async def get_locator_guidance(
    library: str = "browser",
    error_message: str | None = None,
    keyword_name: str | None = None,
) -> Dict[str, Any]:
    """Provide locator/selector guidance for Browser, SeleniumLibrary, AppiumLibrary, PlatynUI.BareMetal, or RequestsLibrary.

    For API testing, call with library="requests" (or "api") to get a
    RequestsLibrary request/response cookbook — session setup, response-field
    access (${resp.json()["field"]}), the $resp-in-Evaluate rule, Status Should
    Be, JSON body/headers, the Cookie token header, and expected_status= for
    non-2xx — BEFORE writing Evaluate-based assertions.

    For VISUAL validation, call with library="visual" (or "screenshot") to learn
    WHEN a screenshot beats the DOM/ARIA tree (canvas/image text, layout/overlap,
    obscured elements, color, charts) and the dual read-back pattern — useful for
    any UI library (Browser/Selenium/Appium/PlatynUI) when a multimodal model
    drives rf-mcp.

    Args:
        library: Target library ("Browser", "SeleniumLibrary", "AppiumLibrary", "PlatynUI.BareMetal", or "RequestsLibrary"/"api"). Case-insensitive.
        error_message: Optional error text to tailor guidance (e.g., from a failed keyword).
        keyword_name: Optional keyword name for context-specific hints.

    Returns:
        Dict[str, Any]: Guidance payload:
            - success: bool
            - library: resolved library name
            - tips/warnings/examples: library-specific suggestions
            - error: present when library is unsupported
    """

    from robotmcp.utils.rf_native_type_converter import RobotFrameworkNativeConverter

    converter = RobotFrameworkNativeConverter()
    lib_norm = (library or "browser").strip().lower()

    if lib_norm in {"browser", "playwright"}:
        result = converter.get_browser_locator_guidance(error_message, keyword_name)
        result["library"] = "Browser"
        result.setdefault("success", True)
        return result

    if lib_norm in {"selenium", "seleniumlibrary"}:
        result = converter.get_selenium_locator_guidance(error_message, keyword_name)
        result["library"] = "SeleniumLibrary"
        result.setdefault("success", True)
        return result

    if lib_norm in {"appium", "appiumlibrary"}:
        result = converter.get_appium_locator_guidance(error_message, keyword_name)
        result["library"] = "AppiumLibrary"
        result.setdefault("success", True)
        return result

    if lib_norm in {"platynui", "platynui.baremetal", "platynui-cli", "baremetal"}:
        result = converter.get_platynui_locator_guidance(error_message, keyword_name)
        result["library"] = "PlatynUI.BareMetal"
        result.setdefault("success", True)
        return result

    if lib_norm in {"requests", "requestslibrary", "api", "rest"}:
        # Proactive RequestsLibrary request/response cookbook (change:
        # api-cookbook) — the API analog agents should pull BEFORE hand-rolling
        # Evaluate-based assertions.
        result = converter.get_requests_guidance(error_message, keyword_name)
        result["library"] = "RequestsLibrary"
        result.setdefault("success", True)
        return result

    if lib_norm in {"visual", "screenshot", "vision", "image"}:
        # Visual-validation guidance (change: visual-inspection-guidance) — WHEN a
        # screenshot beats the DOM/ARIA tree, the dual read-back pattern, and the
        # multimodal/file-access caveats.
        result = converter.get_visual_guidance(error_message, keyword_name)
        result["library"] = "visual"
        result.setdefault("success", True)
        return result

    return {
        "success": False,
        "error": f"Unsupported library '{library}'. Choose Browser, SeleniumLibrary, AppiumLibrary, PlatynUI.BareMetal, RequestsLibrary (api), or visual.",
    }


def _screenshot_mode() -> str:
    """ROBOTMCP_SCREENSHOT_MODE: file | image | auto (default file). Governs whether
    visual_check may return an image content block (change: visual-inspection-guidance)."""
    m = os.environ.get("ROBOTMCP_SCREENSHOT_MODE", "file").strip().lower()
    return m if m in ("file", "image", "auto") else "file"


@mcp.tool
async def visual_check(
    session_id: str,
    return_image: bool = False,
    filename: str | None = None,
) -> Any:
    """Capture a screenshot of the current UI for VISUAL validation (change:
    visual-inspection-guidance).

    Token-cheap by DEFAULT: saves the screenshot to disk and returns the PATH as
    text — a multimodal agent WITH file access reads that file on demand for checks
    the DOM/ARIA can't do (canvas/image text, layout/overlap, obscured elements,
    color, charts). Call get_locator_guidance(library="visual") for when to use it.

    Set return_image=true ONLY if your model is multimodal AND cannot read the saved
    file (e.g. a hosted/remote MCP): the response then includes an image content
    block. This requires ROBOTMCP_SCREENSHOT_MODE to allow images (image|auto);
    text-only deployments (mode=file, the default) always return just the path so a
    text-only model is never sent unsupported image content.

    Works across Browser/SeleniumLibrary/AppiumLibrary/PlatynUI (uses the session's
    screenshot keyword). Degrades cleanly if capture fails.
    """
    import tempfile
    from robotmcp.utils.visual_guidance import VISUAL_HINT_ONE_LINER

    session = execution_engine.session_manager.get_session(session_id)
    if session is None:
        return {"success": False, "error": f"No session '{session_id}'"}

    out_dir = os.environ.get("ROBOTMCP_SCREENSHOT_DIR", "").strip() or tempfile.gettempdir()
    path = filename if (filename and os.path.isabs(filename)) else os.path.join(
        out_dir, f"visual_check_{session_id}.png"
    )

    # Screenshot keyword differs per library — try the Browser/PlatynUI form
    # (filename=<path>) first, then the Selenium/Appium form (positional path).
    attempts = [
        ("Take Screenshot", [f"filename={path}"]),
        ("Capture Page Screenshot", [path]),
    ]
    captured = None
    for kw, args in attempts:
        try:
            res = await execution_engine.execute_step(
                kw, args, session_id, detail_level="minimal", use_context=True
            )
        except Exception:
            continue
        if res.get("success"):
            captured = res.get("screenshot_path") or path
            break

    if not captured or not os.path.isfile(captured):
        return {
            "success": False,
            "error": "screenshot capture failed or produced no file on disk",
            "hint": "ensure a UI library (Browser/Selenium/Appium/PlatynUI) is active in this session",
        }

    size = os.path.getsize(captured)
    base = {
        "success": True,
        "screenshot_path": captured,
        "size_bytes": size,
        "mode": _screenshot_mode(),
        "visual_hint": VISUAL_HINT_ONE_LINER,
    }

    if return_image and _screenshot_mode() in ("image", "auto"):
        try:
            from fastmcp.utilities.types import Image

            # Return the image content block for a multimodal model, plus the path.
            return [base, Image(path=captured)]
        except Exception:
            base["image_error"] = "Image content unavailable; returning path only"
            return base
    return base


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def get_selenium_locator_guidance(
    error_message: str = None, keyword_name: str = None
) -> Dict[str, Any]:
    """Get comprehensive SeleniumLibrary locator strategy guidance for AI agents.

    This tool helps AI agents understand SeleniumLibrary's locator strategies and
    provides context-aware suggestions for element location and error resolution.

    SeleniumLibrary supports these locator strategies:
    - id: Element id (e.g., 'id:example')
    - name: name attribute (e.g., 'name:example')
    - identifier: Either id or name (e.g., 'identifier:example')
    - class: Element class (e.g., 'class:example')
    - tag: Tag name (e.g., 'tag:div')
    - xpath: XPath expression (e.g., 'xpath://div[@id="example"]')
    - css: CSS selector (e.g., 'css:div#example')
    - dom: DOM expression (e.g., 'dom:document.images[5]')
    - link: Exact link text (e.g., 'link:Click Here')
    - partial link: Partial link text (e.g., 'partial link:Click')
    - data: Element data-* attribute (e.g., 'data:id:my_id')
    - jquery: jQuery expression (e.g., 'jquery:div.example')
    - default: Keyword-specific default (e.g., 'default:example')

    Args:
        error_message: Optional error message to analyze for specific guidance
        keyword_name: Optional keyword name that failed for context-specific tips

    Returns:
        Comprehensive locator strategy guidance with examples, tips, and error-specific advice
    """
    from robotmcp.utils.rf_native_type_converter import RobotFrameworkNativeConverter

    converter = RobotFrameworkNativeConverter()
    return converter.get_selenium_locator_guidance(error_message, keyword_name)


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def get_browser_locator_guidance(
    error_message: str = None, keyword_name: str = None
) -> Dict[str, Any]:
    """Get comprehensive Browser Library (Playwright) locator strategy guidance for AI agents.

    This tool helps AI agents understand Browser Library's selector strategies and
    provides context-aware suggestions for element location and error resolution.

    Browser Library uses Playwright's locator strategies with these key features:

    **Selector Strategies:**
    - css: CSS selector (default) - e.g., '.button' or 'css=.button'
    - xpath: XPath expression - e.g., '//button' or 'xpath=//button'
    - text: Text content matching - e.g., '"Login"' or 'text=Login'
    - id: Element ID - e.g., 'id=submit-btn'
    - data-testid: Test ID attribute - e.g., 'data-testid=login-button'

    **Advanced Features:**
    - Cascaded selectors: 'text=Hello >> ../.. >> .select_button'
    - iFrame piercing: 'id=myframe >>> .inner-button'
    - Shadow DOM: Automatic piercing with CSS and text engines
    - Strict mode: Controls behavior with multiple element matches
    - Element references: '${ref} >> .child' for chained operations

    **Implicit Detection Rules:**
    - Plain selectors → CSS (default): '.button' becomes 'css=.button'
    - Starting with // or .. → XPath: '//button' becomes 'xpath=//button'
    - Quoted text → Text selector: '"Login"' becomes 'text=Login'
    - Explicit format: 'strategy=value' for any strategy

    Args:
        error_message: Optional error message to analyze for specific guidance
        keyword_name: Optional keyword name that failed for context-specific tips

    Returns:
        Comprehensive Browser Library locator guidance with examples, patterns, and error-specific advice
    """
    from robotmcp.utils.rf_native_type_converter import RobotFrameworkNativeConverter

    converter = RobotFrameworkNativeConverter()
    return converter.get_browser_locator_guidance(error_message, keyword_name)


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def get_appium_locator_guidance(
    error_message: str = None, keyword_name: str = None
) -> Dict[str, Any]:
    """Get comprehensive AppiumLibrary locator strategy guidance for AI agents.

    This tool helps AI agents understand AppiumLibrary's locator strategies and
    provides context-aware suggestions for mobile element location and error resolution.

    AppiumLibrary supports these locator strategies:

    **Basic Locators:**
    - id: Element ID (e.g., 'id=my_element' or just 'my_element')
    - xpath: XPath expression (e.g., '//*[@type="android.widget.EditText"]')
    - identifier: Matches by @id attribute (e.g., 'identifier=my_element')
    - accessibility_id: Accessibility options utilize (e.g., 'accessibility_id=button3')
    - class: Matches by class (e.g., 'class=UIAPickerWheel')
    - name: Matches by @name attribute (e.g., 'name=my_element') - Only valid for Selendroid

    **Platform-Specific Locators:**
    - android: Android UI Automator (e.g., 'android=UiSelector().description("Apps")')
    - ios: iOS UI Automation (e.g., 'ios=.buttons().withName("Apps")')
    - predicate: iOS Predicate (e.g., 'predicate=name=="login"')
    - chain: iOS Class Chain (e.g., 'chain=XCUIElementTypeWindow[1]/*')

    **WebView Locators:**
    - css: CSS selector in webview (e.g., 'css=.green_button')

    **Default Behavior:**
    - By default, locators match against key attributes (id for all elements)
    - Plain text (e.g., 'my_element') is treated as ID lookup
    - XPath should start with // or use explicit 'xpath=' prefix

    **WebElement Support:**
    Starting with AppiumLibrary v1.4, you can pass WebElement objects:
    - Get elements with: Get WebElements or Get WebElement
    - Use directly: Click Element ${element}

    Args:
        error_message: Optional error message to analyze for specific guidance
        keyword_name: Optional keyword name that failed for context-specific tips

    Returns:
        Comprehensive locator strategy guidance with examples, tips, and error-specific advice
    """
    from robotmcp.utils.rf_native_type_converter import RobotFrameworkNativeConverter

    converter = RobotFrameworkNativeConverter()
    return converter.get_appium_locator_guidance(error_message, keyword_name)


async def _get_loaded_libraries_payload() -> Dict[str, Any]:
    # S4: Check bridge first and use its library list when available
    client = _get_external_client_if_configured()
    if client is not None:
        try:
            diag = client.diagnostics()
            if diag.get("success"):
                bridge_libs = diag.get("result", {}).get("libraries", [])
                return {
                    "success": True,
                    "source": "attach_bridge",
                    "libraries": bridge_libs,
                    "library_count": len(bridge_libs),
                    "context_active": diag.get("result", {}).get("context", False),
                }
        except Exception as e:
            logger.debug(f"Library status via bridge failed: {e}")

    return execution_engine.get_library_status()


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def get_loaded_libraries() -> Dict[str, Any]:
    """Get status of all loaded Robot Framework libraries using both libdoc and inspection methods."""
    return await _get_loaded_libraries_payload()


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def run_test_suite_dry(
    session_id: str = "",
    suite_file_path: str = None,
    validation_level: str = "standard",
    include_warnings: bool = True,
    execution_options: Dict[str, Any] = None,
) -> Dict[str, Any]:
    """Validate test suite using Robot Framework dry run mode.

    RECOMMENDED WORKFLOW - SUITE VALIDATION:
    This tool should be used AFTER build_test_suite to validate the generated suite:
    1. ✅ build_test_suite - Generate .robot file from session steps
    2. ✅ run_test_suite_dry (THIS TOOL) - Validate syntax and structure
    3. ➡️ run_test_suite - Execute if validation passes

    Enhanced Session Resolution:
    - If session_id provided and valid: Uses that session's generated suite
    - If session_id empty/invalid: Automatically finds most suitable session
    - If suite_file_path provided: Validates specified file directly

    Validation Levels:
    - minimal: Basic syntax checking only
    - standard: Syntax + keyword verification + imports (default)
    - strict: All checks + argument validation + structure analysis

    Args:
        session_id: Session with executed steps (auto-resolves if empty/invalid)
        suite_file_path: Direct path to .robot file (optional, overrides session)
        validation_level: Validation depth ('minimal', 'standard', 'strict')
        include_warnings: Include warnings in validation report
        execution_options: Optional Robot CLI-oriented options when validating a file path

    Returns:
        Structured validation results with issues, warnings, and suggestions
    """

    if execution_options is None:
        execution_options = {}

    # Session resolution with same logic as build_test_suite
    from robotmcp.utils.session_resolution import SessionResolver

    session_resolver = SessionResolver(execution_engine.session_manager)

    if suite_file_path:
        # Direct file validation mode
        logger.info(f"Running dry run validation on file: {suite_file_path}")
        return await execution_engine.run_suite_dry_run_from_file(
            suite_file_path,
            validation_level,
            include_warnings,
            execution_options,
        )
    else:
        # Session-based validation mode
        resolution_result = session_resolver.resolve_session_with_fallback(session_id)

        if not resolution_result["success"]:
            return {
                "success": False,
                "tool": "run_test_suite_dry",
                "error": "No valid session or suite file for validation",
                "error_details": resolution_result["error_guidance"],
                "guidance": [
                    "Create a session and execute some steps first",
                    "Use build_test_suite to generate a test suite",
                    "Or provide suite_file_path to validate an existing file",
                ],
                "recommendation": "Use build_test_suite first or provide suite_file_path",
            }

        resolved_session_id = resolution_result["session_id"]
        logger.info(f"Running dry run validation for session: {resolved_session_id}")

        result = await execution_engine.run_suite_dry_run(
            resolved_session_id, validation_level, include_warnings
        )

        # Add session resolution info to result
        if resolution_result.get("fallback_used", False):
            result["session_resolution"] = {
                "fallback_used": True,
                "original_session_id": session_id,
                "resolved_session_id": resolved_session_id,
                "message": f"Automatically used session '{resolved_session_id}' with {resolution_result['session_info']['step_count']} executed steps",
            }
        else:
            result["session_resolution"] = {
                "fallback_used": False,
                "session_id": resolved_session_id,
            }

        return result


@mcp.tool
async def run_test_suite(
    session_id: str = "",
    suite_file_path: str = None,
    mode: SuiteRunMode = "full",
    validation_level: ValidationLevel = "standard",
    include_warnings: bool = True,
    execution_options: Dict[str, Any] = None,
    output_level: str = "standard",
    capture_screenshots: bool = False,
) -> Dict[str, Any]:
    """Validate or execute a Robot Framework suite.

    Args:
        session_id: Session containing steps to build/execute; optional if suite_file_path is given.
        suite_file_path: Path to an existing .robot file to validate/execute.
        mode: "dry"/"validate" for dry run; "full" to execute. Defaults to "full".
        validation_level: Dry-run validation depth ("minimal", "standard", "strict"). Default "standard".
        include_warnings: Whether to include warnings in validation output.
        execution_options: RF execution options (variables, tags, loglevel, etc.). For
            ``suite_file_path`` with dry/validate mode, these are forwarded to Robot (e.g.
            ``variables``, ``include_tags``, ``exclude_tags``, ``test`` / ``tests``,
            ``pythonpath``, ``loglevel``). Subprocess cap: ``dry_run_timeout`` (preferred),
            ``dryrun_timeout``, or ``timeout`` (seconds); default comes from config
            ``DRY_RUN_TIMEOUT``.
        output_level: Response verbosity ("minimal", "standard", "detailed").
        capture_screenshots: Enable screenshot capture on failures (if supported).

    Returns:
        Dict[str, Any]: Suite result:
            - success: bool
            - mode: "dry" or "full"
            - statistics/execution_details/output_files when executed
            - validation_results when dry run
            - session_resolution: info when fallback session resolution is used
            - error/guidance: present on failure
    """

    if execution_options is None:
        execution_options = {}

    mode_norm = (mode or "full").strip().lower()

    from robotmcp.utils.session_resolution import SessionResolver

    session_resolver = SessionResolver(execution_engine.session_manager)

    if suite_file_path:
        if mode_norm in {"dry", "validate", "validation"}:
            logger.info(f"Running dry run validation on file: {suite_file_path}")
            result = await execution_engine.run_suite_dry_run_from_file(
                suite_file_path,
                validation_level,
                include_warnings,
                execution_options,
            )
            result["mode"] = "dry"
            return result

        logger.info(f"Running suite execution on file: {suite_file_path}")
        result = await execution_engine.run_suite_execution_from_file(
            suite_file_path, execution_options, output_level, capture_screenshots
        )
        result["mode"] = "full"
        return result

    resolution_result = session_resolver.resolve_session_with_fallback(session_id)

    if not resolution_result["success"]:
        tool_name = (
            "run_test_suite_dry"
            if mode_norm in {"dry", "validate", "validation"}
            else "run_test_suite"
        )
        return {
            "success": False,
            "tool": tool_name,
            "mode": mode_norm,
            "error": "No valid session or suite file available",
            "error_details": resolution_result["error_guidance"],
            "guidance": [
                "Create a session and execute some steps first",
                "Use build_test_suite to generate a test suite",
                "Or provide suite_file_path to validate or execute an existing file",
            ],
            "recommendation": "Use build_test_suite first or provide suite_file_path",
        }

    resolved_session_id = resolution_result["session_id"]

    if mode_norm in {"dry", "validate", "validation"}:
        logger.info(f"Running dry run validation for session: {resolved_session_id}")
        result = await execution_engine.run_suite_dry_run(
            resolved_session_id, validation_level, include_warnings
        )
        result["mode"] = "dry"
    else:
        logger.info(f"Running suite execution for session: {resolved_session_id}")
        result = await execution_engine.run_suite_execution(
            resolved_session_id, execution_options, output_level, capture_screenshots
        )
        result["mode"] = "full"

    if resolution_result.get("fallback_used", False):
        result["session_resolution"] = {
            "fallback_used": True,
            "original_session_id": session_id,
            "resolved_session_id": resolved_session_id,
            "message": f"Automatically used session '{resolved_session_id}' with {resolution_result['session_info']['step_count']} executed steps",
        }
    else:
        result["session_resolution"] = {
            "fallback_used": False,
            "session_id": resolved_session_id,
        }

    # ADR-015: Externalize large fields to artifacts
    result = _externalize_response("run_test_suite", resolved_session_id, result)

    return result


@mcp.tool(**DISABLED_TOOL_KWARGS)
async def get_session_validation_status(session_id: str = "") -> Dict[str, Any]:
    """Get validation status of all steps in a session with intelligent session resolution."""
    return await _get_session_validation_status_payload(session_id)


async def _diagnose_rf_context_payload(session_id: str) -> Dict[str, Any]:
    """Return diagnostic information about the current RF execution context for a session.

    Includes: whether context exists, created_at, imported libraries, variables count,
    and where possible, the current RF library search order.
    """
    try:
        client = _get_external_client_if_configured()
        if client is not None:
            r = client.diagnostics()
            return {
                "context_exists": r.get("success", False),
                "external": True,
                "result": r.get("result"),
            }
        mgr = get_rf_native_context_manager()
        info = mgr.get_session_context_info(session_id)
        # Try to enrich with Namespace search order and imported libraries
        if info.get("context_exists"):
            ctx = mgr._session_contexts.get(session_id)  # internal, read-only
            extra = {}
            try:
                namespace = ctx.get("namespace")
                # Namespace has no direct getter for search order; infer from libraries list
                lib_names = []
                if hasattr(namespace, "libraries"):
                    libs = namespace.libraries
                    if hasattr(libs, "keys"):
                        lib_names = list(libs.keys())
                extra["namespace_libraries"] = lib_names
            except Exception:
                pass
            info["extra"] = extra
        return info
    except Exception as e:
        logger.error(f"diagnose_rf_context failed: {e}")
        return {"context_exists": False, "error": str(e), "session_id": session_id}


@mcp.tool(
    name="diagnose_rf_context",
    description="Inspect RF context state for a session: libraries, search order, and variables count.",
    **DISABLED_TOOL_KWARGS,
)
async def diagnose_rf_context(session_id: str) -> Dict[str, Any]:
    return await _diagnose_rf_context_payload(session_id)


@mcp.tool
async def manage_attach(action: AttachAction = "status") -> Dict[str, Any]:
    """Inspect or control attach bridge configuration.

    Args:
        action: One of:
            - "status" (default): Check bridge configuration and health
            - "stop": Send stop command to bridge (sets stop flag)
            - "cleanup"/"clean": Clean expired sessions and check bridge health
            - "reset"/"reconnect": Stop bridge and clean all local sessions
            - "disconnect_all"/"terminate"/"force_stop": Force stop bridge and terminate all

    Returns:
        Dict[str, Any]: Attach status payload:
            - success: bool
            - action: echoed action
            - configured/reachable/default_mode/strict: attach configuration fields
            - diagnostics/hint/error: context-specific fields

        For cleanup action:
            - sessions_cleaned: number of expired sessions removed
            - remaining_sessions: count of active sessions
            - bridge_status: bridge health information

        For reset action:
            - bridge_stopped: whether bridge was successfully stopped
            - sessions_cleaned: number of sessions removed
            - recovery_hint: how to restart the bridge

        For disconnect_all action:
            - bridge_stopped: whether bridge was successfully stopped
            - sessions_cleaned: number of sessions removed
            - hint: next steps for bridge restart
    """

    action_norm = (action or "status").strip().lower()

    if action_norm in {"status", "info"}:
        try:
            client = _get_external_client_if_configured()
            mode = os.environ.get("ROBOTMCP_ATTACH_DEFAULT", "auto").strip().lower()
            strict = os.environ.get("ROBOTMCP_ATTACH_STRICT", "0").strip() in {
                "1",
                "true",
                "yes",
            }
            if client is None:
                return {
                    "success": True,
                    "action": "status",
                    "configured": False,
                    "default_mode": mode,
                    "strict": strict,
                    "hint": "Set ROBOTMCP_ATTACH_HOST to enable attach mode.",
                }
            diag = client.diagnostics()
            return {
                "success": True,
                "action": "status",
                "configured": True,
                "host": client.host,
                "port": client.port,
                "reachable": bool(diag.get("success")),
                "diagnostics": diag.get("result"),
                "default_mode": mode,
                "strict": strict,
                "hint": "execute_step(..., use_context=True) routes to the bridge when reachable.",
            }
        except Exception as e:
            logger.error(f"attach status failed: {e}")
            return {"success": False, "action": "status", "error": str(e)}

    if action_norm in {"stop", "shutdown"}:
        try:
            client = _get_external_client_if_configured()
            if client is None:
                return {
                    "success": False,
                    "action": "stop",
                    "error": "Attach mode not configured (ROBOTMCP_ATTACH_HOST not set)",
                }
            resp = client.stop()
            return {
                "success": bool(resp.get("success")),
                "action": "stop",
                "response": resp,
            }
        except Exception as e:
            logger.error(f"attach stop failed: {e}")
            return {"success": False, "action": "stop", "error": str(e)}

    # Phase 2a ADR-004: cleanup action - clean expired sessions and check bridge health
    if action_norm in {"cleanup", "clean"}:
        try:
            # Clean expired local sessions
            expired_count = execution_engine.session_manager.cleanup_expired_sessions()

            # Check bridge health if configured
            client = _get_external_client_if_configured()
            bridge_status: Dict[str, Any] = {"configured": False}

            if client is not None:
                try:
                    health = _check_bridge_health(client)
                    bridge_status = {
                        "configured": True,
                        "reachable": health.get("healthy", False),
                        "context_active": health.get("context_active", False),
                    }
                    if not health.get("healthy"):
                        bridge_status["error"] = health.get("error")
                        bridge_status["recovery_hint"] = health.get("recovery_hint")
                except Exception as health_err:
                    bridge_status = {
                        "configured": True,
                        "reachable": False,
                        "error": str(health_err),
                    }

            return {
                "success": True,
                "action": "cleanup",
                "sessions_cleaned": expired_count,
                "remaining_sessions": len(execution_engine.session_manager.sessions),
                "bridge_status": bridge_status,
            }
        except Exception as e:
            logger.error(f"attach cleanup failed: {e}")
            return {"success": False, "action": "cleanup", "error": str(e)}

    # Phase 2a ADR-004: reset action - stop bridge and clean all local sessions
    if action_norm in {"reset", "reconnect"}:
        try:
            client = _get_external_client_if_configured()
            if client is None:
                return {
                    "success": False,
                    "action": "reset",
                    "error": "Attach mode not configured (ROBOTMCP_ATTACH_HOST not set)",
                }

            # Stop current bridge (sets stop flag)
            stop_resp = client.stop()

            # Clean all local sessions
            sessions_cleaned = execution_engine.session_manager.cleanup_all_sessions()

            return {
                "success": True,
                "action": "reset",
                "bridge_stopped": bool(stop_resp.get("success")),
                "sessions_cleaned": sessions_cleaned,
                "recovery_hint": "RF process must call 'MCP Serve' again to restart bridge",
            }
        except Exception as e:
            logger.error(f"attach reset failed: {e}")
            return {"success": False, "action": "reset", "error": str(e)}

    # Phase 2a ADR-004: disconnect_all action - force stop bridge and terminate all
    if action_norm in {"disconnect_all", "terminate", "force_stop"}:
        try:
            client = _get_external_client_if_configured()
            if client is None:
                return {
                    "success": False,
                    "action": "disconnect_all",
                    "error": "Attach mode not configured (ROBOTMCP_ATTACH_HOST not set)",
                }

            # Try force stop (new verb) with fallback to regular stop
            try:
                stop_resp = client.force_stop()
            except Exception:
                # Fall back to regular stop if force_stop not implemented
                stop_resp = client.stop()

            # Clean all local sessions
            sessions_cleaned = execution_engine.session_manager.cleanup_all_sessions()

            return {
                "success": True,
                "action": "disconnect_all",
                "bridge_stopped": bool(stop_resp.get("success")),
                "sessions_cleaned": sessions_cleaned,
                "hint": "All connections terminated. Bridge must be restarted via MCP Serve.",
            }
        except Exception as e:
            logger.error(f"attach disconnect_all failed: {e}")
            return {"success": False, "action": "disconnect_all", "error": str(e)}

    return {
        "success": False,
        "error": f"Unsupported action '{action}'",
        "action": action,
    }


# ── ADR-007: intent_action MCP tool ───────────────────────────────


def _should_commit_after_fill(
    *,
    commit: bool,
    intent: str,
    result: Dict[str, Any],
    library: str | None,
    dispatched_arguments: list,
) -> bool:
    """Decide whether the commit=True follow-up Dispatch Event should fire.

    Only fires for a successful Browser FILL with a locator argument.
    A failed FILL, a non-FILL intent, a non-Browser library, or an
    empty arg list all skip the follow-up.

    ``intent`` is the literal string the MCP tool receives (e.g. ``"fill"``)
    since the IntentVerb type alias in ``domains.shared.kernel`` is a
    Literal, not an Enum.
    """
    return bool(
        commit
        and result.get("success")
        and (intent == "fill" or str(intent) == "fill")
        and library == "Browser"
        and dispatched_arguments
    )


async def _dispatch_change_after_fill(
    *, target_locator: str, session_id: str,
) -> bool:
    """Fire a real DOM ``change`` event on the just-filled target.

    Many SPAs (Vue, React, Angular, jQuery validate, idealForms) gate
    form-state validation on the ``change`` event, which Playwright's
    ``fill`` does not always emit. Best-effort — failures are logged
    and swallowed so a flaky dispatch never escalates a successful
    fill into a failed step.
    """
    try:
        await get_tool_fn(execute_step)(
            keyword="Dispatch Event",
            arguments=[target_locator, "change"],
            session_id=session_id,
            detail_level="minimal",
            raise_on_failure=False,
            record=False,
        )
        return True
    except Exception as commit_exc:
        logger.debug(
            "intent_action commit=True follow-up dispatch failed: %s",
            commit_exc,
        )
        return False


@mcp.tool
async def intent_action(
    intent: IntentVerb,
    target: str | None = None,
    value: str | None = None,
    session_id: str | None = None,
    options: Dict[str, str] | None = None,
    assign_to: str | None = None,
    detail_level: DetailLevel = "standard",
    force: bool = False,
    match: SelectMatch = "label",
    nth: int | None = None,
    commit: bool = False,
    mode: ExtractMode = "text",
    attribute_name: str | None = None,
) -> Dict[str, Any]:
    """Execute a high-level intent that auto-resolves to the correct library keyword.

    Valid intents: navigate, click, fill, hover, select, assert_visible,
    extract, wait_for.

    Also accepted but DEPRECATED:
    - extract_text — equivalent to ``extract`` with ``mode="text"``. The
      ``extract`` verb is the canonical mode-aware getter (text /
      attribute / count / value / url / title) and additionally surfaces
      ``extracted_value`` at the top level of the response. ``extract_text``
      will be removed in a future release; prefer ``intent="extract"`` for
      new code.

    The intent is resolved based on the session's active library (Browser/SeleniumLibrary/AppiumLibrary).

    Args:
        intent: Action verb (e.g. "click", "navigate", "fill", "extract")
        target: Locator or URL (e.g. "#submit", "text=Login", "https://example.com").
            REQUIRED for navigate/click/fill/hover/select/assert_visible/wait_for.
            Only optional for extract with mode="url" or mode="title".
            Do not pass the string "null"/"None" — that counts as no target and the
            call is rejected with the parameter named.
        value: Value for fill/select intents
        session_id: Session to execute against. Pass the session_id returned by
            analyze_scenario or manage_session(action="init") — the session that has
            your libraries loaded. If omitted, it is inferred ONLY when exactly one
            session has libraries (the response then carries a "session_note" saying
            which was used); with several loaded sessions the call is rejected rather
            than guessed at, and "default" is used only when it is genuinely the
            loaded one. Omitting it does NOT silently target the session you just
            created.
        options: Additional options (e.g. {"timeout": "10s"})
        assign_to: Variable name to capture result (esp. useful for extract:
                   the extracted text/count/attribute is assigned to this var).
        detail_level: Response detail level
        force: Use when: the element is visible but Playwright reports it
            "blocked by another element" — overlay, sticky header,
            cookie-consent banner, modal backdrop, animation still
            running. Symptom: ``Click intercepted`` or
            ``element is not stable`` / ``outside of the viewport``
            errors despite the element appearing correct in the ARIA
            snapshot. Example: a "Submit" button covered by a sticky
            consent banner the user can't dismiss programmatically.

            What it does: for a Browser-library click intent, swaps
            ``Click`` for ``Click With Options force=True``, which
            skips Playwright's actionability checks. For other
            libraries / intents whose mapping declares no
            ``force_keyword``, the flag is silently ignored.

            Caveat: do NOT use ``force=True`` to drive elements that
            are genuinely hidden (display:none, visibility:hidden) —
            that's an anti-pattern; the resulting click won't behave
            like a real user click. Prefer natural locators first;
            fall through to ``force=True`` only when an overlay is
            the genuine cause.
        match: Select-match strategy for the ``select`` intent.
            ``"label"`` (default) - match by visible option text. Mirrors RF
                semantics for ``Select Options By label``.
            ``"value"`` - match by ``<option value="X">`` attribute.
            ``"index"`` - match by zero-based integer index.
            ``"text"`` - synonym for ``"label"`` (most libraries).
            ``"auto"`` - OPT-IN heuristic. Numeric value -> ``"value"``,
                otherwise ``"label"``. Use with care: numeric visible
                labels (years, amounts) mis-route.
            For SeleniumLibrary, this also picks the dispatched keyword
            (``Select From List By Label`` / ``Value`` / ``Index``).
            Ignored for non-select intents.
        nth: Zero-based nth-match index. Disambiguates when multiple
            elements match the same locator (e.g., an id duplicated across
            mobile vs desktop nav). Browser library appends
            ``>> nth=<n>``; SeleniumLibrary appends ``:nth-of-type(<n+1>)``
            for CSS locators only (other locator types are unaffected and
            log a debug-level warning).
        commit: Use when: the page uses Vue, React, Angular reactive
            forms, jQuery validate, idealForms, formvalidation.io, or
            any framework that gates validation on the DOM ``change``
            event. Symptom: a form submit is rejected with a "required"
            or validation error despite every visible field appearing
            correctly filled; the framework's internal model still
            thinks the inputs are empty because Playwright's ``fill``
            didn't fire a real ``change``.

            What it does: after a successful Browser-library FILL,
            dispatches a real DOM ``change`` event on the target via
            Browser's ``Dispatch Event`` keyword. Off by default — the
            follow-up is best-effort and any failure is logged and
            ignored (it never escalates a successful fill into a
            failed step). No effect for non-FILL intents, non-Browser
            libraries, or failed fills.
        mode: For ``intent="extract"`` only. Selects what to read from
            the page; ignored for other intents.
              "text"      — element text content      (default)
              "attribute" — element attribute value (requires attribute_name)
              "count"     — number of matching elements (multi-match OK)
              "value"     — DOM property "value" (input values)
              "url"       — current page URL (no target needed)
              "title"     — current page title (no target needed)
            The extracted value is surfaced as ``result["extracted_value"]``
            and assigned to ``assign_to`` if provided. mode="count"
            additionally skips pre-validation for this call — counting is
            the only mode where matching zero/multiple elements is the
            expected outcome rather than a failure.
        attribute_name: Required when ``intent="extract"`` and
            ``mode="attribute"``; the HTML attribute name to read
            (e.g. ``"href"``, ``"data-testid"``, ``"value"``).
            Ignored for other modes.
    """
    global _intent_action_adapter

    # Lazy init fallback (lifespan may not fire in stdio mode)
    if _intent_action_adapter is None:
        try:
            await _initialize_adr_006_007_008()
        except Exception as e:
            logger.warning("ADR lazy init failed: %s", e)
    if _intent_action_adapter is None:
        return {
            "success": False,
            "error": (
                "Intent system not initialized. "
                "Use execute_step for direct keyword access."
            ),
        }

    # --- weak-model input guards (change: intent-action-weak-model-ergonomics) ------
    # Run BEFORE resolution so the first error names the parameter that is actually
    # wrong. Previously a missing target could only surface AFTER library resolution,
    # so a caller with both problems got "Cannot determine target library ... ensure a
    # library is imported" - misleading when they HAD imported one, into another
    # session. See weak_model_guards for the observed traces.
    from robotmcp.domains.intent import weak_model_guards as _guards

    target = _guards.coerce_absent(target)
    value = _guards.coerce_absent(value)
    assign_to = _guards.coerce_absent(assign_to)
    attribute_name = _guards.coerce_absent(attribute_name)
    session_id = _guards.coerce_absent(session_id)

    if _guards.requires_target(intent, mode) and target is None:
        return {
            "success": False,
            "error": _guards.missing_target_error(intent, mode),
            "intent": intent,
        }

    try:
        _sessions = execution_engine.session_manager.sessions
    except Exception:  # pragma: no cover - session manager always present in practice
        _sessions = {}
    effective_session_id, _session_note, _session_error = _guards.resolve_session_id(
        session_id, _sessions
    )
    if _session_error:
        return {"success": False, "error": _session_error, "intent": intent}
    # -------------------------------------------------------------------------------

    resolution = None  # Hoisted for fallback access in except block

    try:
        from robotmcp.domains.intent.services import IntentResolutionError

        # Resolve intent to keyword + arguments
        resolution = _intent_action_adapter.resolve_intent(
            intent=intent,
            target=target,
            value=value,
            session_id=effective_session_id,
            options=options,
            assign_to=assign_to,
            match=match,
            nth=nth,
            mode=mode,
            attribute_name=attribute_name,
        )

        dispatched_keyword = resolution["keyword"]
        dispatched_arguments: list = list(resolution["arguments"])

        # force=True handling: substitute the dispatched keyword when the
        # mapping declares a force_keyword (e.g. Browser CLICK ->
        # Click With Options), then append "force=True" as a named arg
        # so the underlying library skips its actionability check.
        if force:
            fk = resolution.get("force_keyword")
            if fk:
                dispatched_keyword = fk
            if "force=True" not in dispatched_arguments:
                dispatched_arguments.append("force=True")

        # OBS-06 — extract mode=count intentionally accepts multi-match.
        # Pre-validation would reject the locator when it matches zero
        # or many elements; that's the wrong question for counting.
        # Pass pre_validate_timeout_ms=0 to skip the gate for this call.
        extract_mode = resolution.get("extract_mode")
        execute_kwargs = {
            "keyword": dispatched_keyword,
            "arguments": dispatched_arguments,
            "session_id": effective_session_id,
            "assign_to": resolution.get("assign_to"),
            "detail_level": detail_level,
        }
        if extract_mode == "count":
            execute_kwargs["pre_validate_timeout_ms"] = 0

        # Delegate to execute_step for actual execution.
        # execute_step is a FunctionTool (via @mcp.tool decorator),
        # so we call .fn to get the original async function.
        result = await get_tool_fn(execute_step)(**execute_kwargs)

        # Enrich result with intent metadata
        commit_applied = False
        if isinstance(result, dict):
            if _should_commit_after_fill(
                commit=commit, intent=intent, result=result,
                library=resolution.get("library"),
                dispatched_arguments=dispatched_arguments,
            ):
                commit_applied = await _dispatch_change_after_fill(
                    target_locator=dispatched_arguments[0],
                    session_id=effective_session_id,
                )

            # Tell the caller when the session was inferred rather than given, so a
            # model that omitted session_id can correct itself on the next call
            # instead of repeating the omission (observed: 23 consecutive calls with
            # session_id=None). change: intent-action-weak-model-ergonomics.
            if _session_note:
                result["session_note"] = _session_note

            result["intent_resolved"] = {
                "intent": resolution["intent"],
                "keyword": dispatched_keyword,
                "library": resolution["library"],
                "session_id": effective_session_id,
                "locator_normalized": resolution.get("locator_normalized", False),
                "force_applied": bool(force and resolution.get("force_keyword")),
                "commit_applied": commit_applied,
                "extract_mode": extract_mode,
            }

            # OBS-06: for intent=extract, surface the read value at a
            # predictable top-level key so callers don't have to dig
            # through ``result["result"]`` / ``result["output"]`` /
            # ``result["assigned_values"][var]``. The underlying RF
            # keyword's return value is what we want — it lives in
            # ``result["result"]`` (preferred) or ``result["output"]``
            # (stringified fallback).
            if intent == "extract" and result.get("success"):
                extracted_value = result.get("result")
                if extracted_value is None:
                    extracted_value = result.get("output")
                result["extracted_value"] = extracted_value

        # Track for instruction learning
        _track_tool_result(
            effective_session_id,
            "intent_action",
            {"intent": intent, "target": target, "value": value},
            result if isinstance(result, dict) else {"success": True},
        )

        return result

    except IntentResolutionError as e:
        error_result = {
            "success": False,
            "error": str(e),
            # Carried on the failure path too: this is precisely the call the caller
            # has to correct, so telling them which session was actually used is more
            # valuable here than on success (change: intent-action-weak-model-ergonomics).
            **({"session_note": _session_note} if _session_note else {}),
            "session_id": effective_session_id,
            "hint": (
                "Use execute_step for direct keyword access, or check "
                "valid intents: navigate, click, fill, hover, select, "
                "assert_visible, extract, wait_for "
                "(extract_text is also accepted but deprecated — "
                "prefer extract with mode='text')"
            ),
        }
        _track_tool_result(
            effective_session_id,
            "intent_action",
            {"intent": intent, "target": target, "value": value},
            error_result,
        )
        return error_result

    except Exception as e:
        error_msg = str(e)

        # Navigate fallback: if intent was "navigate" and error looks
        # like no browser/page, try opening one before retrying.
        if (
            intent == "navigate"
            and resolution is not None
            and _intent_resolver is not None
        ):
            library = resolution.get("library", "")
            fallback_steps = _intent_resolver.get_navigate_fallback(
                library=library,
                error_message=error_msg,
                session_id=effective_session_id,
            )
            if fallback_steps:
                try:
                    for step in fallback_steps:
                        fb_result = await get_tool_fn(execute_step)(
                            keyword=step["keyword"],
                            arguments=step["arguments"],
                            session_id=effective_session_id,
                        )
                        if isinstance(fb_result, dict) and not fb_result.get(
                            "success", True
                        ):
                            break
                    else:
                        # All fallback steps succeeded — retry navigate
                        result = await get_tool_fn(execute_step)(
                            keyword=resolution["keyword"],
                            arguments=resolution["arguments"],
                            session_id=effective_session_id,
                            assign_to=resolution.get("assign_to"),
                            detail_level=detail_level,
                        )
                        if isinstance(result, dict):
                            result["intent_resolved"] = {
                                "intent": resolution["intent"],
                                "keyword": resolution["keyword"],
                                "library": resolution["library"],
                                "locator_normalized": resolution.get(
                                    "locator_normalized", False
                                ),
                            }
                            result["fallback_applied"] = True
                            result["fallback_steps"] = len(fallback_steps)
                        _track_tool_result(
                            effective_session_id,
                            "intent_action",
                            {"intent": intent, "target": target, "value": value},
                            result if isinstance(result, dict) else {"success": True},
                        )
                        return result
                except Exception:
                    pass  # Fallback failed — fall through to original error

        error_result = {
            "success": False,
            "error": f"Intent execution failed: {error_msg}",
            # Which session this actually ran against, and whether that was inferred.
            # Without it a caller who omitted session_id cannot tell an execution
            # failure from having targeted the wrong session
            # (change: intent-action-weak-model-ergonomics).
            "session_id": effective_session_id,
            **({"session_note": _session_note} if _session_note else {}),
        }
        _track_tool_result(
            effective_session_id,
            "intent_action",
            {"intent": intent, "target": target, "value": value},
            error_result,
        )
        return error_result


# ── End ADR-007 ────────────────────────────────────────────────────


@mcp.tool(
    name="attach_status",
    description="Report attach-mode configuration and bridge health. Indicates whether execute_step(use_context=true) will route externally.",
    **DISABLED_TOOL_KWARGS,
)
async def attach_status() -> Dict[str, Any]:
    try:
        client = _get_external_client_if_configured()
        configured = client is not None
        mode = os.environ.get("ROBOTMCP_ATTACH_DEFAULT", "auto").strip().lower()
        strict = os.environ.get("ROBOTMCP_ATTACH_STRICT", "0").strip() in {
            "1",
            "true",
            "yes",
        }
        if not configured:
            return {
                "configured": False,
                "default_mode": mode,
                "strict": strict,
                "hint": "Set ROBOTMCP_ATTACH_HOST to enable attach mode.",
            }
        diag = client.diagnostics()
        return {
            "configured": True,
            "host": client.host,
            "port": client.port,
            "reachable": bool(diag.get("success")),
            "diagnostics": diag.get("result"),
            "default_mode": mode,
            "strict": strict,
            "hint": "execute_step(..., use_context=true) routes to the bridge when reachable.",
        }
    except Exception as e:
        logger.error(f"attach_status failed: {e}")
        return {"configured": False, "error": str(e)}


@mcp.tool(
    name="attach_stop_bridge",
    description="Send a stop command to the external attach bridge (McpAttach) to exit MCP Serve in the debugged suite.",
    **DISABLED_TOOL_KWARGS,
)
async def attach_stop_bridge() -> Dict[str, Any]:
    try:
        client = _get_external_client_if_configured()
        if client is None:
            return {
                "success": False,
                "error": "Attach mode not configured (ROBOTMCP_ATTACH_HOST not set)",
            }
        resp = client.stop()
        ok = bool(resp.get("success"))
        return {"success": ok, "response": resp}
    except Exception as e:
        logger.error(f"attach_stop_bridge failed: {e}")
        return {"success": False, "error": str(e)}


# note: variable tools consolidated into get_context_variables/set_variables with attach routing


@mcp.tool(
    name="import_resource",
    description="Import a Robot Framework resource file into the session RF Namespace.",
    **DISABLED_TOOL_KWARGS,
)
async def import_resource(session_id: str, path: str) -> Dict[str, Any]:
    def _local_call() -> Dict[str, Any]:
        mgr = get_rf_native_context_manager()
        return mgr.import_resource_for_session(session_id, path)

    def _external_call(client: ExternalRFClient) -> Dict[str, Any]:
        return client.import_resource(path)

    return _call_attach_tool_with_fallback(
        "import_resource", _external_call, _local_call
    )


@mcp.tool(
    name="import_custom_library",
    description="Import a custom Robot Framework library (module name or file path) into the session RF Namespace.",
    **DISABLED_TOOL_KWARGS,
)
async def import_custom_library(
    session_id: str,
    name_or_path: str,
    args: List[str] | None = None,
    alias: str | None = None,
) -> Dict[str, Any]:
    def _local_call() -> Dict[str, Any]:
        mgr = get_rf_native_context_manager()
        return mgr.import_library_for_session(
            session_id, name_or_path, tuple(args or ()), alias
        )

    def _external_call(client: ExternalRFClient) -> Dict[str, Any]:
        return client.import_library(name_or_path, list(args or ()), alias)

    return _call_attach_tool_with_fallback(
        "import_custom_library", _external_call, _local_call
    )


@mcp.tool(
    name="list_available_keywords",
    description="List available keywords from imported libraries and resources in the session RF Namespace.",
    **DISABLED_TOOL_KWARGS,
)
async def list_available_keywords(session_id: str) -> Dict[str, Any]:
    def _local_call() -> Dict[str, Any]:
        mgr = get_rf_native_context_manager()
        return mgr.list_available_keywords(session_id)

    def _external_call(client: ExternalRFClient) -> Dict[str, Any]:
        r = client.list_keywords()
        return {
            "success": r.get("success", False),
            "session_id": session_id,
            "external": True,
            "keywords_by_library": r.get("result"),
        }

    return _call_attach_tool_with_fallback(
        "list_available_keywords", _external_call, _local_call
    )


async def _get_session_keyword_documentation_payload(
    session_id: str, keyword_name: str
) -> Dict[str, Any]:
    def _local_call() -> Dict[str, Any]:
        mgr = get_rf_native_context_manager()
        return mgr.get_keyword_documentation(session_id, keyword_name)

    def _external_call(client: ExternalRFClient) -> Dict[str, Any]:
        r = client.get_keyword_doc(keyword_name)
        if r.get("success"):
            return {
                "success": True,
                "session_id": session_id,
                "name": r["result"]["name"],
                "source": r["result"]["source"],
                "doc": r["result"]["doc"],
                "args": r["result"].get("args", []),
                "type": "external",
            }
        return {
            "success": False,
            "error": r.get("error", "failed"),
            "session_id": session_id,
        }

    return _call_attach_tool_with_fallback(
        "get_session_keyword_documentation", _external_call, _local_call
    )


@mcp.tool(
    name="get_session_keyword_documentation",
    description="Get documentation for a keyword (library or resource) available in the session RF Namespace.",
    **DISABLED_TOOL_KWARGS,
)
async def get_session_keyword_documentation(
    session_id: str, keyword_name: str
) -> Dict[str, Any]:
    return await _get_session_keyword_documentation_payload(session_id, keyword_name)


def _fetch_artifact_enabled() -> dict:
    """Return @mcp.tool kwargs for fetch_artifact based on env config.

    fetch_artifact is only enabled when BOTH conditions are met:
    1. Output mode is not INLINE (externalization is active)
    2. ROBOTMCP_FETCH_ARTIFACT=true (opt-in, disabled by default)
    """
    from robotmcp.domains.artifact_output.value_objects import (
        OutputMode, is_fetch_artifact_enabled,
    )
    mode = OutputMode.from_env()
    if mode == OutputMode.INLINE or not is_fetch_artifact_enabled():
        return DISABLED_TOOL_KWARGS
    return {} if FASTMCP_V3 else {"enabled": True}


@mcp.tool(**_fetch_artifact_enabled())
async def fetch_artifact(
    artifact_id: str,
    offset: int = 0,
    limit: int = 4000,
) -> Dict[str, Any]:
    """Retrieve externalized artifact content by ID.

    When tool responses are large, rf-mcp externalizes them to artifacts and returns
    a summary with an artifact_id. Use this tool to retrieve the full content.

    Args:
        artifact_id: The artifact identifier (format: art_{12 hex chars}).
        offset: Starting character offset for pagination (default 0).
        limit: Maximum characters to return (default 4000).

    Returns:
        Dict with success, content, offset, total_size, has_more.
        On failure: error message with guidance to re-run the original tool.
    """
    from robotmcp.container import get_container

    container = get_container()
    return container.artifact_retrieval_service.fetch(artifact_id, offset, limit)


class BridgeHealthMonitor:
    """Monitors bridge health with periodic heartbeats.

    This class implements Phase 4 of ADR-004: Optional Heartbeat Monitor.
    It runs a background asyncio task that periodically checks the health
    of the debug bridge connection and triggers session cleanup after
    consecutive failures exceed a threshold.

    Configuration via environment variables:
        ROBOTMCP_BRIDGE_HEARTBEAT: Enable/disable (0 or 1, default 0)
        ROBOTMCP_HEARTBEAT_INTERVAL: Check interval in seconds (default 60)
        ROBOTMCP_HEARTBEAT_THRESHOLD: Failures before cleanup (default 3)
    """

    def __init__(self, interval_seconds: int = 60, failure_threshold: int = 3):
        """Initialize the health monitor.

        Args:
            interval_seconds: Time between health checks in seconds.
            failure_threshold: Number of consecutive failures before triggering cleanup.
        """
        self.interval = interval_seconds
        self.failure_threshold = failure_threshold
        self.consecutive_failures = 0
        self.last_healthy: Optional[float] = None
        self._running = False
        self._task: Optional[asyncio.Task] = None

    async def start(self) -> None:
        """Start the health monitor loop."""
        self._running = True
        self._task = asyncio.create_task(self._monitor_loop())
        logger.info(f"Bridge health monitor started (interval: {self.interval}s)")

    async def stop(self) -> None:
        """Stop the health monitor."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("Bridge health monitor stopped")

    async def _monitor_loop(self) -> None:
        """Main monitoring loop that runs health checks at the configured interval."""
        while self._running:
            await asyncio.sleep(self.interval)
            await self._check_health()

    async def _check_health(self) -> None:
        """Perform a single health check against the bridge.

        Updates consecutive_failures counter and triggers cleanup if threshold exceeded.
        """
        client = _get_external_client_if_configured()
        if client is None:
            # No attach mode configured, nothing to monitor
            return

        try:
            health = _check_bridge_health(client)

            if health.get("healthy"):
                self.last_healthy = time.time()
                self.consecutive_failures = 0
                logger.debug(
                    f"Bridge health check passed (context_active: {health.get('context_active')})"
                )
            else:
                self.consecutive_failures += 1
                logger.warning(
                    f"Bridge health check failed ({self.consecutive_failures}/{self.failure_threshold}): "
                    f"{health.get('recovery_hint', 'unknown issue')}"
                )

                if self.consecutive_failures >= self.failure_threshold:
                    await self._handle_unhealthy_bridge()
        except Exception as e:
            self.consecutive_failures += 1
            logger.warning(f"Bridge health check error: {e}")

            if self.consecutive_failures >= self.failure_threshold:
                await self._handle_unhealthy_bridge()

    async def _handle_unhealthy_bridge(self) -> None:
        """Handle persistent bridge failure by cleaning expired sessions."""
        logger.warning("Bridge unhealthy for extended period, cleaning stale sessions")
        try:
            cleaned = execution_engine.session_manager.cleanup_expired_sessions()
            if cleaned > 0:
                logger.info(f"Cleaned {cleaned} expired sessions due to unhealthy bridge")
            # Reset counter after cleanup to avoid repeated cleanups
            self.consecutive_failures = 0
        except Exception as e:
            logger.error(f"Failed to cleanup sessions after unhealthy bridge detection: {e}")


# Global health monitor instance (set in main() if enabled)
_health_monitor: Optional[BridgeHealthMonitor] = None


def _build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="RobotMCP server entry point with optional Django frontend."
    )
    parser.add_argument(
        "--with-frontend",
        dest="frontend_enabled_flag",
        action="store_const",
        const=True,
        help="Start the optional Django-based frontend alongside the MCP server.",
    )
    parser.add_argument(
        "--without-frontend",
        dest="frontend_enabled_flag",
        action="store_const",
        const=False,
        help="Disable the optional frontend even if the environment enables it.",
    )
    parser.add_argument(
        "--frontend-host",
        dest="frontend_host",
        help="Host interface for the frontend server (default 127.0.0.1).",
    )
    parser.add_argument(
        "--frontend-port",
        dest="frontend_port",
        type=int,
        help="Port for the frontend server (default 8001).",
    )
    parser.add_argument(
        "--frontend-base-path",
        dest="frontend_base_path",
        help="Base path prefix for the frontend (default '/').",
    )
    parser.add_argument(
        "--frontend-debug",
        dest="frontend_debug",
        action="store_const",
        const=True,
        help="Enable Django debug mode for the frontend.",
    )
    parser.add_argument(
        "--frontend-no-debug",
        dest="frontend_debug",
        action="store_const",
        const=False,
        help="Disable Django debug mode for the frontend.",
    )
    parser.add_argument(
        "--transport",
        dest="transport",
        choices=["stdio", "http", "sse"],
        help="Transport to use for the MCP server (default: stdio).",
    )
    parser.add_argument(
        "--host",
        dest="host",
        help="Host/interface for HTTP transport (default 127.0.0.1).",
    )
    parser.add_argument(
        "--port",
        dest="port",
        type=int,
        help="Port for HTTP transport (default 8000).",
    )
    parser.add_argument(
        "--path",
        dest="path",
        help="Path for HTTP/streamable endpoints (default '/').",
    )
    parser.add_argument(
        "--log-level",
        dest="log_level",
        help="Log level for the MCP server (e.g., INFO, DEBUG).",
    )
    return parser


# ── Finalize disabled tools for fastmcp v3 compatibility ──────────
# On v2: enabled=False already handled at decorator time (no-op here).
# On v3: calls mcp.disable(names=...) to hide these superseded tools.
_DISABLED_TOOL_NAMES_BASE: frozenset[str] = frozenset({
    "attach_status",
    "attach_stop_bridge",
    "debug_parse_keyword_arguments",
    "diagnose_library_plugin",
    "diagnose_rf_context",
    "discover_keywords",
    "evaluate_expression",
    "execute_for_each",
    "fetch_artifact",
    "execute_if",
    "execute_try_except",
    "get_appium_locator_guidance",
    "get_application_state",
    "get_available_keywords",
    "get_browser_locator_guidance",
    "get_context_variables",
    "get_keyword_documentation",
    "get_library_documentation",
    "get_library_status",
    "get_loaded_libraries",
    "get_page_source",
    "get_selenium_locator_guidance",
    "get_session_info",
    "get_session_keyword_documentation",
    "get_session_validation_status",
    "import_custom_library",
    "import_resource",
    "initialize_context",
    "list_available_keywords",
    "list_library_plugins",
    "load_test_data",
    "reload_library_plugins",
    "run_test_suite_dry",
    "search_keywords",
    "set_variables",
    "suggest_next_step",
    "validate_scenario",
    "validate_test_readiness",
})

# ADR-015: Enable fetch_artifact only when explicitly opted-in
def _compute_disabled_tools() -> frozenset:
    from robotmcp.domains.artifact_output.value_objects import (
        OutputMode, is_fetch_artifact_enabled,
    )
    mode = OutputMode.from_env()
    if mode != OutputMode.INLINE and is_fetch_artifact_enabled():
        return _DISABLED_TOOL_NAMES_BASE - {"fetch_artifact"}
    return _DISABLED_TOOL_NAMES_BASE

_DISABLED_TOOL_NAMES: frozenset[str] = _compute_disabled_tools()
finalize_disabled_tools(mcp, _DISABLED_TOOL_NAMES)

# ── ADR-014: Register memory MCP tools if available ────────────────
try:
    from robotmcp.domains.memory.services import create_memory_services as _create_mem_svc

    _mem_services = _create_mem_svc()
    if _mem_services is not None:
        from robotmcp.domains.memory.adapters import FastMCPMemoryAdapter

        _mem_adapter = FastMCPMemoryAdapter(
            query_service=_mem_services["query_service"],
            hook_service=_mem_services["hook_service"],
            store=_mem_services["store"],
            embedding_service=_mem_services["embedding_service"],
        )
        # Tools are visible (not disabled) because memory was explicitly enabled
        _mem_adapter.register_tools(mcp, disabled=False)
        logger.info("ADR-014: Memory MCP tools registered (5 tools)")
except Exception as _mem_exc:
    logger.debug("ADR-014: Memory tools not registered: %s", _mem_exc)
# ── End ADR-014 ────────────────────────────────────────────────────


def _protect_mcp_stdout() -> None:
    """Redirect sys.__stdout__ to stderr to prevent RF console output from
    corrupting the MCP stdio transport.

    The MCP SDK captures ``sys.stdout.buffer`` once at startup for JSON-RPC
    responses.  Robot Framework's ``Log To Console`` keyword and any library
    ``print()`` call write to ``sys.__stdout__`` instead.  By replacing
    ``sys.__stdout__`` with a stderr-backed wrapper, those writes go to
    stderr while MCP's captured buffer reference remains on fd 1.

    Additionally monkey-patches ``robot.output.librarylogger.write_to_console``
    to force ``stream='stderr'`` as a defence-in-depth measure.
    """
    import sys as _sys
    from io import TextIOWrapper

    # Phase 2: Replace sys.__stdout__ with stderr wrapper.
    # MCP uses sys.stdout.buffer (captured at mcp.run() time) — unaffected.
    # RF uses sys.__stdout__ (resolved at call time) — now goes to stderr.
    try:
        stderr_fd = _sys.stderr.fileno()
        _sys.__stdout__ = TextIOWrapper(
            open(stderr_fd, "wb", closefd=False),
            encoding="utf-8",
            line_buffering=True,
        )
    except (OSError, AttributeError):
        # Non-fd stderr (e.g., pytest capture) — use stderr object directly
        _sys.__stdout__ = _sys.stderr

    # Phase 3: Monkey-patch RF's write_to_console to force stderr stream.
    try:
        import robot.output.librarylogger as _rll

        _original_w2c = _rll.write_to_console

        def _safe_write_to_console(msg, newline=True, stream="stdout"):
            return _original_w2c(msg, newline=newline, stream="stderr")

        _rll.write_to_console = _safe_write_to_console
    except (ImportError, AttributeError):
        pass  # RF not installed or API changed

    # Phase 4: Drop RF's global console logger (change: mcp-stdio-log-safety).
    # robot.output.logger.LOGGER registers a VerboseOutput console logger at
    # import time, BOUND to the real sys.__stdout__ (fd 1) captured then — before
    # this function's Phase-2 swap. Per-context Output(console='none') does NOT
    # unregister it, so the first start_test broadcast writes the padded test-name
    # banner ("MCP_Test_<sid>" + spaces, no newline) straight to fd 1, corrupting
    # the JSON-RPC stream and hanging the client on its first keyword until timeout.
    # Unregister it outright: rf-mcp never wants RF console output on any fd.
    try:
        from robot.output.logger import LOGGER as _RF_LOGGER

        _RF_LOGGER.unregister_console_logger()
    except (ImportError, AttributeError):
        pass  # RF not installed or API changed


# Onboarding subcommands handled before the server starts (see robotmcp.onboarding).
# Kept as literals here so importing server.py does not pull in the installer.
_ONBOARDING_SUBCOMMANDS = frozenset({"init", "install", "uninstall", "list", "doctor"})
_ONBOARDING_VERSION_FLAGS = frozenset({"--version", "-V"})


def main(argv: List[str] | None = None) -> None:
    """Start the RobotMCP server, optionally booting the Django frontend.

    Onboarding subcommands (``init``/``install``/``uninstall``/``list``/``doctor``)
    and ``--version`` are dispatched here BEFORE the server parser and exit without
    starting the MCP server; bare ``robotmcp`` still launches the server.
    """
    import sys as _sys

    _argv = list(_sys.argv[1:] if argv is None else argv)
    if _argv and (_argv[0] in _ONBOARDING_SUBCOMMANDS or _argv[0] in _ONBOARDING_VERSION_FLAGS):
        from robotmcp.onboarding import run as _run_onboarding

        raise SystemExit(_run_onboarding(_argv))

    parser = _build_arg_parser()
    args = parser.parse_args(argv)

    # Stdio-safe logging (change: mcp-stdio-log-safety): stderr defaults to
    # WARNING (ROBOTMCP_LOG_LEVEL overrides), a blocked/broken stderr pipe can
    # never freeze execution, and — when ROBOTMCP_MCP_LOG_NOTIFICATIONS is set —
    # records are forwarded to the client as structured log notifications.
    from robotmcp.utils.logging_setup import (
        configure_logging,
        mcp_log_notifications_enabled,
        build_log_sink_middleware,
    )

    configure_logging()
    if mcp_log_notifications_enabled():
        try:
            _mw = build_log_sink_middleware()
            if _mw is not None:
                mcp.add_middleware(_mw)
        except Exception:
            logger.warning("Could not attach MCP log-notification middleware")

    # Protect MCP stdio transport from RF console output contamination.
    # Must run before mcp.run() so sys.__stdout__ is redirected before any
    # RF keyword execution, but after MCP can still capture sys.stdout.buffer.
    _protect_mcp_stdout()

    try:
        _log_attach_banner()
    except Exception:
        pass

    # ADR-004 Phase 1: Startup validation and cleanup
    try:
        _startup_bridge_validation()
    except Exception:
        pass

    from robotmcp.frontend.config import (
        FrontendConfig,
        build_frontend_config,
        frontend_enabled_from_env,
    )

    enable_frontend = frontend_enabled_from_env(default=False)
    if args.frontend_enabled_flag is not None:
        enable_frontend = args.frontend_enabled_flag

    frontend_config = FrontendConfig(enabled=False)
    if enable_frontend:
        if not _frontend_dependencies_available():
            logger.warning(
                "Frontend requested but Django/uvicorn dependencies are missing. "
                "Install with 'pip install rf-mcp[frontend]' or disable the frontend."
            )
            enable_frontend = False
        else:
            frontend_config = build_frontend_config(
                enabled=True,
                host=args.frontend_host,
                port=args.frontend_port,
                base_path=args.frontend_base_path,
                debug=args.frontend_debug,
            )
            # stdio has a single session, so the per-session FastMCP lifespan is
            # fine; but for http/sse a per-session lifespan never binds the frontend
            # at startup and tears it down when a client session ends (C4), so start
            # the controller eagerly for the whole process lifetime instead.
            if (args.transport or "stdio") == "stdio":
                _install_frontend_lifespan(frontend_config)
            else:
                _start_frontend_eager(frontend_config)

    if enable_frontend:
        logger.info("Starting RobotMCP with frontend at %s", frontend_config.url)
    else:
        logger.info("Starting RobotMCP without frontend")

    # Configure bridge health monitor if enabled (Phase 4 of ADR-004)
    # Environment variables:
    #   ROBOTMCP_BRIDGE_HEARTBEAT: 0 or 1 (default 0 - disabled)
    #   ROBOTMCP_HEARTBEAT_INTERVAL: seconds (default 60)
    #   ROBOTMCP_HEARTBEAT_THRESHOLD: failures before cleanup (default 3)
    heartbeat_enabled = os.environ.get("ROBOTMCP_BRIDGE_HEARTBEAT", "0").strip() in {
        "1",
        "true",
        "yes",
    }
    if heartbeat_enabled:
        # Only enable if attach mode is configured
        if _get_external_client_if_configured() is not None:
            try:
                heartbeat_interval = int(
                    os.environ.get("ROBOTMCP_HEARTBEAT_INTERVAL", "60")
                )
                heartbeat_threshold = int(
                    os.environ.get("ROBOTMCP_HEARTBEAT_THRESHOLD", "3")
                )
                _install_health_monitor_lifespan(
                    interval_seconds=heartbeat_interval,
                    failure_threshold=heartbeat_threshold,
                )
                logger.info(
                    f"Bridge health monitor enabled (interval: {heartbeat_interval}s, "
                    f"threshold: {heartbeat_threshold} failures)"
                )
            except ValueError as e:
                logger.warning(f"Invalid heartbeat configuration, monitor disabled: {e}")
        else:
            logger.debug(
                "Bridge health monitor requested but attach mode not configured, skipping"
            )

    try:
        run_kwargs = {}

        # Default to stdio when no transport is provided to remain backward compatible
        transport = args.transport or "stdio"
        run_kwargs["transport"] = transport

        # Suppress FastMCP's decorative startup banner — it is pure noise on the
        # stderr stream that MCP clients render as warnings (change: mcp-stdio-log-safety).
        try:
            import inspect as _inspect
            if "show_banner" in _inspect.signature(mcp.run).parameters:
                run_kwargs["show_banner"] = False
        except Exception:
            pass

        # log_level is accepted by both stdio and http
        if args.log_level:
            run_kwargs["log_level"] = args.log_level

        # Only pass host/port/path when using HTTP/SSE transports
        if transport != "stdio":
            if args.host:
                run_kwargs["host"] = args.host
            if args.port:
                run_kwargs["port"] = args.port
            if args.path:
                run_kwargs["path"] = args.path

        # Warm up the lazy ExecutionCoordinator in the background right after the
        # event loop comes up, so the first tool call doesn't pay the init
        # (change: fast-mcp-handshake-lazy-init). The MCP handshake is answered
        # from static metadata and is unaffected. A tool call arriving during
        # warm-up blocks on the same factory lock — never longer than one init.
        if (
            os.environ.get("ROBOTMCP_LAZY_INIT") != "0"
            and os.environ.get("ROBOTMCP_WARMUP") != "0"
        ):
            def _warm_up_engine():
                try:
                    _get_execution_engine()
                except Exception as e:  # never let warm-up break startup
                    logger.debug(f"Engine warm-up failed (lazy path remains): {e}")

            threading.Thread(
                target=_warm_up_engine, name="robotmcp-engine-warmup", daemon=True
            ).start()

        # One deliberate, always-visible readiness line on stderr (the server is
        # about to serve) with its key config — replaces the suppressed FastMCP
        # banner (change: mcp-stdio-log-safety).
        try:
            from robotmcp.utils.logging_setup import emit_ready_banner
            emit_ready_banner(transport)
        except Exception:
            pass

        mcp.run(**run_kwargs)
    except KeyboardInterrupt:
        logger.info("RobotMCP interrupted by user")
    finally:
        # Shutdown instruction learning and persist metrics
        try:
            hooks = _get_instruction_hooks()
            shutdown_result = hooks.shutdown()
            if shutdown_result.get("persisted"):
                logger.info(
                    f"Instruction learning data persisted: "
                    f"{shutdown_result.get('sessions_ended', 0)} sessions saved"
                )
        except Exception:
            logger.debug("Failed to shutdown instruction learning", exc_info=True)

        try:
            if _real_execution_engine is not None:
                _real_execution_engine.session_manager.cleanup_all_sessions()
        except Exception:
            logger.debug("Failed to cleanup sessions on shutdown", exc_info=True)
        finally:
            if _real_execution_engine is not None:
                _real_execution_engine.keyword_executor._rf_exec.shutdown(
                    wait=True, cancel_futures=True
                )

        if _frontend_controller:
            try:
                asyncio.run(_frontend_controller.stop())
            except RuntimeError:
                loop = asyncio.new_event_loop()
                loop.run_until_complete(_frontend_controller.stop())
                loop.close()


if __name__ == "__main__":
    main()
