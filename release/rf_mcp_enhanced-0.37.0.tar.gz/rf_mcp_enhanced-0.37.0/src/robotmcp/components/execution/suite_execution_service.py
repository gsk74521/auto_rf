"""Suite Execution Service for running Robot Framework test suites in dry run and normal modes."""

import asyncio
import logging
import os
import re
import tempfile
import uuid
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime
import io
import subprocess
import sys
import signal
from contextlib import redirect_stdout, redirect_stderr

# Hoisted above the `logger` assignment and the import guard below: once `logger = ...`
# moved up (see next comment), any module-level import after it counted as
# "import after code" (E402). `config_models` pulls in stdlib only, so there is no
# cycle and no cost to importing it first (change: quality-baseline-cleanup).
from robotmcp.models.config_models import ExecutionConfig

# Defined BEFORE the try/except below, which uses it. It used to be assigned after,
# so a missing Robot Framework made the handler raise
# `NameError: name 'logger' is not defined` instead of logging its warning - turning a
# degraded-mode notice into an import-time crash (change: quality-baseline-cleanup).
logger = logging.getLogger(__name__)

try:
    from robot import run_cli, rebot_cli
    from robot.api import ExecutionResult, TestSuite
    from robot.running import TestSuite as RunningTestSuite
    from robot.parsing import get_model
    from robot.libraries.BuiltIn import BuiltIn
    ROBOT_AVAILABLE = True
except ImportError:
    ROBOT_AVAILABLE = False
    logger.warning("Robot Framework not available - suite execution will be limited")


def _kill_process_tree(proc: "subprocess.Popen") -> None:
    """Best-effort terminate a child process AND all of its descendants.

    change: fix-mcp-subprocess-stdin-deadlock. A plain ``proc.kill()`` reaps only the
    direct child; a surviving grandchild (e.g. the uv-trampoline launcher's real
    interpreter) keeps the captured stdout/stderr pipes open and hangs the post-kill
    ``communicate()``. On Windows we ``taskkill /F /T`` the PID tree; on POSIX we
    ``killpg`` (the child is spawned with ``start_new_session=True``). Never raises.
    """
    pid = getattr(proc, "pid", None)
    if pid is not None:
        try:
            if os.name == "nt":
                subprocess.run(
                    ["taskkill", "/F", "/T", "/PID", str(pid)],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=10,
                )
            else:
                os.killpg(os.getpgid(pid), signal.SIGKILL)
        except Exception:
            pass  # missing taskkill / already-dead / permission — fall through
    # Ensure the direct child is gone regardless.
    try:
        proc.kill()
    except Exception:
        pass


class SuiteExecutionService:
    """Service for executing Robot Framework test suites in dry run and normal modes."""
    
    def __init__(self, config: ExecutionConfig):
        self.config = config
        self.temp_dir = self._setup_temp_directory()
        self.active_executions = {}  # Track active executions for cleanup
        
        # Execution timeouts
        self.dry_run_timeout = int(getattr(config, 'DRY_RUN_TIMEOUT', 180))
        self.execution_timeout = getattr(config, 'EXECUTION_TIMEOUT', 300)
        
        logger.info(f"SuiteExecutionService initialized with temp dir: {self.temp_dir}")
    
    def _setup_temp_directory(self) -> str:
        """Setup temporary directory for suite execution."""
        base_temp = getattr(self.config, 'TEMP_DIR_BASE', None)
        if base_temp:
            temp_dir = os.path.join(base_temp, f"rf_mcp_execution_{uuid.uuid4().hex[:8]}")
            os.makedirs(temp_dir, exist_ok=True)
            return temp_dir
        else:
            return tempfile.mkdtemp(prefix="rf_mcp_execution_")

    _DRY_RUN_TIMEOUT_CAP_S = 7200

    def _effective_dry_run_timeout_seconds(self, options: Dict[str, Any]) -> int:
        """Resolve subprocess timeout for dry-run (per-call overrides supported)."""
        base = int(self.dry_run_timeout)
        if base < 1:
            base = 1
        for key in ("dry_run_timeout", "dryrun_timeout"):
            if key not in options or options[key] is None:
                continue
            try:
                v = int(float(options[key]))
                return max(1, min(v, self._DRY_RUN_TIMEOUT_CAP_S))
            except (TypeError, ValueError):
                pass
        if "timeout" in options and options["timeout"] is not None:
            try:
                v = int(float(options["timeout"]))
                return max(1, min(v, self._DRY_RUN_TIMEOUT_CAP_S))
            except (TypeError, ValueError):
                pass
        return max(1, min(base, self._DRY_RUN_TIMEOUT_CAP_S))

    def _append_dry_run_cli_execution_options(self, rf_options: List[str], options: Dict) -> None:
        """Append Robot CLI flags from execution options (shared shape with normal runs)."""
        if options.get("variables"):
            for key, value in options["variables"].items():
                rf_options.extend(["--variable", f"{key}:{value}"])
        if options.get("include_tags"):
            for tag in options["include_tags"]:
                rf_options.extend(["--include", str(tag)])
        if options.get("exclude_tags"):
            for tag in options["exclude_tags"]:
                rf_options.extend(["--exclude", str(tag)])
        test_names: List[str] = []
        if options.get("test"):
            test_names.append(str(options["test"]))
        tests = options.get("tests")
        if isinstance(tests, str):
            test_names.append(tests)
        elif isinstance(tests, (list, tuple)):
            test_names.extend(str(t) for t in tests)
        for name in test_names:
            rf_options.extend(["--test", name])
        pp = options.get("pythonpath")
        if isinstance(pp, str):
            pp = [pp]
        if isinstance(pp, (list, tuple)):
            for p in pp:
                rf_options.extend(["--pythonpath", str(p)])
    
    async def execute_dry_run(
        self,
        suite_content: str,
        session_id: str,
        options: Dict[str, Any] = None,
        existing_suite_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Execute suite in dry run mode and parse validation results.

        Args:
            suite_content: Robot Framework suite content (.robot format); ignored when
                ``existing_suite_path`` is set.
            session_id: Session identifier for tracking
            options: Execution options including validation_level, include_warnings
            existing_suite_path: If set, run Robot against this absolute on-disk suite
                (preserves suite-relative ``Resource`` / file paths). Otherwise a temp
                file is created from ``suite_content`` (generated suites).
        """
        if options is None:
            options = {}

        execution_id = f"dry_{session_id}_{uuid.uuid4().hex[:8]}"

        try:
            if existing_suite_path:
                suite_file = os.path.abspath(existing_suite_path)
                if not os.path.isfile(suite_file):
                    return {
                        "success": False,
                        "tool": "run_test_suite_dry",
                        "session_id": session_id,
                        "error": f"Suite file not found: {suite_file}",
                        "error_type": "file_not_found",
                    }
            else:
                suite_file = await self._create_temp_suite_file(suite_content, execution_id)

            # Execute Robot Framework dry run
            return_code, stdout, stderr = await self._execute_rf_dry_run(suite_file, options)
            
            # Parse results
            validation_results = self._parse_dry_run_output(stdout, stderr, return_code, options)
            
            # Add execution metadata
            validation_results.update({
                "execution_id": execution_id,
                "session_id": session_id,
                "tool": "run_test_suite_dry",
                "execution_time": validation_results.get("execution_time", 0),
                "suite_file_generated": os.path.basename(suite_file),
            })
            
            return validation_results
            
        except Exception as e:
            logger.error(f"Error in dry run execution for session {session_id}: {e}")
            return {
                "success": False,
                "tool": "run_test_suite_dry",
                "session_id": session_id,
                "error": f"Dry run execution failed: {str(e)}",
                "error_type": "execution_error"
            }
        finally:
            await self._cleanup_execution(execution_id)
    
    async def execute_normal(
        self,
        suite_content: str,
        session_id: str,
        options: Dict[str, Any] = None,
        companion_files: List[str] = None,
        existing_suite_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Execute suite normally and parse execution results.

        Args:
            suite_content: Robot Framework suite content (.robot format); ignored when
                ``existing_suite_path`` is set.
            session_id: Session identifier for tracking
            options: Execution options including variables, tags, output settings
            companion_files: Optional list of data file paths to copy alongside a **temp**
                generated suite (ignored when ``existing_suite_path`` is set).
            existing_suite_path: If set, run Robot against this absolute on-disk suite.

        Returns:
            Comprehensive execution results
        """
        if options is None:
            options = {}

        execution_id = f"normal_{session_id}_{uuid.uuid4().hex[:8]}"

        try:
            cleanup_tracking_id: Optional[str] = None
            if existing_suite_path:
                suite_file = os.path.abspath(existing_suite_path)
                if not os.path.isfile(suite_file):
                    return {
                        "success": False,
                        "tool": "run_test_suite",
                        "session_id": session_id,
                        "error": f"Suite file not found: {suite_file}",
                        "error_type": "file_not_found",
                    }
                if execution_id not in self.active_executions:
                    self.active_executions[execution_id] = {"files": [], "dirs": []}
                cleanup_tracking_id = execution_id
            else:
                suite_file = await self._create_temp_suite_file(suite_content, execution_id)

                # ADR-019: Copy companion data files to temp dir
                if companion_files:
                    import shutil

                    for src_path in companion_files:
                        if os.path.isfile(src_path):
                            dst = os.path.join(
                                os.path.dirname(suite_file), os.path.basename(src_path)
                            )
                            shutil.copy2(src_path, dst)
                            logger.debug(f"Copied companion file: {src_path} -> {dst}")

            # Execute Robot Framework normally
            return_code, stdout, stderr, output_dir = await self._execute_rf_normal(
                suite_file, options, cleanup_tracking_id=cleanup_tracking_id
            )
            
            # Parse execution results
            execution_results = await self._parse_execution_results(output_dir, return_code, stdout, stderr, options)
            
            # Add execution metadata
            execution_results.update({
                "execution_id": execution_id,
                "session_id": session_id,
                "tool": "run_test_suite",
                "suite_file_generated": os.path.basename(suite_file)
            })
            
            return execution_results
            
        except Exception as e:
            logger.error(f"Error in normal execution for session {session_id}: {e}")
            return {
                "success": False,
                "tool": "run_test_suite",
                "session_id": session_id,
                "error": f"Normal execution failed: {str(e)}",
                "error_type": "execution_error"
            }
        finally:
            # Cleanup handled by configuration (may preserve output files)
            if not getattr(self.config, 'PRESERVE_OUTPUT_FILES', False):
                await self._cleanup_execution(execution_id)
    
    async def _create_temp_suite_file(self, suite_content: str, execution_id: str) -> str:
        """Create temporary .robot file for execution."""
        suite_file = os.path.join(self.temp_dir, f"suite_{execution_id}.robot")
        
        try:
            with open(suite_file, 'w', encoding='utf-8') as f:
                f.write(suite_content)
            
            logger.debug(f"Created temporary suite file: {suite_file}")
            
            # Track for cleanup
            if execution_id not in self.active_executions:
                self.active_executions[execution_id] = {"files": [], "dirs": []}
            self.active_executions[execution_id]["files"].append(suite_file)
            
            return suite_file
            
        except Exception as e:
            logger.error(f"Failed to create temporary suite file: {e}")
            raise
    
    async def _execute_rf_dry_run(self, suite_file: str, options: Dict) -> Tuple[int, str, str]:
        """Execute Robot Framework dry run using native API."""
        if not ROBOT_AVAILABLE:
            raise Exception("Robot Framework not available for dry run execution")

        timeout_s = self._effective_dry_run_timeout_seconds(options)
        # Allow the worker thread to surface subprocess.TimeoutExpired before asyncio aborts.
        asyncio_cap = timeout_s + 60

        try:
            start_time = datetime.now()
            
            # Prepare Robot Framework options
            # NOTE: do NOT add --console none here. The dry-run captures RF's console output
            # via a PIPE and the validation parser reads it (there is no output.xml —
            # --output NONE), so suppressing the console would blank suite_info/test_count.
            # The stdin=DEVNULL isolation below (change: fix-mcp-subprocess-stdin-deadlock)
            # is what fixes the Windows deadlock; the captured stdout is a pipe, not an
            # inherited handle, so there is nothing to defend against with --console none.
            rf_options = ["--dryrun", "--output", "NONE", "--report", "NONE", "--log", "NONE"]
            
            # Add validation level options (execution_options may override loglevel)
            if options.get("loglevel"):
                rf_options.extend(["--loglevel", str(options["loglevel"])])
            else:
                validation_level = options.get("validation_level", "standard")
                if validation_level == "strict":
                    rf_options.extend(["--loglevel", "DEBUG"])
                elif validation_level == "minimal":
                    rf_options.extend(["--loglevel", "WARN"])
                else:
                    rf_options.extend(["--loglevel", "INFO"])

            self._append_dry_run_cli_execution_options(rf_options, options)
            
            # Set output directory
            rf_options.extend(["--outputdir", self.temp_dir])
            
            # Add the suite file
            rf_options.append(suite_file)
            
            logger.debug(f"Executing dry run with options: {rf_options}")

            # Use subprocess so Robot console output is captured reliably (run_cli may
            # write to the underlying stdout fd and bypass contextlib.redirect_stdout).
            def run_robot_dry():
                cmd = [sys.executable, "-m", "robot", *rf_options]
                # stdin=DEVNULL: the dry-run child MUST NOT inherit the MCP server's stdin
                # (its JSON-RPC read channel). On Windows an inherited synchronous stdin
                # pipe deadlocks the child's C-runtime stdio init behind the server's
                # pending read → the dry-run hangs the full timeout (change:
                # fix-mcp-subprocess-stdin-deadlock). Popen (not subprocess.run) so a
                # timeout can reap the whole tree BEFORE draining the pipes.
                popen_kwargs = dict(
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                )
                if os.name != "nt":
                    popen_kwargs["start_new_session"] = True  # own group for killpg
                try:
                    proc = subprocess.Popen(cmd, **popen_kwargs)
                except Exception as e:
                    logger.error(f"Robot Framework dry run error: {e}")
                    return 252, "", str(e)
                try:
                    stdout, stderr = proc.communicate(timeout=timeout_s)
                    return proc.returncode, stdout or "", stderr or ""
                except subprocess.TimeoutExpired:
                    # Reap the whole tree so an orphaned grandchild cannot keep the
                    # capture pipes open and hang the drain below.
                    _kill_process_tree(proc)
                    try:
                        proc.communicate(timeout=5)
                    except Exception:
                        pass
                    raise
                except Exception as e:
                    logger.error(f"Robot Framework dry run error: {e}")
                    _kill_process_tree(proc)
                    return 252, "", str(e)

            loop = asyncio.get_event_loop()
            return_code, stdout_content, stderr_content = await asyncio.wait_for(
                loop.run_in_executor(None, run_robot_dry),
                timeout=asyncio_cap,
            )

            execution_time = (datetime.now() - start_time).total_seconds()

            logger.debug(
                f"Dry run completed in {execution_time:.2f}s with return code {return_code}"
            )

            return return_code, stdout_content, stderr_content
            
        except (asyncio.TimeoutError, subprocess.TimeoutExpired):
            logger.error(f"Dry run execution timed out after {timeout_s}s")
            raise Exception(f"Dry run execution timed out after {timeout_s}s")
        
        except Exception as e:
            logger.error(f"Error executing dry run: {e}")
            raise
    
    async def _execute_rf_normal(
        self,
        suite_file: str,
        options: Dict,
        cleanup_tracking_id: Optional[str] = None,
    ) -> Tuple[int, str, str, str]:
        """Execute Robot Framework normal run using native API."""
        if not ROBOT_AVAILABLE:
            raise Exception("Robot Framework not available for normal execution")

        track_id = (
            cleanup_tracking_id
            if cleanup_tracking_id is not None
            else os.path.basename(suite_file).replace("suite_", "").replace(".robot", "")
        )
        output_dir = os.path.join(self.temp_dir, f"output_{track_id}")
        os.makedirs(output_dir, exist_ok=True)

        # Track output directory for cleanup
        if track_id in self.active_executions:
            self.active_executions[track_id]["dirs"].append(output_dir)
        
        try:
            start_time = datetime.now()
            
            # Prepare Robot Framework options
            rf_options = [
                # Defense-in-depth (change: mcp-stdio-log-safety): --console none
                # so RF's VerboseWriter (which binds sys.__stdout__, not the
                # redirected sys.stdout) never writes progress toward fd 1.
                "--console", "none",
                "--outputdir", output_dir,
                "--output", "output.xml",
                "--report", "report.html",
                "--log", "log.html"
            ]
            
            # Add execution options
            if options.get("variables"):
                for key, value in options["variables"].items():
                    rf_options.extend(["--variable", f"{key}:{value}"])
            
            if options.get("include_tags"):
                for tag in options["include_tags"]:
                    rf_options.extend(["--include", tag])
            
            if options.get("exclude_tags"):
                for tag in options["exclude_tags"]:
                    rf_options.extend(["--exclude", tag])
            
            if options.get("loglevel"):
                rf_options.extend(["--loglevel", options["loglevel"]])
            else:
                rf_options.extend(["--loglevel", "INFO"])
            
            # Add screenshot capture if requested
            if options.get("capture_screenshots", False):
                rf_options.extend(["--variable", "CAPTURE_SCREENSHOTS:True"])
            
            # Add the suite file
            rf_options.append(suite_file)
            
            logger.debug(f"Executing normal run with options: {rf_options}")
            
            # Capture stdout and stderr
            stdout_capture = io.StringIO()
            stderr_capture = io.StringIO()
            
            # Execute Robot Framework in executor to avoid blocking
            def run_robot_normal():
                with redirect_stdout(stdout_capture), redirect_stderr(stderr_capture):
                    try:
                        # Use run_cli which properly handles command line arguments
                        return run_cli(rf_options, exit=False)
                    except SystemExit as e:
                        return e.code if hasattr(e, 'code') else (e.args[0] if e.args else 1)
                    except Exception as e:
                        logger.error(f"Robot Framework execution error: {e}")
                        return 255  # Unexpected internal error
            
            # Run in thread to avoid blocking
            loop = asyncio.get_event_loop()
            return_code = await asyncio.wait_for(
                loop.run_in_executor(None, run_robot_normal),
                timeout=self.execution_timeout
            )
            
            execution_time = (datetime.now() - start_time).total_seconds()
            stdout_content = stdout_capture.getvalue()
            stderr_content = stderr_capture.getvalue()
            
            logger.debug(f"Normal execution completed in {execution_time:.2f}s with return code {return_code}")
            
            return return_code, stdout_content, stderr_content, output_dir
            
        except asyncio.TimeoutError:
            logger.error(f"Normal execution timed out after {self.execution_timeout}s")
            raise Exception(f"Normal execution timed out after {self.execution_timeout}s")
        
        except Exception as e:
            logger.error(f"Error executing normal run: {e}")
            raise
    
    def _validate_suite_syntax(self, suite_content: str) -> Dict[str, Any]:
        """Validate suite syntax using Robot Framework parsing API."""
        if not ROBOT_AVAILABLE:
            return {"syntax_valid": False, "error": "Robot Framework not available"}
        
        try:
            # Create temporary file for parsing
            temp_file = os.path.join(self.temp_dir, f"syntax_check_{uuid.uuid4().hex[:8]}.robot")
            with open(temp_file, 'w', encoding='utf-8') as f:
                f.write(suite_content)
            
            # Try to parse the suite
            try:
                model = get_model(temp_file)
                
                # Basic syntax validation passed
                validation_result = {
                    "syntax_valid": True,
                    "suite_name": getattr(model, 'name', 'Unknown'),
                    "sections": []
                }
                
                # Extract information about sections
                if hasattr(model, 'sections'):
                    for section in model.sections:
                        section_info = {
                            "type": section.__class__.__name__,
                            "header": getattr(section, 'header', None)
                        }
                        validation_result["sections"].append(section_info)
                
                return validation_result
                
            except Exception as parse_error:
                return {
                    "syntax_valid": False,
                    "error": f"Syntax error: {str(parse_error)}",
                    "error_type": "parsing_error"
                }
            
            finally:
                # Clean up temp file
                try:
                    if os.path.exists(temp_file):
                        os.remove(temp_file)
                except Exception:
                    pass
                    
        except Exception as e:
            return {
                "syntax_valid": False,
                "error": f"Validation error: {str(e)}",
                "error_type": "validation_error"
            }
    
    def _parse_dry_run_output(self, stdout: str, stderr: str, return_code: int, options: Dict) -> Dict[str, Any]:
        """Parse dry run output for validation issues."""
        issues = []
        warnings = []
        suggestions = []
        
        # Parse stderr for common error patterns
        error_patterns = [
            (r"No keyword with name '(.+)' found", "missing_keyword", "error"),
            (r"Importing library '(.+)' failed", "import_error", "error"),
            (r"Importing resource '(.+)' failed", "resource_error", "error"),
            (
                r"Resource file ['\"](.+)['\"] does not exist",
                "resource_error",
                "error",
            ),
            (r"Invalid number of arguments", "argument_error", "error"),
            (r"Keyword name cannot be empty", "syntax_error", "error"),
            (r"Variable '(.+)' not found", "variable_error", "error"),
            (r"Invalid variable syntax", "syntax_error", "error")
        ]
        
        # Parse warning patterns
        warning_patterns = [
            (r"Variable '(.+)' is not used", "unused_variable", "warning"),
            (r"Keyword '(.+)' is deprecated", "deprecated_keyword", "warning")
        ]
        
        all_output = stdout + "\n" + stderr
        
        for pattern, issue_type, severity in error_patterns:
            matches = re.findall(pattern, all_output, re.MULTILINE | re.IGNORECASE)
            for match in matches:
                issue = {
                    "type": issue_type,
                    "message": self._format_error_message(issue_type, match),
                    "severity": severity,
                    "context": match if isinstance(match, str) else str(match)
                }
                issues.append(issue)
                
                # Add suggestions based on error type
                suggestion = self._generate_suggestion(issue_type, match)
                if suggestion:
                    suggestions.append(suggestion)
        
        # Parse warnings if requested
        if options.get("include_warnings", True):
            for pattern, issue_type, severity in warning_patterns:
                matches = re.findall(pattern, all_output, re.MULTILINE | re.IGNORECASE)
                for match in matches:
                    warning = {
                        "type": issue_type,
                        "message": self._format_error_message(issue_type, match),
                        "severity": severity,
                        "context": match if isinstance(match, str) else str(match)
                    }
                    warnings.append(warning)
        
        # Determine validation status.
        #
        # ERROR-FIRST. This used to short-circuit on `return_code == 0`, which won
        # unconditionally and discarded error-severity issues: a dry run whose library
        # imports had FAILED reported `validation_status: "passed"`, `success: true`,
        # `return_code: 0` alongside two error issues, and an agent reading that
        # proceeded to a full run before discovering the environment was wrong
        # (change: launch-env-fidelity sec 4).
        #
        # All 8 patterns feeding `issues` were audited before tightening this: each is
        # an unambiguous failure (missing keyword, failed library/resource import,
        # missing resource file, bad argument count, empty keyword name, unknown
        # variable, bad variable syntax). Verified that a Robot Framework dry run of a
        # suite using RUNTIME-ASSIGNED variables emits none of them, so the stricter
        # gate does not turn dry-run variable handling into false failures.
        error_issues = [i for i in issues if i.get("severity") == "error"]
        if error_issues:
            validation_status = "failed"
        elif return_code != 0:
            validation_status = "failed"
        elif issues:
            validation_status = "failed"
        else:
            validation_status = "warning" if warnings else "passed"
        
        # Parse suite information from output
        suite_info = self._extract_suite_info(stdout, stderr)
        
        result = {
            # `success` FOLLOWS `validation_status`. These were computed independently,
            # which is how `success: true` coexisted with two error-severity import
            # failures (change: launch-env-fidelity sec 4).
            "success": validation_status != "failed",
            "validation_status": validation_status,
            "suite_info": suite_info,
            "validation_results": {
                "syntax_valid": return_code == 0 and not any(i["type"] == "syntax_error" for i in issues),
                "imports_valid": not any(i["type"] in ["import_error", "resource_error"] for i in issues),
                "keywords_found": not any(i["type"] == "missing_keyword" for i in issues),
                "issues": issues,
                "warnings": warnings,
                "suggestions": suggestions
            },
            "return_code": return_code
        }
        
        # Include raw output if configured
        if getattr(self.config, 'INCLUDE_RAW_OUTPUT', False):
            result["raw_output"] = {"stdout": stdout, "stderr": stderr}
        
        return result
    
    async def _parse_execution_results(self, output_dir: str, return_code: int, stdout: str, stderr: str, options: Dict) -> Dict[str, Any]:
        """Parse Robot Framework execution results using native Result objects."""
        output_xml = os.path.join(output_dir, "output.xml")
        
        if not os.path.exists(output_xml):
            return {
                "success": False,
                "error": "Output XML not generated",
                "execution_status": "failed",
                "return_code": return_code,
                "raw_output": {"stdout": stdout, "stderr": stderr} if options.get("include_raw_output") else None
            }
        
        try:
            # Use Robot Framework's native result parsing with Result object
            if ROBOT_AVAILABLE:
                try:
                    from robot.result.executionresult import Result
                    from robot.api import ExecutionResult
                    
                    # Load execution result 
                    exec_result = ExecutionResult(output_xml)
                    
                    # Get the Result object which contains detailed statistics and messages
                    result_obj = exec_result.result if hasattr(exec_result, 'result') else exec_result
                    
                    # Extract comprehensive statistics using Result object
                    suite = exec_result.suite
                    stats = suite.statistics
                    
                    statistics = {
                        "total": stats.total,
                        "passed": stats.passed,
                        "failed": stats.failed,
                        "skipped": getattr(stats, 'skipped', 0),
                        "success_rate": stats.passed / max(stats.total, 1) if stats.total > 0 else 0.0
                    }
                    
                    # Extract detailed test information with messages
                    test_details = []
                    failed_tests = []
                    
                    def extract_test_info(suite_obj):
                        """Recursively extract test information from suites."""
                        for test in suite_obj.tests:
                            test_info = {
                                "name": test.name,
                                "status": test.status,
                                "message": test.message,
                                "start_time": test.start_time.isoformat() if test.start_time else None,
                                "end_time": test.end_time.isoformat() if test.end_time else None,
                                "elapsed_time": test.elapsed_time.total_seconds() if test.elapsed_time else 0,
                                "tags": list(test.tags) if hasattr(test, 'tags') else [],
                                "critical": getattr(test, 'critical', True)
                            }
                            test_details.append(test_info)
                            
                            # Add to failed tests if not passed
                            if test.status != "PASS":
                                failed_info = test_info.copy()
                                
                                # Extract failing keyword information
                                failing_keyword = None
                                if hasattr(test, 'body'):
                                    for item in test.body:
                                        if hasattr(item, 'status') and item.status == 'FAIL':
                                            failing_keyword = {
                                                "name": getattr(item, 'name', 'Unknown'),
                                                "message": getattr(item, 'message', ''),
                                                "elapsed_time": item.elapsed_time.total_seconds() if hasattr(item, 'elapsed_time') and item.elapsed_time else 0
                                            }
                                            break
                                
                                if failing_keyword:
                                    failed_info["failing_keyword"] = failing_keyword
                                
                                failed_tests.append(failed_info)
                        
                        # Recursively process nested suites
                        for nested_suite in suite_obj.suites:
                            extract_test_info(nested_suite)
                    
                    extract_test_info(suite)
                    
                    # Build comprehensive execution result
                    execution_result = {
                        "success": return_code == 0,
                        "execution_status": "passed" if return_code == 0 else "failed", 
                        "statistics": statistics,
                        "execution_details": {
                            "start_time": suite.start_time.isoformat() if suite.start_time else None,
                            "end_time": suite.end_time.isoformat() if suite.end_time else None,
                            "elapsed_time": suite.elapsed_time.total_seconds() if suite.elapsed_time else 0,
                            "return_code": return_code,
                            "robot_version": getattr(exec_result, 'generated', 'Unknown')
                        },
                        "suite_info": {
                            "name": suite.name,
                            "full_name": suite.full_name if hasattr(suite, 'full_name') else suite.name,
                            "documentation": suite.doc,
                            "test_count": stats.total,
                            "metadata": dict(suite.metadata) if hasattr(suite, 'metadata') else {},
                            "source": getattr(suite, 'source', 'Unknown')
                        },
                        "output_files": {
                            "output_xml": output_xml,
                            "log_html": os.path.join(output_dir, "log.html"),
                            "report_html": os.path.join(output_dir, "report.html")
                        }
                    }
                    
                    # Add test details based on output level
                    output_level = options.get("output_level", "standard")
                    if output_level == "detailed":
                        execution_result["test_details"] = test_details
                    
                    # Add failed tests if any
                    if failed_tests:
                        execution_result["failed_tests"] = failed_tests[:10]  # Limit to first 10 failures
                        if len(failed_tests) > 10:
                            execution_result["additional_failures"] = len(failed_tests) - 10
                    
                    # Add suite messages and errors
                    if hasattr(suite, 'message') and suite.message:
                        execution_result["suite_message"] = suite.message
                    
                    return execution_result
                    
                except ImportError as e:
                    logger.warning(f"Robot Framework Result parsing not fully available: {e}")
                    return await self._parse_execution_results_fallback(output_xml, return_code, stdout, stderr, output_dir)
            else:
                return await self._parse_execution_results_fallback(output_xml, return_code, stdout, stderr, output_dir)
                
        except Exception as e:
            logger.error(f"Failed to parse execution results: {e}")
            return {
                "success": False,
                "error": f"Failed to parse execution results: {str(e)}",
                "execution_status": "failed",
                "return_code": return_code,
                "error_type": "result_parsing_error"
            }
    
    async def _parse_execution_results_fallback(self, output_xml: str, return_code: int, stdout: str, stderr: str, output_dir: str) -> Dict[str, Any]:
        """Fallback method to parse execution results without Robot Framework API."""
        try:
            # Basic XML parsing to extract statistics
            import xml.etree.ElementTree as ET
            tree = ET.parse(output_xml)
            root = tree.getroot()
            
            # Extract basic statistics from XML
            statistics_elem = root.find(".//total/stat")
            if statistics_elem is not None:
                total = int(statistics_elem.get("pass", 0)) + int(statistics_elem.get("fail", 0))
                passed = int(statistics_elem.get("pass", 0))
                failed = int(statistics_elem.get("fail", 0))
            else:
                total = passed = failed = 0
            
            # Extract suite information
            suite_elem = root.find("suite")
            suite_name = suite_elem.get("name", "Unknown") if suite_elem is not None else "Unknown"
            
            return {
                "success": return_code == 0,
                "execution_status": "passed" if return_code == 0 else "failed",
                "statistics": {
                    "total": total,
                    "passed": passed,
                    "failed": failed,
                    "skipped": 0,
                    "success_rate": passed / max(total, 1)
                },
                "suite_info": {
                    "name": suite_name,
                    "test_count": total
                },
                "output_files": {
                    "output_xml": output_xml,
                    "log_html": os.path.join(output_dir, "log.html"),
                    "report_html": os.path.join(output_dir, "report.html")
                },
                "execution_details": {
                    "return_code": return_code
                },
                "note": "Results parsed using fallback method (limited information available)"
            }
            
        except Exception as e:
            logger.error(f"Fallback parsing also failed: {e}")
            return {
                "success": False,
                "error": f"Both primary and fallback result parsing failed: {str(e)}",
                "execution_status": "failed",
                "return_code": return_code
            }
    
    def _extract_failed_tests(self, suite) -> List[Dict[str, Any]]:
        """Extract information about failed tests from suite results."""
        failed_tests = []
        
        def extract_from_suite(s):
            for test in s.tests:
                if not test.passed:
                    failed_info = {
                        "name": test.name,
                        "status": test.status,
                        "message": test.message,
                        "elapsed_time": test.elapsed_time.total_seconds()
                    }
                    
                    # Try to find the failing keyword
                    for kw in test.body:
                        if hasattr(kw, 'status') and kw.status == 'FAIL':
                            failed_info.update({
                                "failing_keyword": kw.name,
                                "keyword_message": getattr(kw, 'message', '')
                            })
                            break
                    
                    failed_tests.append(failed_info)
            
            # Recursively check nested suites
            for nested_suite in s.suites:
                extract_from_suite(nested_suite)
        
        extract_from_suite(suite)
        return failed_tests
    
    @staticmethod
    def _try_parse_full_test_summary_line(line: str) -> Optional[int]:
        """Parse 'N test[s], X passed, Y failed' from one line (flexible whitespace)."""
        parts = [p.strip() for p in line.strip().split(",")]
        if len(parts) < 3:
            return None
        head, mid, tail = parts[0], parts[1], parts[2]
        hl, ml, tl = head.lower(), mid.lower(), tail.lower()
        if not (hl.endswith(" test") or hl.endswith(" tests")):
            return None
        if not ml.endswith(" passed"):
            return None
        if not tl.endswith(" failed"):
            return None
        s = head.strip()
        i = 0
        while i < len(s) and s[i].isspace():
            i += 1
        j = i
        while j < len(s) and s[j].isdigit():
            j += 1
        if j == i:
            return None
        rest = s[j:].strip().lower()
        if rest not in ("test", "tests"):
            return None
        return int(s[i:j])

    @staticmethod
    def _combined_has_zero_failed(combined: str) -> bool:
        """True if output contains a phrase '<n> failed' with n == 0 (not 10, 20, …)."""
        lower = combined.lower()
        marker = " failed"
        pos = 0
        while True:
            i = lower.find(marker, pos)
            if i == -1:
                return False
            j = i - 1
            while j >= 0 and lower[j].isspace():
                j -= 1
            end = j
            while j >= 0 and lower[j].isdigit():
                j -= 1
            if end > j:
                num = int(lower[j + 1 : end + 1])
                if num == 0 and (j < 0 or not lower[j].isdigit()):
                    return True
            pos = i + len(marker)

    @staticmethod
    def _fallback_tests_count_on_line(line: str) -> Optional[int]:
        """First integer before a standalone 'test' / 'tests' token on this line."""
        s = line.strip()
        lower = s.lower()
        for needle in (" tests", " test"):
            idx = lower.find(needle)
            if idx == -1:
                continue
            j = idx - 1
            while j >= 0 and s[j].isspace():
                j -= 1
            end = j
            while j >= 0 and s[j].isdigit():
                j -= 1
            if end > j:
                return int(s[j + 1 : end + 1])
        return None

    def _parse_robot_test_count_from_output(self, combined: str) -> int:
        for line in combined.splitlines():
            n = self._try_parse_full_test_summary_line(line)
            if n is not None:
                return n
        if self._combined_has_zero_failed(combined):
            for line in combined.splitlines():
                n = self._fallback_tests_count_on_line(line)
                if n is not None:
                    return n
        return 0

    def _extract_suite_info(self, stdout: str, stderr: str) -> Dict[str, Any]:
        """Extract suite information from Robot Framework output."""
        suite_info = {
            "name": "Unknown",
            "test_count": 0,
            "keyword_count": 0,
            "libraries_used": []
        }

        combined = f"{stdout}\n{stderr}"

        # Try to extract suite name
        name_match = re.search(r"^(.+?) :: ", combined, re.MULTILINE)
        if name_match:
            suite_info["name"] = name_match.group(1).strip()

        suite_info["test_count"] = self._parse_robot_test_count_from_output(combined)

        return suite_info
    
    def _format_error_message(self, error_type: str, context: str) -> str:
        """Format error messages based on error type."""
        messages = {
            "missing_keyword": f"Keyword '{context}' not found in available libraries",
            "import_error": f"Failed to import library '{context}'",
            "resource_error": f"Failed to import resource '{context}'",
            "argument_error": "Invalid arguments provided to keyword",
            "syntax_error": "Invalid Robot Framework syntax",
            "variable_error": f"Variable '{context}' is not defined",
            "unused_variable": f"Variable '{context}' is defined but not used",
            "deprecated_keyword": f"Keyword '{context}' is deprecated"
        }
        return messages.get(error_type, f"Unknown error type: {error_type}")
    
    def _generate_suggestion(self, error_type: str, context: str) -> Optional[str]:
        """Generate suggestions based on error type."""
        suggestions = {
            "missing_keyword": f"Check if the library containing '{context}' is imported or if keyword name is spelled correctly",
            "import_error": f"Verify that library '{context}' is installed and available",
            "resource_error": f"Check that resource file '{context}' exists and is accessible",
            "argument_error": "Review keyword documentation for correct argument syntax",
            "variable_error": f"Define variable '{context}' in Variables section or pass as parameter"
        }
        return suggestions.get(error_type)
    
    async def _cleanup_execution(self, execution_id: str):
        """Clean up temporary files and directories for an execution."""
        if execution_id not in self.active_executions:
            return
        
        try:
            execution_data = self.active_executions[execution_id]
            
            # Clean up files
            for file_path in execution_data.get("files", []):
                try:
                    if os.path.exists(file_path):
                        os.remove(file_path)
                        logger.debug(f"Cleaned up file: {file_path}")
                except Exception as e:
                    logger.warning(f"Failed to clean up file {file_path}: {e}")
            
            # Clean up directories (only if not preserving output files)
            if not getattr(self.config, 'PRESERVE_OUTPUT_FILES', False):
                for dir_path in execution_data.get("dirs", []):
                    try:
                        if os.path.exists(dir_path):
                            import shutil
                            shutil.rmtree(dir_path)
                            logger.debug(f"Cleaned up directory: {dir_path}")
                    except Exception as e:
                        logger.warning(f"Failed to clean up directory {dir_path}: {e}")
            
            # Remove from tracking
            del self.active_executions[execution_id]
            
        except Exception as e:
            logger.error(f"Error during cleanup for execution {execution_id}: {e}")
    
    def cleanup_all(self):
        """Clean up all temporary files and directories."""
        logger.info("Cleaning up all suite execution temporary files")
        
        # Clean up tracked executions
        for execution_id in list(self.active_executions.keys()):
            asyncio.create_task(self._cleanup_execution(execution_id))
        
        # Clean up temp directory
        try:
            if os.path.exists(self.temp_dir):
                import shutil
                shutil.rmtree(self.temp_dir)
                logger.debug(f"Cleaned up temp directory: {self.temp_dir}")
        except Exception as e:
            logger.error(f"Failed to clean up temp directory {self.temp_dir}: {e}")
    
    def get_service_status(self) -> Dict[str, Any]:
        """Get current status of the suite execution service."""
        return {
            "service": "SuiteExecutionService",
            "temp_directory": self.temp_dir,
            "active_executions": len(self.active_executions),
            "execution_timeouts": {
                "dry_run": self.dry_run_timeout,
                "normal": self.execution_timeout
            },
            "configuration": {
                "preserve_output_files": getattr(self.config, 'PRESERVE_OUTPUT_FILES', False),
                "include_raw_output": getattr(self.config, 'INCLUDE_RAW_OUTPUT', False)
            }
        }